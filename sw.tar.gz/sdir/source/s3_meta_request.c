/**
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */

#include "aws/s3/private/s3_auto_ranged_get.h"
#include "aws/s3/private/s3_auto_ranged_put.h"
#include "aws/s3/private/s3_checksums.h"
#include "aws/s3/private/s3_client_impl.h"
#include "aws/s3/private/s3_meta_request_impl.h"
#include "aws/s3/private/s3_parallel_input_stream.h"
#include "aws/s3/private/s3_request_messages.h"
#include "aws/s3/private/s3_util.h"
#include "aws/s3/s3express_credentials_provider.h"
#include <aws/auth/signable.h>
#include <aws/auth/signing.h>
#include <aws/auth/signing_config.h>
#include <aws/auth/signing_result.h>
#include <aws/common/clock.h>
#include <aws/common/encoding.h>
#include <aws/common/file.h>
#include <aws/common/math.h>
#include <aws/common/string.h>
#include <aws/common/system_info.h>
#include <aws/io/async_stream.h>
#include <aws/io/event_loop.h>
#include <aws/io/retry_strategy.h>
#include <aws/io/socket.h>
#include <aws/io/stream.h>
#include <errno.h>
#include <inttypes.h>

#define ONE_SEC_IN_NS_P ((uint64_t)AWS_TIMESTAMP_NANOS)
#define MAX_TIMEOUT_NS_P (60 * ONE_SEC_IN_NS_P)

static const size_t s_dynamic_body_initial_buf_size = KB_TO_BYTES(1);
static const size_t s_default_body_streaming_priority_queue_size = 16;
static const size_t s_default_event_delivery_array_size = 16;

/* Modes for the init-only stdio open that brings recv_filepath into existence. Passed as aws_strings
 * so the path converts correctly for non-ASCII paths on Windows. */
AWS_STATIC_STRING_FROM_LITERAL(s_recv_file_create_mode, "wb");
AWS_STATIC_STRING_FROM_LITERAL(s_recv_file_append_mode, "a+b");
AWS_STATIC_STRING_FROM_LITERAL(s_recv_file_update_mode, "r+");

static int s_s3_request_priority_queue_pred(const void *a, const void *b);
static int s_s3_delivery_tracking_record_pred(const void *a, const void *b);
static void s_s3_meta_request_close_write_fds(struct aws_s3_meta_request *meta_request);
static int s_s3_pending_prepare_entry_pred(const void *a, const void *b);
static bool s_s3_meta_request_fold_combine_slots(struct aws_s3_meta_request *meta_request);
static void s_s3_meta_request_destroy(void *user_data);

static void s_s3_meta_request_init_signing_date_time(
    struct aws_s3_meta_request *meta_request,
    struct aws_date_time *date_time);

static void s_s3_meta_request_sign_request(
    struct aws_s3_meta_request *meta_request,
    struct aws_s3_request *request,
    aws_signing_complete_fn *on_signing_complete,
    void *user_data);

static void s_s3_meta_request_request_on_signed(
    struct aws_signing_result *signing_result,
    int error_code,
    void *user_data);

static int s_s3_meta_request_incoming_body(
    struct aws_http_stream *stream,
    const struct aws_byte_cursor *data,
    void *user_data);

static int s_s3_meta_request_incoming_headers(
    struct aws_http_stream *stream,
    enum aws_http_header_block header_block,
    const struct aws_http_header *headers,
    size_t headers_count,
    void *user_data);

static int s_s3_meta_request_headers_block_done(
    struct aws_http_stream *stream,
    enum aws_http_header_block header_block,
    void *user_data);

static void s_s3_meta_request_stream_metrics(
    struct aws_http_stream *stream,
    const struct aws_http_stream_metrics *metrics,
    void *user_data);

static void s_s3_meta_request_stream_complete(struct aws_http_stream *stream, int error_code, void *user_data);

static void s_s3_meta_request_send_request_finish(
    struct aws_s3_connection *connection,
    struct aws_http_stream *stream,
    int error_code);

static bool s_s3_meta_request_read_from_pending_async_writes(
    struct aws_s3_meta_request *meta_request,
    struct aws_byte_buf *dest);

void aws_s3_meta_request_lock_synced_data(struct aws_s3_meta_request *meta_request) {
    AWS_PRECONDITION(meta_request);

    aws_mutex_lock(&meta_request->synced_data.lock);
}

void aws_s3_meta_request_unlock_synced_data(struct aws_s3_meta_request *meta_request) {
    AWS_PRECONDITION(meta_request);

    aws_mutex_unlock(&meta_request->synced_data.lock);
}

/* True if the checksum validated and matched, false otherwise. Finalizes checksum_to_validate. */
static bool s_validate_checksum(
    struct aws_s3_checksum *checksum_to_validate,
    struct aws_byte_buf *expected_encoded_checksum) {

    struct aws_byte_buf response_body_sum;
    struct aws_byte_buf encoded_response_body_sum;
    AWS_ZERO_STRUCT(response_body_sum);
    AWS_ZERO_STRUCT(encoded_response_body_sum);
    bool validated = false;

    size_t encoded_checksum_len = 0;
    if (aws_base64_compute_encoded_len(checksum_to_validate->digest_size, &encoded_checksum_len)) {
        goto done;
    }
    aws_byte_buf_init(&encoded_response_body_sum, checksum_to_validate->allocator, encoded_checksum_len);
    aws_byte_buf_init(&response_body_sum, checksum_to_validate->allocator, checksum_to_validate->digest_size);

    if (aws_checksum_finalize(checksum_to_validate, &response_body_sum)) {
        goto done;
    }
    struct aws_byte_cursor response_body_sum_cursor = aws_byte_cursor_from_buf(&response_body_sum);
    if (aws_base64_encode(&response_body_sum_cursor, &encoded_response_body_sum)) {
        goto done;
    }
    if (aws_byte_buf_eq(&encoded_response_body_sum, expected_encoded_checksum)) {
        validated = true;
    }
done:
    aws_byte_buf_clean_up(&response_body_sum);
    aws_byte_buf_clean_up(&encoded_response_body_sum);
    return validated;
}

/* Validates the whole-object checksum at finish, setting AWS_ERROR_S3_RESPONSE_CHECKSUM_MISMATCH on the
 * result if it doesn't match, and releases the running sum either way.
 *
 * Returns whether this call found a mismatch. The caller needs that answer and cannot get it by reading
 * the result's error code, which only tells it the request failed, not that this check is what failed it.
 * A false return covers both "matched" and "nothing was validated" (validation off, no running sum, the
 * request already failed, or parts missing), which is what every caller wants to treat alike. */
static bool s_validate_meta_request_checksum_on_finish(
    struct aws_s3_meta_request *meta_request,
    struct aws_s3_meta_request_result *meta_request_result) {

    bool mismatch = false;

    /* No lock. meta_request_level_running_response_sum has a single owner at any point in its life: the
     * connection thread that creates it at discovery, then either the delivery loop (byte-wise) or this
     * function (folding recorded part digests), never both. Each handoff sits behind a lock that the path
     * already takes, so nothing here races. See the combine_slots declaration for the ordering argument. */
    if (meta_request->checksum_config.validate_response_checksum && meta_request_result->error_code == AWS_OP_SUCCESS &&
        meta_request->meta_request_level_running_response_sum) {
        /* A part that never completed leaves the whole-object sum covering only a subset of the object, so
         * validating it would be meaningless. Report it as unvalidated rather than as a failure: the caller
         * asked for the object, and every part that arrived was still checked against whatever checksum it
         * carried of its own. */
        bool complete =
            !meta_request->meta_request_level_checksum_combinable || s_s3_meta_request_fold_combine_slots(meta_request);

        if (complete) {
            meta_request_result->did_validate = true;
            meta_request_result->validation_algorithm =
                meta_request->meta_request_level_running_response_sum->algorithm;

            if (!s_validate_checksum(
                    meta_request->meta_request_level_running_response_sum,
                    &meta_request->meta_request_level_response_header_checksum)) {
                meta_request_result->error_code = AWS_ERROR_S3_RESPONSE_CHECKSUM_MISMATCH;
                mismatch = true;
                AWS_LOGF_ERROR(AWS_LS_S3_META_REQUEST, "id=%p Checksum mismatch!", (void *)meta_request);
            }
        }
    }
    aws_checksum_destroy(meta_request->meta_request_level_running_response_sum);
    meta_request->meta_request_level_running_response_sum = NULL;
    aws_byte_buf_clean_up(&meta_request->meta_request_level_response_header_checksum);
    return mismatch;
}

/* The caller can tell us the checksum of the data being downloaded instead of having the client learn it from the
 * service. Seed the meta-request-level checksum with that value here, at creation, so that from this point on
 * nothing downstream can tell a caller-supplied checksum from one a discovery response reported: the same running
 * sum is fed over the same bytes and compared at finish by the same code.
 *
 * Supplying the value is by itself a request to validate, which internally is what validate_response_checksum
 * means, so turn it on. */
static int s_meta_request_init_expected_checksum(
    struct aws_s3_meta_request *meta_request,
    const struct aws_s3_meta_request_options *options) {

    if (options->checksum_config == NULL) {
        return AWS_OP_SUCCESS;
    }
    struct aws_byte_cursor expected_checksum = options->checksum_config->expected_checksum;
    enum aws_s3_checksum_algorithm algorithm = options->checksum_config->expected_checksum_algorithm;

    if (expected_checksum.len == 0 && algorithm == AWS_SCA_NONE) {
        return AWS_OP_SUCCESS;
    }

    if (expected_checksum.len == 0 || algorithm < AWS_SCA_INIT || algorithm > AWS_SCA_END) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p Cannot create meta request; expected_checksum and expected_checksum_algorithm must both be set, "
            "to a known algorithm.",
            (void *)meta_request);
        return aws_raise_error(AWS_ERROR_INVALID_ARGUMENT);
    }

    /* Only a download returns object data for the value to describe. A GetObject issued as a default meta request
     * is one too: the client itself routes a GET carrying a partNumber down that path, and a caller can ask for a
     * download it does not want split by naming the operation directly. Either way the whole response body is the
     * bytes the value covers, arriving through the same delivery loop that feeds the running sum. */
    bool downloads_object_data =
        options->type == AWS_S3_META_REQUEST_TYPE_GET_OBJECT ||
        (options->type == AWS_S3_META_REQUEST_TYPE_DEFAULT &&
         aws_byte_cursor_eq_c_str_ignore_case(
             &options->operation_name, aws_s3_request_type_operation_name(AWS_S3_REQUEST_TYPE_GET_OBJECT)));
    if (!downloads_object_data) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p Cannot create meta request; expected_checksum is only supported for "
            "AWS_S3_META_REQUEST_TYPE_GET_OBJECT, or AWS_S3_META_REQUEST_TYPE_DEFAULT with operation name "
            "GetObject.",
            (void *)meta_request);
        return aws_raise_error(AWS_ERROR_INVALID_ARGUMENT);
    }

    /* The value covers the whole download, which is more than any one response the client receives, and
     * AWS_SCVM_REQUEST_ONLY asks for nothing spanning more than one response to be validated. */
    if (options->checksum_config->response_checksum_validation_mode == AWS_SCVM_REQUEST_ONLY) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p Cannot create meta request; expected_checksum cannot be used with "
            "response_checksum_validation_mode AWS_SCVM_REQUEST_ONLY.",
            (void *)meta_request);
        return aws_raise_error(AWS_ERROR_INVALID_ARGUMENT);
    }

    /* The value has to be one digest of this algorithm, base64-encoded. Among other things this rejects a
     * composite checksum, whose trailing "-N" describes an object's parts rather than any span of bytes. */
    size_t encoded_len = 0;
    if (aws_base64_compute_encoded_len(aws_get_digest_size_from_checksum_algorithm(algorithm), &encoded_len) ||
        expected_checksum.len != encoded_len) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p Cannot create meta request; expected_checksum is not a base64-encoded checksum of the algorithm "
            "it was given with.",
            (void *)meta_request);
        return aws_raise_error(AWS_ERROR_INVALID_ARGUMENT);
    }

    meta_request->meta_request_level_running_response_sum = aws_checksum_new(meta_request->allocator, algorithm);
    if (meta_request->meta_request_level_running_response_sum == NULL) {
        return AWS_OP_ERR;
    }
    if (aws_byte_buf_init_copy_from_cursor(
            &meta_request->meta_request_level_response_header_checksum, meta_request->allocator, expected_checksum)) {
        return AWS_OP_ERR;
    }
    meta_request->checksum_config.validate_response_checksum = true;

    return AWS_OP_SUCCESS;
}

/* Bring `recv_filepath` into existence per the requested recv_file_option, settle whether writes
 * can use O_DIRECT, and allocate the per-worker descriptor slots. No-op when the transfer has no
 * receive file.
 *
 * On failure the error is already raised and the caller's `error:` label destroys the meta request,
 * which is what deletes a file this transfer created. That is why `recv_filepath` is assigned before
 * anything that can fail.
 *
 * `part_size` is passed in rather than read off the meta request because it is not assigned there
 * until after this runs. */
static int s_s3_meta_request_init_recv_file(
    struct aws_s3_meta_request *meta_request,
    const struct aws_s3_meta_request_options *options,
    size_t part_size) {

    if (options->recv_filepath.len == 0) {
        return AWS_OP_SUCCESS;
    }

    /* Rebound as locals so the body below reads the same as it did inline. `client` is NULL exactly
     * when the meta request was created without one, which the fd-slot check below relies on. */
    struct aws_allocator *allocator = meta_request->allocator;
    struct aws_s3_client *client = meta_request->client;

    meta_request->recv_filepath = aws_string_new_from_cursor(allocator, &options->recv_filepath);

    /* Deleting on failure is only safe for a file whose previous content this transfer does not need to keep.
     * WRITE_TO_POSITION always writes into an existing file, and CREATE_OR_APPEND does when the file is
     * already there; deleting either would destroy bytes this transfer never wrote. Rejected before the file
     * is touched. CREATE_OR_REPLACE is allowed: it truncates an existing file, so its old content is gone
     * whether or not the file is deleted afterward. */
    if (options->recv_file_delete_on_failure) {
        bool writes_into_existing_file = options->recv_file_option == AWS_S3_RECV_FILE_WRITE_TO_POSITION ||
                                         (options->recv_file_option == AWS_S3_RECV_FILE_CREATE_OR_APPEND &&
                                          aws_path_exists(meta_request->recv_filepath));
        if (writes_into_existing_file) {
            AWS_LOGF_ERROR(
                AWS_LS_S3_META_REQUEST,
                "id=%p Cannot create meta request; recv_file_delete_on_failure cannot be used when writing into an "
                "existing file (AWS_S3_RECV_FILE_WRITE_TO_POSITION, or AWS_S3_RECV_FILE_CREATE_OR_APPEND with a file "
                "that already exists).",
                (void *)meta_request);
            return aws_raise_error(AWS_ERROR_INVALID_ARGUMENT);
        }
    }

    /* "direct_io" is what we'll attempt; we may flip it off below if any precondition fails.
     * recv_file_direct_io_fallback_count tracks each fallback decision (init-time and write). */
    bool direct_io = meta_request->fio_opts.direct_io;
    size_t page_size = aws_system_info_page_size();
    /* Accumulated locally because the field is atomic and nothing else can touch it yet. */
    size_t direct_io_fallback_count = 0;
    /* Where this transfer's byte 0 lands in the file. Needed for every write, not just O_DIRECT
     * ones, because pwrite() takes an absolute offset rather than following a stream position. */
    uint64_t base_offset = 0;

    /* Bring the file into existence per the requested recv_file_option, and read whatever the mode
     * needs from it. This handle is init-only: nothing writes received bytes through it, so it is
     * closed before this block ends. */
    FILE *init_file = NULL;
    bool file_length_read_failed = false;

    switch (options->recv_file_option) {
        case AWS_S3_RECV_FILE_CREATE_OR_REPLACE:
            init_file = aws_fopen_safe(meta_request->recv_filepath, s_recv_file_create_mode);
            break;

        case AWS_S3_RECV_FILE_CREATE_NEW:
            if (aws_path_exists(meta_request->recv_filepath)) {
                AWS_LOGF_ERROR(
                    AWS_LS_S3_META_REQUEST,
                    "id=%p Cannot receive file via CREATE_NEW: file already exists",
                    (void *)meta_request);
                aws_raise_error(AWS_ERROR_S3_RECV_FILE_ALREADY_EXISTS);
                return AWS_OP_ERR;
            }
            init_file = aws_fopen_safe(meta_request->recv_filepath, s_recv_file_create_mode);
            break;

        case AWS_S3_RECV_FILE_CREATE_OR_APPEND:
            init_file = aws_fopen_safe(meta_request->recv_filepath, s_recv_file_append_mode);
            /* For APPEND, the base offset is the existing file size. It also has to be
             * page-aligned for O_DIRECT writes to land at correct offsets. */
            if (init_file != NULL) {
                int64_t existing_len = 0;
                if (aws_file_get_length(init_file, &existing_len) != AWS_OP_SUCCESS) {
                    /* Recorded rather than jumped on, so the handle below is always closed. */
                    file_length_read_failed = true;
                    break;
                }
                base_offset = (uint64_t)existing_len;
                if (direct_io && base_offset % page_size != 0) {
                    AWS_LOGF_WARN(
                        AWS_LS_S3_META_REQUEST,
                        "id=%p: O_DIRECT requested with CREATE_OR_APPEND but existing file size %" PRId64
                        " is not page-aligned (page size %zu). Falling back to buffered I/O.",
                        (void *)meta_request,
                        existing_len,
                        page_size);
                    direct_io = false;
                    ++direct_io_fallback_count;
                }
            }
            break;

        case AWS_S3_RECV_FILE_WRITE_TO_POSITION:
            if (!aws_path_exists(meta_request->recv_filepath)) {
                AWS_LOGF_ERROR(
                    AWS_LS_S3_META_REQUEST,
                    "id=%p Cannot receive file via WRITE_TO_POSITION: file not found.",
                    (void *)meta_request);
                aws_raise_error(AWS_ERROR_S3_RECV_FILE_NOT_FOUND);
                return AWS_OP_ERR;
            }
            init_file = aws_fopen_safe(meta_request->recv_filepath, s_recv_file_update_mode);
            /* For WRITE_TO_POSITION, the base offset is set by the user. It also has to be
             * page-aligned for O_DIRECT writes. No seek: every write carries its own offset. */
            base_offset = options->recv_file_position;
            if (direct_io && base_offset % page_size != 0) {
                AWS_LOGF_WARN(
                    AWS_LS_S3_META_REQUEST,
                    "id=%p: O_DIRECT requested with WRITE_TO_POSITION but recv_file_position %" PRIu64
                    " is not page-aligned (page size %zu). Falling back to buffered I/O.",
                    (void *)meta_request,
                    options->recv_file_position,
                    page_size);
                direct_io = false;
                ++direct_io_fallback_count;
            }
            break;

        default:
            AWS_ASSERT(false);
            aws_raise_error(AWS_ERROR_INVALID_ARGUMENT);
            return AWS_OP_ERR;
    }

    bool file_opened = init_file != NULL;
    if (file_opened) {
        fclose(init_file);
        init_file = NULL;

        /* Armed as soon as this meta request has opened -- and so possibly created or truncated -- the file, and
         * before anything after the open can fail, so that failure is cleaned up too. Arming it before the open
         * would let an init failure that never touched the file, such as CREATE_NEW finding one already there,
         * delete a file this transfer does not own. */
        meta_request->recv_file_delete_on_failure = options->recv_file_delete_on_failure;
    }

    if (!file_opened || file_length_read_failed) {
        return AWS_OP_ERR;
    }

    /* Additional init-time fallback checks for O_DIRECT */
    if (direct_io && !aws_file_direct_io_is_supported()) {
        /* Platform doesn't support O_DIRECT. Fall back proactively at init rather than
         * waiting for the first write to fail. */
        AWS_LOGF_WARN(
            AWS_LS_S3_META_REQUEST,
            "id=%p: O_DIRECT is not supported on this platform. Falling back to buffered I/O.",
            (void *)meta_request);
        direct_io = false;
        ++direct_io_fallback_count;
    }

    if (direct_io && part_size % page_size != 0) {
        AWS_LOGF_WARN(
            AWS_LS_S3_META_REQUEST,
            "id=%p: O_DIRECT requires part_size to be page-aligned, but part_size is %zu and "
            "page size is %zu. Falling back to buffered I/O.",
            (void *)meta_request,
            part_size,
            page_size);
        direct_io = false;
        ++direct_io_fallback_count;
    }

    if (direct_io) {
        /* Some destinations satisfy every check above yet still reject O_DIRECT at open -- /dev/null
         * is the usual one. Probing here keeps that decision with the other init-time fallbacks, so
         * `recv_file_direct_io` describes what the writers will really do and each of them is spared
         * repeating the same failing open. The probe neither creates nor truncates: the descriptor
         * API opens O_WRONLY only, and the file already exists by this point. */
        int probe_fd = AWS_FILE_INVALID_FD;
        if (aws_file_open_direct_io_for_write(meta_request->recv_filepath, &probe_fd) != AWS_OP_SUCCESS) {
            AWS_LOGF_WARN(
                AWS_LS_S3_META_REQUEST,
                "id=%p: Could not open %s with O_DIRECT. aws-error:%s. Falling back to buffered I/O.",
                (void *)meta_request,
                aws_string_c_str(meta_request->recv_filepath),
                aws_error_name(aws_last_error()));
            aws_reset_error();
            direct_io = false;
            ++direct_io_fallback_count;
        } else {
            aws_file_close_fd(probe_fd);
        }
    }

    meta_request->recv_file_direct_io = direct_io;
    meta_request->recv_file_base_offset = base_offset;
    aws_atomic_init_int(&meta_request->recv_file_direct_io_fallback_count, direct_io_fallback_count);

    /* One descriptor slot per file I/O loop, so a write worker never shares a descriptor.
     * Only a client gives us that loop group; without one no body is delivered at all (body
     * delivery asserts on the client), so the ordered path's own descriptor covers that case.
     * Skipped when out-of-order delivery has been ruled out, since nothing would use them.
     *
     * The type check is a filter, not a guarantee: an auto-ranged GET is the only implementation that
     * ever resolves the delivery order out of order, and it always carries this type -- but so does a
     * GET whose query already names a partNumber, which the client routes to the default
     * implementation instead. Such a request never resolves anything and writes through the ordered
     * path's descriptor, so over-allocating here costs it a few unused slots and nothing else. Under-
     * allocating is the direction that would matter, and this cannot do that.
     *
     * Asks the same decision function the delivery-order resolution uses, so the two cannot disagree
     * about which preference wins. The checksum's ordering demand is not consulted here and does not
     * need to be: it is applied at discovery, and a constraint discovered then just leaves these
     * descriptors unused, whereas skipping them here would leave a request that turns out to be
     * eligible with nothing to write through. */
    bool out_of_order_allowed = client != NULL && meta_request->type == AWS_S3_META_REQUEST_TYPE_GET_OBJECT &&
                                aws_s3_allow_out_of_order_delivery(
                                    true /*file_sink*/,
                                    false /*callback_sink*/,
                                    meta_request->out_of_order_delivery_override,
                                    client->out_of_order_delivery,
                                    client->out_of_order_delivery_env);
    if (out_of_order_allowed) {
        size_t loop_count = aws_event_loop_group_get_loop_count(client->file_io_elg);
        AWS_FATAL_ASSERT(loop_count > 0);
        meta_request->recv_file_write_fd_slots =
            aws_mem_calloc(allocator, loop_count, sizeof(*meta_request->recv_file_write_fd_slots));
        for (size_t i = 0; i < loop_count; ++i) {
            meta_request->recv_file_write_fd_slots[i].fd = AWS_FILE_INVALID_FD;
        }
        meta_request->recv_file_write_fd_slot_count = loop_count;

        AWS_LOGF_DEBUG(
            AWS_LS_S3_META_REQUEST,
            "id=%p: Out-of-order delivery available for download. direct_io=%d workers=%zu base_offset=%" PRIu64,
            (void *)meta_request,
            (int)direct_io,
            loop_count,
            base_offset);
    }

    return AWS_OP_SUCCESS;
}

int aws_s3_meta_request_init_base(
    struct aws_allocator *allocator,
    struct aws_s3_client *client,
    size_t part_size,
    bool should_compute_content_md5,
    bool should_default_streaming,
    const struct aws_s3_meta_request_options *options,
    void *impl,
    struct aws_s3_meta_request_vtable *vtable,
    struct aws_s3_meta_request *meta_request) {

    AWS_PRECONDITION(allocator);
    AWS_PRECONDITION(options);
    AWS_PRECONDITION(options->message);
    AWS_PRECONDITION(impl);
    AWS_PRECONDITION(meta_request);

    AWS_ZERO_STRUCT(*meta_request);

    AWS_ASSERT(vtable->update);
    AWS_ASSERT(vtable->prepare_request);
    AWS_ASSERT(vtable->destroy);
    AWS_ASSERT(vtable->sign_request);
    AWS_ASSERT(vtable->init_signing_date_time);
    AWS_ASSERT(vtable->finished_request);
    AWS_ASSERT(vtable->send_request_finish);

    meta_request->allocator = allocator;
    meta_request->type = options->type;

    /* Deep copy the file io options. */
    if (options->fio_opts) {
        meta_request->fio_opts = *options->fio_opts;
    } else if (client != NULL && client->fio_options_set) {
        meta_request->fio_opts = client->fio_opts;
    } else {
        /* Take a default options. */
        meta_request->fio_opts.should_stream = should_default_streaming;
    }

    if (meta_request->fio_opts.should_stream && meta_request->fio_opts.disk_throughput_gbps == 0) {
        /* If disk throughput is not set, set it to the default. */
        meta_request->fio_opts.disk_throughput_gbps = client->throughput_target_gbps;
    }

    /* Set up reference count. */
    aws_ref_count_init(&meta_request->ref_count, meta_request, s_s3_meta_request_destroy);
    aws_atomic_init_int(&meta_request->num_requests_network, 0);
    aws_atomic_init_int(&meta_request->num_request_being_prepared, 0);
    aws_linked_list_init(&meta_request->synced_data.cancellable_http_streams_list);
    aws_linked_list_init(&meta_request->synced_data.pending_buffer_futures);
    aws_atomic_init_int(&meta_request->recv_file_direct_io_fallback_count, 0);
    /* Zero is a valid descriptor, so the sentinel has to be written explicitly over the calloc. */
    meta_request->recv_file_ordered_fds.fd = AWS_FILE_INVALID_FD;
    /* Every part, including part 1, extends the contiguous written prefix. */
    meta_request->synced_data.next_contiguous_delivered_part = 1;
    meta_request->out_of_order_delivery_override = options->out_of_order_delivery;
    /* Only an auto-ranged GET ever resolves this, at discovery. Everything else stays in object order. */
    aws_atomic_init_int(&meta_request->out_of_order_delivery, 0);

    if (part_size == SIZE_MAX) {
        aws_raise_error(AWS_ERROR_INVALID_ARGUMENT);
        goto error;
    }

    if (meta_request->fio_opts.should_stream && options->checksum_config &&
        options->checksum_config->location == AWS_SCL_HEADER) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p: Invalid meta request configuration - Cannot use checksum via header with streaming upload.",
            (void *)meta_request);
        aws_raise_error(AWS_ERROR_INVALID_ARGUMENT);
        goto error;
    }

    if (options->body_callback != NULL && options->body_callback_ex != NULL) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p Invalid meta request configuration - body and body_ex callbacks cannot be both set at the same time",
            (void *)meta_request);
        aws_raise_error(AWS_ERROR_INVALID_ARGUMENT);
        goto error;
    }

    if (aws_mutex_init(&meta_request->synced_data.lock)) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST, "id=%p Could not initialize mutex for meta request", (void *)meta_request);
        goto error;
    }

    if (aws_priority_queue_init_dynamic(
            &meta_request->synced_data.pending_body_streaming_requests,
            meta_request->allocator,
            s_default_body_streaming_priority_queue_size,
            sizeof(struct aws_s3_request *),
            s_s3_request_priority_queue_pred)) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST, "id=%p Could not initialize priority queue for meta request", (void *)meta_request);
        /* Priority queue */
        goto error;
    }

    if (aws_priority_queue_init_dynamic(
            &meta_request->synced_data.completed_deliveries_tracker,
            meta_request->allocator,
            s_default_body_streaming_priority_queue_size,
            sizeof(struct aws_s3_delivery_tracking_record),
            s_s3_delivery_tracking_record_pred)) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p Could not initialize completed-write queue for meta request",
            (void *)meta_request);
        goto error;
    }

    aws_array_list_init_dynamic(
        &meta_request->synced_data.event_delivery_array,
        meta_request->allocator,
        s_default_event_delivery_array_size,
        sizeof(struct aws_s3_meta_request_event));
    aws_array_list_init_dynamic(
        &meta_request->io_threaded_data.event_delivery_array,
        meta_request->allocator,
        s_default_event_delivery_array_size,
        sizeof(struct aws_s3_meta_request_event));

    aws_priority_queue_init_dynamic(
        &meta_request->io_threaded_data.pending_put_prepare_queue,
        meta_request->allocator,
        0,
        sizeof(struct aws_s3_pending_prepare_entry),
        s_s3_pending_prepare_entry_pred);
    meta_request->io_threaded_data.next_put_part_to_prepare = 1;

    *((size_t *)&meta_request->part_size) = part_size;
    *((uint32_t *)&meta_request->max_active_connections_override) = options->max_active_connections_override;
    *((bool *)&meta_request->should_compute_content_md5) = should_compute_content_md5;
    if (aws_s3_meta_request_checksum_config_storage_init(
            meta_request->allocator,
            &meta_request->checksum_config,
            options->checksum_config,
            options->message,
            (void *)meta_request)) {
        goto error;
    }

    if (s_meta_request_init_expected_checksum(meta_request, options)) {
        goto error;
    }

    if (options->signing_config) {
        meta_request->cached_signing_config = aws_cached_signing_config_new(client, options->signing_config);
    }

    /* Client is currently optional to allow spinning up a meta_request without a client in a test. */
    if (client != NULL) {
        meta_request->client = aws_s3_client_acquire(client);
        meta_request->io_event_loop = aws_event_loop_group_get_next_loop(client->body_streaming_elg);
        meta_request->synced_data.read_window_running_total = client->initial_read_window;
        meta_request->feature_ids = client->feature_ids;

        /* Al: tag only the first HTTP request of the first meta-request, not every part.
         * Stored on the client (first meta-request) and meta-request (first part). */
        if (!client->first_operation_emitted) {
            client->first_operation_emitted = true;
            meta_request->first_request_for_new_client = true;
        }
    }

    /* Per-request feature IDs for the User-Agent m/ section. Derived from what the caller asked for
     * in the options, not from how it was implemented, so they don't depend on internal plumbing. */
    if (options->send_filepath.len > 0 || options->recv_filepath.len > 0) {
        /* Transfer is file-based (either direction) rather than stream/callback-based. */
        meta_request->feature_ids |= AWS_S3_FEATURE_ID_FILE_PATH;
    }
    if (options->part_size != 0 && options->part_size != g_default_part_size_fallback) {
        /* Caller overrode part size for this meta request AND it differs from the 8 MiB default.
         * Uses options->part_size (the caller's value) rather than the resolved part_size argument,
         * which may have been auto-adjusted for large objects; that adjustment is not caller config. */
        meta_request->feature_ids |= AWS_S3_FEATURE_ID_CUSTOM_PART_SIZE;
    }

    /* Keep original message around, for headers, method, and synchronous body-stream (if any) */
    meta_request->initial_request_message = aws_http_message_acquire(options->message);

    /* Build the cached User-Agent header now that feature_ids and initial_request_message are set.
     * Per-part stamping will copy this cache instead of re-parsing the SDK header on each request. */
    aws_s3_init_user_agent_header_cached(meta_request);

    if (s_s3_meta_request_init_recv_file(meta_request, options, part_size) != AWS_OP_SUCCESS) {
        goto error;
    }

    /* If the request's body is being passed in some other way, set that up.
     * (we checked earlier that the request body is not being passed multiple ways) */
    if (options->send_filepath.len > 0) {
        /* For upload with direct_io, check platform support proactively.
         * If not supported, silently disable direct_io for the upload stream. */
        bool upload_direct_io = meta_request->fio_opts.direct_io;
        if (upload_direct_io && !aws_file_direct_io_is_supported()) {
            AWS_LOGF_WARN(
                AWS_LS_S3_META_REQUEST,
                "id=%p: O_DIRECT is not supported on this platform. Upload will use buffered I/O.",
                (void *)meta_request);
            upload_direct_io = false;
        }

        /* Create parallel read stream from file.
         * TODO: pass client->file_io_elg here instead of body_streaming_elg. Reading the upload
         * source file is file I/O and belongs on the same dedicated pool as the download writes, so
         * a slow disk read cannot stall body delivery or user callbacks. Left as-is for now because
         * this stream's reads and the request preparation that drives them currently share
         * body_streaming_elg (see s_s3_meta_request_schedule_prepare_request_default), and splitting
         * only the reads off needs that relationship re-examined first. */
        meta_request->request_body_parallel_stream = client->vtable->parallel_input_stream_new_from_file(
            allocator, options->send_filepath, client->body_streaming_elg, upload_direct_io);
        if (meta_request->request_body_parallel_stream == NULL) {
            goto error;
        }

    } else if (options->send_async_stream != NULL) {
        meta_request->request_body_async_stream = aws_async_input_stream_acquire(options->send_async_stream);

    } else if (options->send_using_async_writes == true) {
        meta_request->request_body_using_async_writes = true;
    }

    meta_request->synced_data.next_streaming_part = 1;

    meta_request->user_data = options->user_data;
    meta_request->progress_callback = options->progress_callback;
    meta_request->telemetry_callback = options->telemetry_callback;
    meta_request->upload_review_callback = options->upload_review_callback;

    meta_request->headers_callback = options->headers_callback;
    meta_request->body_callback = options->body_callback;
    meta_request->body_callback_ex = options->body_callback_ex;
    meta_request->finish_callback = options->finish_callback;
    meta_request->on_error_resume_token = options->on_error_resume_token;

    /* Nothing can fail after here. Leave the impl not affected by failure of initializing base. */
    meta_request->impl = impl;
    meta_request->vtable = vtable;

    return AWS_OP_SUCCESS;
error:
    s_s3_meta_request_destroy((void *)meta_request);
    return AWS_OP_ERR;
}

void aws_s3_meta_request_increment_read_window(struct aws_s3_meta_request *meta_request, uint64_t bytes) {
    AWS_PRECONDITION(meta_request);

    if (bytes == 0) {
        return;
    }

    if (!meta_request->client->enable_read_backpressure) {
        AWS_LOGF_DEBUG(
            AWS_LS_S3_META_REQUEST,
            "id=%p: Ignoring call to increment read window. This client has not enabled read backpressure.",
            (void *)meta_request);
        return;
    }

    AWS_LOGF_TRACE(AWS_LS_S3_META_REQUEST, "id=%p: Incrementing read window by %" PRIu64, (void *)meta_request, bytes);

    /* BEGIN CRITICAL SECTION */
    aws_s3_meta_request_lock_synced_data(meta_request);

    /* Response will never approach UINT64_MAX, so do a saturating sum instead of worrying about overflow */
    meta_request->synced_data.read_window_running_total =
        aws_add_u64_saturating(bytes, meta_request->synced_data.read_window_running_total);
    /* Try to schedule the delivery task again. */
    aws_s3_meta_request_add_event_for_delivery_synced(meta_request, NULL);

    aws_s3_meta_request_unlock_synced_data(meta_request);
    /* END CRITICAL SECTION */

    /* Schedule the work task, to continue processing the meta-request */
    aws_s3_client_schedule_process_work(meta_request->client);
}

void aws_s3_meta_request_cancel(struct aws_s3_meta_request *meta_request) {
    /* BEGIN CRITICAL SECTION */
    aws_s3_meta_request_lock_synced_data(meta_request);
    aws_s3_meta_request_set_fail_synced(meta_request, NULL, AWS_ERROR_S3_CANCELED);
    aws_s3_meta_request_cancel_cancellable_requests_synced(meta_request, AWS_ERROR_S3_CANCELED);
    aws_s3_meta_request_cancel_pending_buffer_futures_synced(meta_request, AWS_ERROR_S3_CANCELED);
    aws_s3_meta_request_unlock_synced_data(meta_request);
    /* END CRITICAL SECTION */

    /* Schedule the work task, to continue processing the meta-request */
    aws_s3_client_schedule_process_work(meta_request->client);
}

int aws_s3_meta_request_pause(
    struct aws_s3_meta_request *meta_request,
    struct aws_s3_meta_request_resume_token **out_resume_token) {
    AWS_ERROR_PRECONDITION(meta_request);
    AWS_ERROR_PRECONDITION(meta_request->vtable);

    *out_resume_token = NULL;

    if (!meta_request->vtable->pause) {
        return aws_raise_error(AWS_ERROR_UNSUPPORTED_OPERATION);
    }

    return meta_request->vtable->pause(meta_request, out_resume_token);
}

int aws_s3_meta_request_pause_async(
    struct aws_s3_meta_request *meta_request,
    aws_s3_meta_request_pause_complete_fn *on_complete,
    void *user_data) {
    AWS_ERROR_PRECONDITION(meta_request);
    AWS_ERROR_PRECONDITION(on_complete);
    AWS_ERROR_PRECONDITION(meta_request->vtable);

    if (!meta_request->vtable->build_resume_token_synced) {
        return aws_raise_error(AWS_ERROR_UNSUPPORTED_OPERATION);
    }

    /* BEGIN CRITICAL SECTION */
    aws_s3_meta_request_lock_synced_data(meta_request);

    if (meta_request->synced_data.async_pause_requested) {
        aws_s3_meta_request_unlock_synced_data(meta_request);
        /* Invoke callback immediately — pause already in progress */
        on_complete(meta_request, NULL, AWS_ERROR_INVALID_STATE, user_data);
        return AWS_OP_SUCCESS;
    }

    meta_request->synced_data.async_pause_requested = true;
    meta_request->synced_data.pause_complete_callback = on_complete;
    meta_request->synced_data.pause_complete_user_data = user_data;

    /* Stop scheduling new work and cancel in-flight HTTP streams and pending buffer reservations */
    aws_s3_meta_request_set_fail_synced(meta_request, NULL, AWS_ERROR_S3_PAUSED);
    aws_s3_meta_request_cancel_cancellable_requests_synced(meta_request, AWS_ERROR_S3_PAUSED);
    aws_s3_meta_request_cancel_pending_buffer_futures_synced(meta_request, AWS_ERROR_S3_PAUSED);

    aws_s3_meta_request_unlock_synced_data(meta_request);
    /* END CRITICAL SECTION */

    /* Schedule work processing so the update loop can wind down and finish */
    aws_s3_client_schedule_process_work(meta_request->client);

    return AWS_OP_SUCCESS;
}

void aws_s3_meta_request_set_fail_synced(
    struct aws_s3_meta_request *meta_request,
    struct aws_s3_request *failed_request,
    int error_code) {
    AWS_PRECONDITION(meta_request);
    ASSERT_SYNCED_DATA_LOCK_HELD(meta_request);

    /* Protect against bugs */
    if (error_code == AWS_ERROR_SUCCESS) {
        AWS_ASSERT(false);
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p Meta request failed but error code not set, AWS_ERROR_UNKNOWN will be reported",
            (void *)meta_request);
        error_code = AWS_ERROR_UNKNOWN;
    }

    if (meta_request->synced_data.finish_result_set) {
        return;
    }

    meta_request->synced_data.finish_result_set = true;

    if ((error_code == AWS_ERROR_S3_INVALID_RESPONSE_STATUS || error_code == AWS_ERROR_S3_NON_RECOVERABLE_ASYNC_ERROR ||
         error_code == AWS_ERROR_S3_OBJECT_MODIFIED) &&
        failed_request != NULL) {
        aws_s3_meta_request_result_setup(
            meta_request,
            &meta_request->synced_data.finish_result,
            failed_request,
            failed_request->send_data.response_status,
            error_code);
    } else {
        AWS_ASSERT(error_code != AWS_ERROR_S3_INVALID_RESPONSE_STATUS);

        aws_s3_meta_request_result_setup(meta_request, &meta_request->synced_data.finish_result, NULL, 0, error_code);
    }
}

void aws_s3_meta_request_set_success_synced(struct aws_s3_meta_request *meta_request, int response_status) {
    AWS_PRECONDITION(meta_request);
    ASSERT_SYNCED_DATA_LOCK_HELD(meta_request);

    if (meta_request->synced_data.finish_result_set) {
        return;
    }

    meta_request->synced_data.finish_result_set = true;

    aws_s3_meta_request_result_setup(
        meta_request, &meta_request->synced_data.finish_result, NULL, response_status, AWS_ERROR_SUCCESS);
}

bool aws_s3_meta_request_has_finish_result(struct aws_s3_meta_request *meta_request) {
    AWS_PRECONDITION(meta_request);

    /* BEGIN CRITICAL SECTION */
    aws_s3_meta_request_lock_synced_data(meta_request);
    bool is_finishing = aws_s3_meta_request_has_finish_result_synced(meta_request);
    aws_s3_meta_request_unlock_synced_data(meta_request);
    /* END CRITICAL SECTION */

    return is_finishing;
}

bool aws_s3_meta_request_has_finish_result_synced(struct aws_s3_meta_request *meta_request) {
    AWS_PRECONDITION(meta_request);
    ASSERT_SYNCED_DATA_LOCK_HELD(meta_request);

    if (!meta_request->synced_data.finish_result_set) {
        return false;
    }

    return true;
}

struct aws_s3_meta_request *aws_s3_meta_request_acquire(struct aws_s3_meta_request *meta_request) {
    AWS_PRECONDITION(meta_request);

    aws_ref_count_acquire(&meta_request->ref_count);
    return meta_request;
}

struct aws_s3_meta_request *aws_s3_meta_request_release(struct aws_s3_meta_request *meta_request) {
    if (meta_request != NULL) {
        aws_ref_count_release(&meta_request->ref_count);
    }

    return NULL;
}

static void s_s3_meta_request_destroy(void *user_data) {
    struct aws_s3_meta_request *meta_request = user_data;
    AWS_PRECONDITION(meta_request);
    void *log_id = meta_request;

    AWS_LOGF_DEBUG(AWS_LS_S3_META_REQUEST, "id=%p Cleaning up meta request", (void *)meta_request);

    /* Clean up our initial http message */
    aws_s3_meta_request_checksum_config_storage_cleanup(&meta_request->checksum_config);
    meta_request->request_body_async_stream = aws_async_input_stream_release(meta_request->request_body_async_stream);
    if (meta_request->request_body_parallel_stream != NULL) {
        struct aws_future_void *shutdown_future =
            aws_parallel_input_stream_get_shutdown_future(meta_request->request_body_parallel_stream);
        aws_parallel_input_stream_release(meta_request->request_body_parallel_stream);
        meta_request->request_body_parallel_stream = NULL;
        aws_future_void_wait(shutdown_future, MAX_TIMEOUT_NS_P);
        aws_future_void_release(shutdown_future);
    }
    meta_request->initial_request_message = aws_http_message_release(meta_request->initial_request_message);

    void *meta_request_user_data = meta_request->user_data;
    aws_s3_meta_request_shutdown_fn *shutdown_callback = meta_request->shutdown_callback;

    aws_byte_buf_clean_up(&meta_request->cached_user_agent);
    aws_cached_signing_config_destroy(meta_request->cached_signing_config);
    aws_string_destroy(meta_request->s3express_session_host);
    aws_mutex_clean_up(&meta_request->synced_data.lock);
    aws_mem_release(meta_request->allocator, meta_request->synced_data.parts_delivered_mask);
    /* endpoint should have already been released and set NULL by the meta request finish call.
     * But call release() again, just in case we're tearing down a half-initialized meta request */
    aws_s3_endpoint_release(meta_request->endpoint);
    /* Close the write descriptors before anything looks at the file, so every byte is out of our hands
     * before a delete-on-failure. Safe to do unlocked: each pending write holds a meta request ref, so
     * none are outstanding by the time we get here. */
    s_s3_meta_request_close_write_fds(meta_request);

    /* Not finalized means the finish call never ran, so creation failed after the file was opened. */
    if (meta_request->recv_filepath != NULL && meta_request->recv_file_delete_on_failure &&
        !meta_request->recv_file_finalized) {
        aws_file_delete(meta_request->recv_filepath);
    }
    aws_string_destroy(meta_request->recv_filepath);

    /* Client may be NULL if meta request failed mid-creation (or this some weird testing mock with no client) */
    if (meta_request->client != NULL) {
        if (meta_request->buffer_pool_optimized) {
            aws_s3_buffer_pool_release_special_size(meta_request->client->buffer_pool, meta_request->part_size);
        }
        aws_s3_buffer_ticket_release(meta_request->synced_data.async_write.buffered_data_ticket);
        /* pending buffer acquisition will keep meta request alive from destroying.  */
        AWS_ASSERT(meta_request->synced_data.async_write.buffered_data_ticket_future == NULL);
        meta_request->client = aws_s3_client_release(meta_request->client);
    }

    AWS_ASSERT(aws_priority_queue_size(&meta_request->synced_data.pending_body_streaming_requests) == 0);
    aws_priority_queue_clean_up(&meta_request->synced_data.pending_body_streaming_requests);

    aws_priority_queue_clean_up(&meta_request->synced_data.completed_deliveries_tracker);

    /* Slots own nothing, so a cancelled or failed meta request can just drop them. */
    aws_mem_release(meta_request->allocator, meta_request->combine_slots);
    meta_request->combine_slots = NULL;
    meta_request->combine_slot_count = 0;

    /* Normally the finish call tears the meta-request-level checksum down. A meta request that was seeded with a
     * caller-supplied checksum and then failed mid-creation never gets that far, so clean up here too. */
    aws_checksum_destroy(meta_request->meta_request_level_running_response_sum);
    meta_request->meta_request_level_running_response_sum = NULL;
    aws_byte_buf_clean_up(&meta_request->meta_request_level_response_header_checksum);

    AWS_ASSERT(aws_array_list_length(&meta_request->synced_data.event_delivery_array) == 0);
    aws_array_list_clean_up(&meta_request->synced_data.event_delivery_array);

    AWS_ASSERT(aws_array_list_length(&meta_request->io_threaded_data.event_delivery_array) == 0);
    aws_array_list_clean_up(&meta_request->io_threaded_data.event_delivery_array);

    AWS_ASSERT(aws_priority_queue_size(&meta_request->io_threaded_data.pending_put_prepare_queue) == 0);
    aws_priority_queue_clean_up(&meta_request->io_threaded_data.pending_put_prepare_queue);

    AWS_ASSERT(aws_linked_list_empty(&meta_request->synced_data.cancellable_http_streams_list));
    AWS_ASSERT(aws_linked_list_empty(&meta_request->synced_data.pending_buffer_futures));

    aws_s3_meta_request_result_clean_up(meta_request, &meta_request->synced_data.finish_result);

    if (meta_request->vtable != NULL) {
        AWS_LOGF_TRACE(AWS_LS_S3_META_REQUEST, "id=%p Calling virtual meta request destroy function.", log_id);
        meta_request->vtable->destroy(meta_request);
    }
    meta_request = NULL;

    if (shutdown_callback != NULL) {
        AWS_LOGF_TRACE(AWS_LS_S3_META_REQUEST, "id=%p Calling meta request shutdown callback.", log_id);
        shutdown_callback(meta_request_user_data);
    }

    AWS_LOGF_TRACE(AWS_LS_S3_META_REQUEST, "id=%p Meta request clean up finished.", log_id);
}

static int s_s3_request_priority_queue_pred(const void *a, const void *b) {
    const struct aws_s3_request *const *request_a = a;
    AWS_PRECONDITION(request_a);
    AWS_PRECONDITION(*request_a);

    const struct aws_s3_request *const *request_b = b;
    AWS_PRECONDITION(request_b);
    AWS_PRECONDITION(*request_b);

    return (*request_a)->part_number > (*request_b)->part_number;
}

static int s_s3_delivery_tracking_record_pred(const void *a, const void *b) {
    const struct aws_s3_delivery_tracking_record *delivery_a = a;
    const struct aws_s3_delivery_tracking_record *delivery_b = b;
    AWS_PRECONDITION(delivery_a);
    AWS_PRECONDITION(delivery_b);

    return delivery_a->part_number > delivery_b->part_number;
}

/* Close every descriptor opened for writing parts. Idempotent. */
static void s_s3_recv_file_fds_close(struct aws_s3_recv_file_fds *fds) {
    aws_file_close_fd(fds->fd);
    fds->fd = AWS_FILE_INVALID_FD;
    fds->direct = false;
    fds->open_attempted = false;
}

static void s_s3_meta_request_close_write_fds(struct aws_s3_meta_request *meta_request) {
    if (meta_request->recv_file_write_fd_slots != NULL) {
        for (size_t i = 0; i < meta_request->recv_file_write_fd_slot_count; ++i) {
            s_s3_recv_file_fds_close(&meta_request->recv_file_write_fd_slots[i]);
        }
        aws_mem_release(meta_request->allocator, meta_request->recv_file_write_fd_slots);
        meta_request->recv_file_write_fd_slots = NULL;
        meta_request->recv_file_write_fd_slot_count = 0;
    }

    s_s3_recv_file_fds_close(&meta_request->recv_file_ordered_fds);
}

/* Records one finished part's digest so it can be folded into the whole-object checksum at finish.
 *
 * No lock: the slot array was sized before any part was dispatched and is never resized, and this part owns
 * its slot exclusively. See the combine_slots declaration for why the write is visible to the fold. */
static void s_s3_meta_request_record_part_digest(
    struct aws_s3_meta_request *meta_request,
    uint32_t part_number,
    const struct aws_byte_buf *digest,
    uint64_t length) {

    AWS_PRECONDITION(meta_request);
    AWS_PRECONDITION(digest);
    AWS_PRECONDITION(part_number > 0);
    AWS_FATAL_ASSERT(digest->len > 0 && digest->len <= AWS_S3_COMBINABLE_DIGEST_MAX_LEN);

    if (part_number > meta_request->combine_slot_count) {
        /* More parts turned up than the discovery response accounted for. Leave the slots alone; the fold at
         * finish will report the whole-object checksum as unvalidated rather than assembling a partial sum. */
        AWS_LOGF_WARN(
            AWS_LS_S3_META_REQUEST,
            "id=%p Part %" PRIu32 " is beyond the %" PRIu32 " parts discovered, so its checksum cannot "
            "contribute to the whole-object checksum.",
            (void *)meta_request,
            part_number,
            meta_request->combine_slot_count);
        return;
    }

    struct aws_s3_combine_slot *slot = &meta_request->combine_slots[part_number - 1];
    slot->length = length;
    memcpy(slot->digest, digest->buffer, digest->len);
    slot->digest_len = digest->len;
}

/* Assembles the whole-object checksum from the recorded part digests. Returns false, leaving the running sum
 * untouched, if any part never recorded one.
 *
 * CRCs compose: folding part digests left to right in object order yields exactly the checksum of the
 * concatenated object, so no thread re-reads the body. Slots are already in object order, so this is a single
 * forward pass.
 *
 * No lock, and none needed: by the time the meta request finishes, update() has confirmed every dispatched
 * part completed, so all slot writes are done and published. */
static bool s_s3_meta_request_fold_combine_slots(struct aws_s3_meta_request *meta_request) {
    AWS_PRECONDITION(meta_request);

    struct aws_s3_checksum *running_sum = meta_request->meta_request_level_running_response_sum;
    AWS_FATAL_ASSERT(running_sum != NULL);

    if (meta_request->combine_slots == NULL || meta_request->combine_slot_count == 0) {
        AWS_LOGF_WARN(
            AWS_LS_S3_META_REQUEST,
            "id=%p No part checksums were recorded, so the whole-object checksum cannot be validated.",
            (void *)meta_request);
        return false;
    }

    for (uint32_t i = 0; i < meta_request->combine_slot_count; ++i) {
        const struct aws_s3_combine_slot *slot = &meta_request->combine_slots[i];
        if (slot->digest_len == 0) {
            AWS_LOGF_WARN(
                AWS_LS_S3_META_REQUEST,
                "id=%p Part %" PRIu32 " never recorded a checksum, so the whole-object checksum cannot be "
                "validated.",
                (void *)meta_request,
                i + 1);
            return false;
        }
        if (aws_checksum_combine_digest(
                running_sum, aws_byte_cursor_from_array(slot->digest, slot->digest_len), slot->length)) {
            AWS_LOGF_ERROR(
                AWS_LS_S3_META_REQUEST,
                "id=%p Failed to combine checksum for part %" PRIu32 ". last error:%s",
                (void *)meta_request,
                i + 1,
                aws_error_name(aws_last_error_or_unknown()));
            return false;
        }
    }

    return true;
}

int aws_s3_meta_request_setup_checksum_combine_synced(
    struct aws_s3_meta_request *meta_request,
    struct aws_s3_request *discovery_request,
    uint32_t total_num_parts) {

    AWS_ERROR_PRECONDITION(meta_request);
    AWS_ERROR_PRECONDITION(discovery_request);
    ASSERT_SYNCED_DATA_LOCK_HELD(meta_request);

    meta_request->meta_request_level_checksum_combinable = false;

    if (meta_request->meta_request_level_running_response_sum == NULL) {
        /* Nothing to validate at the meta request level. */
        return AWS_OP_SUCCESS;
    }

    enum aws_s3_checksum_algorithm algorithm = meta_request->meta_request_level_running_response_sum->algorithm;
    if (!aws_checksum_algorithm_is_combinable(algorithm)) {
        /* Leave it to the delivery loop, which sees the body in object order. */
        return AWS_OP_SUCCESS;
    }
    if (total_num_parts == 0) {
        /* An empty object, so there is nothing to combine. */
        return AWS_OP_SUCCESS;
    }

    AWS_FATAL_ASSERT(meta_request->combine_slots == NULL);
    meta_request->combine_slots =
        aws_mem_calloc(meta_request->allocator, total_num_parts, sizeof(struct aws_s3_combine_slot));
    meta_request->combine_slot_count = total_num_parts;
    meta_request->meta_request_level_checksum_combinable = true;

    /* From here on, each part checksums itself as it streams. The discovery request is the exception: if it
     * carried body bytes, they arrived before we knew which algorithm to use, so checksum that one part from
     * its buffer now. A HEAD discovery has no body and needs nothing. */
    if (discovery_request->part_number == 0 || discovery_request->send_data.response_body.len == 0) {
        return AWS_OP_SUCCESS;
    }

    struct aws_s3_checksum *part_sum = aws_checksum_new(meta_request->allocator, algorithm);
    if (part_sum == NULL) {
        return AWS_OP_ERR;
    }

    struct aws_byte_cursor body = aws_byte_cursor_from_buf(&discovery_request->send_data.response_body);
    uint8_t digest_storage[AWS_S3_COMBINABLE_DIGEST_MAX_LEN];
    struct aws_byte_buf part_digest = aws_byte_buf_from_empty_array(digest_storage, sizeof(digest_storage));

    if (aws_checksum_update(part_sum, &body) || aws_checksum_finalize(part_sum, &part_digest)) {
        aws_checksum_destroy(part_sum);
        return AWS_OP_ERR;
    }
    aws_checksum_destroy(part_sum);

    s_s3_meta_request_record_part_digest(meta_request, discovery_request->part_number, &part_digest, body.len);
    return AWS_OP_SUCCESS;
}

static int s_s3_pending_prepare_entry_pred(const void *a, const void *b) {
    const struct aws_s3_pending_prepare_entry *entry_a = a;
    const struct aws_s3_pending_prepare_entry *entry_b = b;
    return entry_a->request->part_number > entry_b->request->part_number;
}

bool aws_s3_meta_request_update(
    struct aws_s3_meta_request *meta_request,
    uint32_t flags,
    struct aws_s3_request **out_request) {
    AWS_PRECONDITION(meta_request);
    AWS_PRECONDITION(meta_request->vtable);
    AWS_PRECONDITION(meta_request->vtable->update);

    return meta_request->vtable->update(meta_request, flags, out_request);
}

bool aws_s3_meta_request_is_active(struct aws_s3_meta_request *meta_request) {
    AWS_PRECONDITION(meta_request);

    /* BEGIN CRITICAL SECTION */
    aws_s3_meta_request_lock_synced_data(meta_request);
    bool active = meta_request->synced_data.state == AWS_S3_META_REQUEST_STATE_ACTIVE;
    aws_s3_meta_request_unlock_synced_data(meta_request);
    /* END CRITICAL SECTION */

    return active;
}

bool aws_s3_meta_request_is_finished(struct aws_s3_meta_request *meta_request) {
    AWS_PRECONDITION(meta_request);

    /* BEGIN CRITICAL SECTION */
    aws_s3_meta_request_lock_synced_data(meta_request);
    bool is_finished = meta_request->synced_data.state == AWS_S3_META_REQUEST_STATE_FINISHED;
    aws_s3_meta_request_unlock_synced_data(meta_request);
    /* END CRITICAL SECTION */

    return is_finished;
}

/* TODO: document how this is final step in prepare-request sequence.
 * Could be invoked on any thread. */
static void s_s3_prepare_request_payload_callback_and_destroy(
    struct aws_s3_prepare_request_payload *payload,
    int error_code) {
    AWS_PRECONDITION(payload);
    AWS_PRECONDITION(payload->request);

    struct aws_s3_meta_request *meta_request = payload->request->meta_request;
    AWS_PRECONDITION(meta_request);

    ++payload->request->num_times_prepared;

    if (error_code) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p Could not prepare request %p due to error %d (%s).",
            (void *)meta_request,
            (void *)payload->request,
            error_code,
            aws_error_str(error_code));

        /* BEGIN CRITICAL SECTION */
        aws_s3_meta_request_lock_synced_data(meta_request);
        aws_s3_meta_request_set_fail_synced(meta_request, payload->request, error_code);
        aws_s3_meta_request_unlock_synced_data(meta_request);
        /* END CRITICAL SECTION */
    }

    if (payload->callback != NULL) {
        payload->callback(meta_request, payload->request, error_code, payload->user_data);
    }

    aws_future_void_release(payload->asyncstep_prepare_request);
    aws_mem_release(payload->allocator, payload);
}

static void s_s3_meta_request_schedule_prepare_request_default(
    struct aws_s3_meta_request *meta_request,
    struct aws_s3_request *request,
    aws_s3_meta_request_prepare_request_callback_fn *callback,
    void *user_data) {
    /* By default, don't do any parallel. */
    aws_s3_meta_request_schedule_prepare_request_default_impl(
        meta_request, request, false /*parallel*/, callback, user_data);
}

void aws_s3_meta_request_prepare_request(
    struct aws_s3_meta_request *meta_request,
    struct aws_s3_request *request,
    aws_s3_meta_request_prepare_request_callback_fn *callback,
    void *user_data) {
    AWS_PRECONDITION(meta_request);
    AWS_PRECONDITION(meta_request->vtable);

    if (meta_request->vtable->schedule_prepare_request) {
        meta_request->vtable->schedule_prepare_request(meta_request, request, callback, user_data);
    } else {
        s_s3_meta_request_schedule_prepare_request_default(meta_request, request, callback, user_data);
    }
}

static void s_s3_meta_request_prepare_request_task(struct aws_task *task, void *arg, enum aws_task_status task_status);
static void s_s3_meta_request_on_request_prepared(void *user_data);

void aws_s3_meta_request_schedule_prepare_request_default_impl(
    struct aws_s3_meta_request *meta_request,
    struct aws_s3_request *request,
    bool parallel,
    aws_s3_meta_request_prepare_request_callback_fn *callback,
    void *user_data) {
    AWS_PRECONDITION(meta_request);
    AWS_PRECONDITION(request);

    struct aws_s3_client *client = meta_request->client;
    AWS_PRECONDITION(client);

    struct aws_allocator *allocator = client->allocator;
    AWS_PRECONDITION(allocator);

    struct aws_s3_prepare_request_payload *payload =
        aws_mem_calloc(allocator, 1, sizeof(struct aws_s3_prepare_request_payload));

    payload->allocator = allocator;
    payload->request = request;
    payload->callback = callback;
    payload->user_data = user_data;

    aws_task_init(
        &payload->task, s_s3_meta_request_prepare_request_task, payload, "s3_meta_request_prepare_request_task");

    if (parallel) {
        /* To support reading in parallel, schedule task on any I/O thread in the streaming elg.
         * Otherwise, we wouldn't get any parallelism. */
        struct aws_event_loop *loop = aws_event_loop_group_get_next_loop(client->body_streaming_elg);
        aws_event_loop_schedule_task_now(loop, &payload->task);
    } else {
        aws_event_loop_schedule_task_now(meta_request->io_event_loop, &payload->task);
    }
}

static void s_s3_meta_request_prepare_request_task(struct aws_task *task, void *arg, enum aws_task_status task_status) {
    (void)task;
    (void)task_status;

    struct aws_s3_prepare_request_payload *payload = arg;
    AWS_PRECONDITION(payload);

    struct aws_s3_request *request = payload->request;
    AWS_PRECONDITION(request);

    struct aws_s3_meta_request *meta_request = request->meta_request;
    AWS_PRECONDITION(meta_request);

    const struct aws_s3_meta_request_vtable *vtable = meta_request->vtable;
    AWS_PRECONDITION(vtable);

    /* Client owns this event loop group. A cancel should not be possible. */
    AWS_ASSERT(task_status == AWS_TASK_STATUS_RUN_READY);

    if (!request->always_send && aws_s3_meta_request_has_finish_result(meta_request)) {
        s_s3_prepare_request_payload_callback_and_destroy(payload, AWS_ERROR_S3_CANCELED);
        return;
    }

    /* Kick off the async vtable->prepare_request()
     * Each subclass has its own implementation of this. */
    payload->asyncstep_prepare_request = vtable->prepare_request(request);
    aws_future_void_register_callback(
        payload->asyncstep_prepare_request, s_s3_meta_request_on_request_prepared, payload);
    return;
}

/* Called after vtable->prepare_request has succeeded or failed. */
static void s_s3_meta_request_on_request_prepared(void *user_data) {
    struct aws_s3_prepare_request_payload *payload = user_data;
    struct aws_s3_request *request = payload->request;
    struct aws_s3_meta_request *meta_request = request->meta_request;

    int error_code = aws_future_void_get_error(payload->asyncstep_prepare_request);
    if (error_code) {
        s_s3_prepare_request_payload_callback_and_destroy(payload, error_code);
        return;
    }

    aws_s3_apply_user_agent_header(meta_request, request->send_data.message);

    /* Next step is to sign the newly created message (completion callback could happen on any thread) */
    s_s3_meta_request_sign_request(meta_request, request, s_s3_meta_request_request_on_signed, payload);
}

static void s_s3_meta_request_init_signing_date_time(
    struct aws_s3_meta_request *meta_request,
    struct aws_date_time *date_time) {
    AWS_PRECONDITION(meta_request);
    AWS_PRECONDITION(meta_request->vtable);
    AWS_PRECONDITION(meta_request->vtable->init_signing_date_time);

    meta_request->vtable->init_signing_date_time(meta_request, date_time);
}

void aws_s3_meta_request_init_signing_date_time_default(
    struct aws_s3_meta_request *meta_request,
    struct aws_date_time *date_time) {
    AWS_PRECONDITION(meta_request);
    AWS_PRECONDITION(date_time);
    (void)meta_request;

    aws_date_time_init_now(date_time);
}

static void s_s3_meta_request_sign_request(
    struct aws_s3_meta_request *meta_request,
    struct aws_s3_request *request,
    aws_signing_complete_fn *on_signing_complete,
    void *user_data) {
    AWS_PRECONDITION(meta_request);
    AWS_PRECONDITION(meta_request->vtable);
    AWS_PRECONDITION(meta_request->vtable->sign_request);

    if (request->send_data.metrics) {
        struct aws_s3_request_metrics *metric = request->send_data.metrics;
        aws_high_res_clock_get_ticks((uint64_t *)&metric->time_metrics.sign_start_timestamp_ns);
    }

    meta_request->vtable->sign_request(meta_request, request, on_signing_complete, user_data);
}

struct aws_get_s3express_credentials_user_data {
    /* Keep our own reference to allocator, because the meta request can be gone after the callback invoked. */
    struct aws_allocator *allocator;

    struct aws_s3_meta_request *meta_request;
    struct aws_s3_request *request;
    aws_signing_complete_fn *on_signing_complete;

    const struct aws_credentials *original_credentials;

    struct aws_signing_config_aws base_signing_config;
    struct aws_credentials_properties_s3express properties;
    void *user_data;
};

static void s_aws_get_s3express_credentials_user_data_destroy(struct aws_get_s3express_credentials_user_data *context) {
    aws_s3_meta_request_release(context->meta_request);
    aws_credentials_release(context->original_credentials);
    aws_mem_release(context->allocator, context);
}

static void s_get_s3express_credentials_callback(struct aws_credentials *credentials, int error_code, void *user_data) {
    struct aws_get_s3express_credentials_user_data *context = user_data;
    struct aws_signing_config_aws signing_config = context->base_signing_config;

    if (error_code) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p: Failed to get S3 Express credentials %p. due to error code %d (%s)",
            (void *)context->meta_request,
            (void *)context->request,
            error_code,
            aws_error_str(error_code));
        context->on_signing_complete(NULL, error_code, context->user_data);
        goto done;
    }
    s_s3_meta_request_init_signing_date_time(context->meta_request, &signing_config.date);
    /* Override the credentials */
    signing_config.credentials = credentials;
    signing_config.algorithm = AWS_SIGNING_ALGORITHM_V4_S3EXPRESS;
    if (aws_sign_request_aws(
            context->allocator,
            context->request->send_data.signable,
            (struct aws_signing_config_base *)&signing_config,
            context->on_signing_complete,
            context->user_data)) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p: Could not sign request %p. due to error code %d (%s)",
            (void *)context->meta_request,
            (void *)context->request,
            aws_last_error_or_unknown(),
            aws_error_str(aws_last_error_or_unknown()));
        context->on_signing_complete(NULL, aws_last_error_or_unknown(), context->user_data);
    }
done:
    s_aws_get_s3express_credentials_user_data_destroy(context);
}

static void s_get_original_credentials_callback(struct aws_credentials *credentials, int error_code, void *user_data) {
    struct aws_get_s3express_credentials_user_data *context = user_data;
    struct aws_s3_meta_request *meta_request = context->meta_request;
    if (error_code) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p: Failed to get S3 Express credentials %p. due to error code %d (%s)",
            (void *)context->meta_request,
            (void *)context->request,
            error_code,
            aws_error_str(error_code));
        context->on_signing_complete(NULL, error_code, context->user_data);
        s_aws_get_s3express_credentials_user_data_destroy(context);
        return;
    }
    context->original_credentials = credentials;
    aws_credentials_acquire(context->original_credentials);

    /**
     * Derive the credentials for S3 Express.
     */
    struct aws_s3_client *client = meta_request->client;
    if (aws_s3express_credentials_provider_get_credentials(
            client->s3express_provider,
            context->original_credentials,
            &context->properties,
            s_get_s3express_credentials_callback,
            context)) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p: Could not get S3 Express credentials %p",
            (void *)meta_request,
            (void *)context->request);
        context->on_signing_complete(NULL, aws_last_error_or_unknown(), user_data);
        s_aws_get_s3express_credentials_user_data_destroy(context);
    }
}

static void s_meta_request_resolve_signing_config(
    struct aws_signing_config_aws *out_signing_config,
    struct aws_s3_request *request,
    struct aws_s3_meta_request *meta_request) {
    struct aws_s3_client *client = meta_request->client;
    if (meta_request->cached_signing_config != NULL) {
        *out_signing_config = meta_request->cached_signing_config->config;

        if (out_signing_config->credentials == NULL && out_signing_config->credentials_provider == NULL) {
            /* When no credentials available from meta request level override, we use the credentials from client */
            out_signing_config->credentials = client->cached_signing_config->config.credentials;
            out_signing_config->credentials_provider = client->cached_signing_config->config.credentials_provider;
        }
    } else if (client->cached_signing_config != NULL) {
        *out_signing_config = client->cached_signing_config->config;
    } else {
        /* Not possible to have no cached signing config from both client and request */
        AWS_FATAL_ASSERT(false);
    }

    /* If the checksum is configured to be added to the trailer, the payload will be aws-chunked encoded. The
     * payload will need to be streaming signed/unsigned. */
    if (meta_request->checksum_config.location == AWS_SCL_TRAILER &&
        aws_byte_cursor_eq(&out_signing_config->signed_body_value, &g_aws_signed_body_value_unsigned_payload)) {
        out_signing_config->signed_body_value = g_aws_signed_body_value_streaming_unsigned_payload_trailer;
    }
    /* However the initial request for a multipart upload does not have a trailing checksum and is not chunked so it
     * must have an unsigned_payload signed_body value*/
    if (request->part_number == 0 &&
        aws_byte_cursor_eq(
            &out_signing_config->signed_body_value, &g_aws_signed_body_value_streaming_unsigned_payload_trailer)) {
        out_signing_config->signed_body_value = g_aws_signed_body_value_unsigned_payload;
    }

    /**
     * In case of the signing was skipped for anonymous credentials, or presigned URL.
     */
    request->send_data.require_streaming_unsigned_payload_header = aws_byte_cursor_eq(
        &out_signing_config->signed_body_value, &g_aws_signed_body_value_streaming_unsigned_payload_trailer);
}

void aws_s3_meta_request_sign_request_default_impl(
    struct aws_s3_meta_request *meta_request,
    struct aws_s3_request *request,
    aws_signing_complete_fn *on_signing_complete,
    void *user_data,
    bool disable_s3_express_signing) {
    AWS_PRECONDITION(meta_request);
    AWS_PRECONDITION(request);
    AWS_PRECONDITION(on_signing_complete);

    struct aws_s3_client *client = meta_request->client;
    AWS_ASSERT(client);

    struct aws_signing_config_aws signing_config;

    s_meta_request_resolve_signing_config(&signing_config, request, meta_request);

    request->send_data.signable = aws_signable_new_http_request(meta_request->allocator, request->send_data.message);
    if (request->send_data.signable == NULL) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p: Could not allocate signable for request %p",
            (void *)meta_request,
            (void *)request);

        on_signing_complete(NULL, aws_last_error_or_unknown(), user_data);
        return;
    }
    AWS_LOGF_TRACE(
        AWS_LS_S3_META_REQUEST,
        "id=%p Created signable %p for request %p with message %p",
        (void *)meta_request,
        (void *)request->send_data.signable,
        (void *)request,
        (void *)request->send_data.message);

    if (signing_config.algorithm == AWS_SIGNING_ALGORITHM_V4_S3EXPRESS && !disable_s3_express_signing) {
        /* Fetch credentials from S3 Express provider. */
        struct aws_get_s3express_credentials_user_data *context =
            aws_mem_calloc(meta_request->allocator, 1, sizeof(struct aws_get_s3express_credentials_user_data));

        context->allocator = meta_request->allocator;
        context->base_signing_config = signing_config;
        context->meta_request = aws_s3_meta_request_acquire(meta_request);
        context->on_signing_complete = on_signing_complete;
        context->request = request;
        context->user_data = user_data;
        context->properties.host = aws_byte_cursor_from_string(meta_request->s3express_session_host);
        context->properties.region = signing_config.region;
        context->properties.headers = aws_http_message_get_headers(meta_request->initial_request_message);

        if (signing_config.credentials) {
            context->original_credentials = signing_config.credentials;
            aws_credentials_acquire(context->original_credentials);
            /**
             * Derive the credentials for S3 Express.
             */
            if (aws_s3express_credentials_provider_get_credentials(
                    client->s3express_provider,
                    context->original_credentials,
                    &context->properties,
                    s_get_s3express_credentials_callback,
                    context)) {
                AWS_LOGF_ERROR(
                    AWS_LS_S3_META_REQUEST,
                    "id=%p: Could not get S3 Express credentials %p",
                    (void *)meta_request,
                    (void *)request);
                on_signing_complete(NULL, aws_last_error_or_unknown(), user_data);
                s_aws_get_s3express_credentials_user_data_destroy(context);
                return;
            }
        } else if (signing_config.credentials_provider) {
            /* Get the credentials from provider first. */
            if (aws_credentials_provider_get_credentials(
                    signing_config.credentials_provider, s_get_original_credentials_callback, context)) {
                AWS_LOGF_ERROR(
                    AWS_LS_S3_META_REQUEST,
                    "id=%p: Could not get S3 Express credentials %p",
                    (void *)meta_request,
                    (void *)request);
                on_signing_complete(NULL, aws_last_error_or_unknown(), user_data);
                s_aws_get_s3express_credentials_user_data_destroy(context);
                return;
            }
        }
    } else {
        /* Regular signing. */
        if (disable_s3_express_signing) {
            signing_config.algorithm = AWS_SIGNING_ALGORITHM_V4;
        }
        s_s3_meta_request_init_signing_date_time(meta_request, &signing_config.date);
        if (aws_sign_request_aws(
                meta_request->allocator,
                request->send_data.signable,
                (struct aws_signing_config_base *)&signing_config,
                on_signing_complete,
                user_data)) {

            AWS_LOGF_ERROR(
                AWS_LS_S3_META_REQUEST, "id=%p: Could not sign request %p", (void *)meta_request, (void *)request);

            on_signing_complete(NULL, aws_last_error_or_unknown(), user_data);
            return;
        }
    }
}

/* Handles signing a message for the caller. */
void aws_s3_meta_request_sign_request_default(
    struct aws_s3_meta_request *meta_request,
    struct aws_s3_request *request,
    aws_signing_complete_fn *on_signing_complete,
    void *user_data) {
    aws_s3_meta_request_sign_request_default_impl(meta_request, request, on_signing_complete, user_data, false);
}

/* Handle the signing result */
static void s_s3_meta_request_request_on_signed(
    struct aws_signing_result *signing_result,
    int error_code,
    void *user_data) {

    struct aws_s3_prepare_request_payload *payload = user_data;
    AWS_PRECONDITION(payload);

    struct aws_s3_request *request = payload->request;
    AWS_PRECONDITION(request);

    struct aws_s3_meta_request *meta_request = request->meta_request;
    AWS_PRECONDITION(meta_request);

    if (error_code != AWS_ERROR_SUCCESS) {
        goto finish;
    }

    if (signing_result != NULL &&
        aws_apply_signing_result_to_http_request(request->send_data.message, meta_request->allocator, signing_result)) {

        error_code = aws_last_error_or_unknown();

        goto finish;
    }

    /**
     * Add "x-amz-content-sha256: STREAMING-UNSIGNED-PAYLOAD-TRAILER" header to support trailing checksum.
     */
    if (request->send_data.require_streaming_unsigned_payload_header) {
        struct aws_http_headers *headers = aws_http_message_get_headers(request->send_data.message);
        AWS_ASSERT(headers != NULL);
        if (aws_http_headers_set(
                headers,
                aws_byte_cursor_from_c_str("x-amz-content-sha256"),
                g_aws_signed_body_value_streaming_unsigned_payload_trailer)) {
            error_code = aws_last_error_or_unknown();
            goto finish;
        }
    }

    if (request->send_data.metrics) {
        struct aws_s3_request_metrics *metric = request->send_data.metrics;
        aws_high_res_clock_get_ticks((uint64_t *)&metric->time_metrics.sign_end_timestamp_ns);
        AWS_ASSERT(metric->time_metrics.sign_start_timestamp_ns != 0);
        metric->time_metrics.signing_duration_ns =
            metric->time_metrics.sign_end_timestamp_ns - metric->time_metrics.sign_start_timestamp_ns;
    }

finish:

    if (error_code != AWS_ERROR_SUCCESS) {

        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p Meta request could not sign HTTP request due to error code %d (%s)",
            (void *)meta_request,
            error_code,
            aws_error_str(error_code));
    }

    s_s3_prepare_request_payload_callback_and_destroy(payload, error_code);
}

void aws_s3_meta_request_send_request(struct aws_s3_meta_request *meta_request, struct aws_s3_connection *connection) {
    AWS_PRECONDITION(meta_request);
    AWS_PRECONDITION(connection);
    AWS_PRECONDITION(connection->http_connection);

    struct aws_s3_client *client = meta_request->client;
    AWS_PRECONDITION(client);
    struct aws_s3_request *request = connection->request;
    AWS_PRECONDITION(request);

    /* Now that we have a signed request and a connection, go ahead and issue the request. */
    struct aws_http_make_request_options options;
    AWS_ZERO_STRUCT(options);

    options.self_size = sizeof(struct aws_http_make_request_options);
    options.request = request->send_data.message;
    options.user_data = connection;
    options.on_response_headers = s_s3_meta_request_incoming_headers;
    options.on_response_header_block_done = s_s3_meta_request_headers_block_done;
    options.on_response_body = s_s3_meta_request_incoming_body;
    if (request->send_data.metrics) {
        options.on_metrics = s_s3_meta_request_stream_metrics;
    }
    options.on_complete = s_s3_meta_request_stream_complete;
    if (request->request_type == AWS_S3_REQUEST_TYPE_UPLOAD_PART && !meta_request->is_express &&
        !client->disable_retries) {
        /* Note: For S3express, server responses random ETag. Killing the connection in the middle may cause server
         * receive two same part and result in confusing during complete MPU with etag doesn't match.
         * Disable the first byte timeout for s3 express.  */
        options.response_first_byte_timeout_ms = aws_atomic_load_int(&meta_request->client->upload_timeout_ms);
        request->upload_timeout_ms = (size_t)options.response_first_byte_timeout_ms;
    }

    struct aws_http_stream *stream =
        client->vtable->http_connection_make_request(connection->http_connection, &options);

    if (stream == NULL) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST, "id=%p: Could not make HTTP request %p", (void *)meta_request, (void *)request);

        goto error_finish;
    }

    AWS_LOGF_TRACE(AWS_LS_S3_META_REQUEST, "id=%p: Sending request %p", (void *)meta_request, (void *)request);

    if (!request->always_send) {
        /* BEGIN CRITICAL SECTION */
        aws_s3_meta_request_lock_synced_data(meta_request);
        if (aws_s3_meta_request_has_finish_result_synced(meta_request)) {
            /* The meta request has finish result already, for this request, treat it as canceled. */
            aws_raise_error(AWS_ERROR_S3_CANCELED);
            aws_s3_meta_request_unlock_synced_data(meta_request);
            goto error_finish;
        }

        /* Activate the stream within the lock as once the activate invoked, the HTTP level callback can happen
         * right after.  */
        if (aws_http_stream_activate(stream) != AWS_OP_SUCCESS) {
            aws_s3_meta_request_unlock_synced_data(meta_request);
            AWS_LOGF_ERROR(
                AWS_LS_S3_META_REQUEST,
                "id=%p: Could not activate HTTP stream %p",
                (void *)meta_request,
                (void *)request);
            goto error_finish;
        }
        aws_linked_list_push_back(
            &meta_request->synced_data.cancellable_http_streams_list, &request->cancellable_http_streams_list_node);
        request->synced_data.cancellable_http_stream = stream;

        aws_s3_meta_request_unlock_synced_data(meta_request);
        /* END CRITICAL SECTION */
    } else {
        /* If the request always send, it is not cancellable. We simply activate the stream. */
        if (aws_http_stream_activate(stream) != AWS_OP_SUCCESS) {
            AWS_LOGF_ERROR(
                AWS_LS_S3_META_REQUEST,
                "id=%p: Could not activate HTTP stream %p",
                (void *)meta_request,
                (void *)request);
            goto error_finish;
        }
    }
    return;

error_finish:
    if (stream) {
        aws_http_stream_release(stream);
        stream = NULL;
    }

    s_s3_meta_request_send_request_finish(connection, NULL, aws_last_error_or_unknown());
}

static int s_s3_meta_request_error_code_from_response_status(int response_status) {
    int error_code = AWS_ERROR_UNKNOWN;

    switch (response_status) {
        case AWS_HTTP_STATUS_CODE_200_OK:
        case AWS_HTTP_STATUS_CODE_206_PARTIAL_CONTENT:
        case AWS_HTTP_STATUS_CODE_204_NO_CONTENT:
            error_code = AWS_ERROR_SUCCESS;
            break;
        case AWS_HTTP_STATUS_CODE_500_INTERNAL_SERVER_ERROR:
        case AWS_HTTP_STATUS_CODE_502_BAD_GATEWAY:
        case AWS_HTTP_STATUS_CODE_504_GATEWAY_TIMEOUT:
            error_code = AWS_ERROR_S3_INTERNAL_ERROR;
            break;
        case AWS_HTTP_STATUS_CODE_503_SERVICE_UNAVAILABLE:
            /* S3 response 503 for throttling, slow down the sending */
            error_code = AWS_ERROR_S3_SLOW_DOWN;
            break;
        default:
            error_code = AWS_ERROR_S3_INVALID_RESPONSE_STATUS;
            break;
    }

    return error_code;
}

static bool s_header_value_from_list(
    const struct aws_http_header *headers,
    size_t headers_count,
    const struct aws_byte_cursor name,
    struct aws_byte_cursor *out_value) {
    for (size_t i = 0; i < headers_count; ++i) {
        if (aws_byte_cursor_eq(&headers[i].name, &name)) {
            *out_value = headers[i].value;
            return true;
        }
    }
    return false;
}

/* Capture the checksum this part's response carries, if it carries one we can use, so that the part's body can be
 * validated against it as it arrives. */
static void s_get_part_response_headers_checksum_helper(
    struct aws_s3_connection *connection,
    struct aws_s3_meta_request *meta_request,
    const struct aws_http_header *headers,
    size_t headers_count) {
    for (size_t i = 0; i < AWS_ARRAY_SIZE(s_checksum_algo_priority_list); i++) {
        enum aws_s3_checksum_algorithm algorithm = s_checksum_algo_priority_list[i];
        if (!aws_s3_meta_request_checksum_config_has_algorithm(meta_request, algorithm)) {
            /* If user doesn't select this algorithm, skip */
            continue;
        }
        const struct aws_byte_cursor algorithm_header_name =
            aws_get_http_header_name_from_checksum_algorithm(algorithm);
        struct aws_byte_cursor header_sum;
        if (s_header_value_from_list(headers, headers_count, algorithm_header_name, &header_sum)) {
            size_t encoded_len = 0;
            aws_base64_compute_encoded_len(aws_get_digest_size_from_checksum_algorithm(algorithm), &encoded_len);
            if (header_sum.len == encoded_len) {
                aws_byte_buf_init_copy_from_cursor(
                    &connection->request->request_level_response_header_checksum, meta_request->allocator, header_sum);
                connection->request->request_level_running_response_sum =
                    aws_checksum_new(meta_request->allocator, algorithm);
            }
            return;
        }
    }
}

/* Check to see if we need to create a request_level_combine_sum for combine the checksum for the full object */
static int s_ensure_part_combine_sum(struct aws_s3_meta_request *meta_request, struct aws_s3_request *request) {
    AWS_ERROR_PRECONDITION(meta_request);
    AWS_ERROR_PRECONDITION(request);

    if (request->request_level_combine_sum != NULL) {
        /* Already running, skipping. */
        return AWS_OP_SUCCESS;
    }
    if (request->part_number == 0) {
        /* Not a part, so it has no place in the object's byte order. */
        return AWS_OP_SUCCESS;
    }
    if (!meta_request->meta_request_level_checksum_combinable ||
        meta_request->meta_request_level_running_response_sum == NULL) {
        /* No track on the meta request level for combine the checksum */
        return AWS_OP_SUCCESS;
    }

    request->request_level_combine_sum =
        aws_checksum_new(meta_request->allocator, meta_request->meta_request_level_running_response_sum->algorithm);
    if (request->request_level_combine_sum == NULL) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p Could not create part checksum for request %p",
            (void *)meta_request,
            (void *)request);
        return AWS_OP_ERR;
    }
    return AWS_OP_SUCCESS;
}

static int s_s3_meta_request_incoming_headers(
    struct aws_http_stream *stream,
    enum aws_http_header_block header_block,
    const struct aws_http_header *headers,
    size_t headers_count,
    void *user_data) {
    (void)header_block;

    AWS_PRECONDITION(stream);

    struct aws_s3_connection *connection = user_data;
    AWS_PRECONDITION(connection);

    struct aws_s3_request *request = connection->request;
    AWS_PRECONDITION(request);

    struct aws_s3_meta_request *meta_request = request->meta_request;
    AWS_PRECONDITION(meta_request);
    bool collect_metrics = request->send_data.metrics != NULL;

    if (aws_http_stream_get_incoming_response_status(stream, &request->send_data.response_status)) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p Could not get incoming response status for request %p",
            (void *)meta_request,
            (void *)request);
    }

    if (collect_metrics) {
        /* Record the headers to the metrics */
        struct aws_s3_request_metrics *s3_metrics = request->send_data.metrics;
        if (s3_metrics->req_resp_info_metrics.response_headers == NULL) {
            s3_metrics->req_resp_info_metrics.response_headers = aws_http_headers_new(meta_request->allocator);
        }
        s3_metrics->req_resp_info_metrics.response_status = request->send_data.response_status;
    }

    bool successful_response =
        s_s3_meta_request_error_code_from_response_status(request->send_data.response_status) == AWS_ERROR_SUCCESS;

    if (successful_response && meta_request->checksum_config.validate_response_checksum &&
        request->request_type == AWS_S3_REQUEST_TYPE_GET_OBJECT) {
        /* We have `struct aws_http_header *` array instead of `struct aws_http_headers *` */
        s_get_part_response_headers_checksum_helper(connection, meta_request, headers, headers_count);
    }

    /* Only record headers if an error has taken place, or if the request_desc has asked for them. */
    bool should_record_headers = !successful_response || request->record_response_headers;

    if (should_record_headers) {
        if (request->send_data.response_headers == NULL) {
            request->send_data.response_headers = aws_http_headers_new(meta_request->allocator);
        }
    }

    for (size_t i = 0; i < headers_count; ++i) {
        const struct aws_byte_cursor *name = &headers[i].name;
        const struct aws_byte_cursor *value = &headers[i].value;
        if (request->send_data.request_id == NULL && aws_byte_cursor_eq(name, &g_request_id_header_name)) {
            request->send_data.request_id = aws_string_new_from_cursor(connection->request->allocator, value);
            if (collect_metrics) {
                request->send_data.metrics->req_resp_info_metrics.request_id =
                    aws_string_new_from_cursor(connection->request->allocator, value);
            }
        }
        if (request->send_data.amz_id_2 == NULL && aws_byte_cursor_eq(name, &g_amz_id_2_header_name)) {
            request->send_data.amz_id_2 = aws_string_new_from_cursor(connection->request->allocator, value);
            if (collect_metrics) {
                request->send_data.metrics->req_resp_info_metrics.extended_request_id =
                    aws_string_new_from_cursor(connection->request->allocator, value);
            }
        }
        if (aws_byte_cursor_eq(name, &g_content_range_header_name) && successful_response &&
            request->request_type == AWS_S3_REQUEST_TYPE_GET_OBJECT) {
            uint64_t object_range_start = 0;
            uint64_t object_range_end = 0;
            uint64_t object_size = 0;
            if (aws_s3_parse_content_range_cursor(*value, &object_range_start, &object_range_end, &object_size)) {
                AWS_LOGF_ERROR(
                    AWS_LS_S3_META_REQUEST,
                    "id=%p: Could not parse content range header (%s)",
                    (void *)meta_request,
                    aws_error_str(aws_last_error()));
                return AWS_OP_ERR;
            } else {
                /* Make we get what we ask for. */
                if (request->part_range_end != 0) {
                    if (request->part_range_start != object_range_start) {
                        /* Log the error */
                        AWS_LOGF_ERROR(
                            AWS_LS_S3_META_REQUEST,
                            "id=%p: Part range start mismatch. Expected: %" PRIu64 ", Actual: %" PRIu64 "",
                            (void *)meta_request,
                            request->part_range_start,
                            object_range_start);
                        return aws_raise_error(AWS_ERROR_S3_INVALID_CONTENT_RANGE_HEADER);
                    }
                    if (request->part_range_end != object_range_end) {
                        /* In the case where the object size is less than the range requested. It must be return the
                         * last part to the end of the object.
                         * Note: that when get with part 1 is used we dont know how big the buffer will be. We
                         * optimistically allocate part sized buffer, and see if its enough. If its over, the req will
                         * get canceled. So in that case skip validation on expected size.
                         */
                        bool is_unknown_len_part_req =
                            request->request_type == AWS_S3_REQUEST_TYPE_GET_OBJECT &&
                            request->request_tag == AWS_S3_AUTO_RANGE_GET_REQUEST_TYPE_GET_OBJECT_WITH_PART_NUMBER_1;

                        if (!is_unknown_len_part_req &&
                            (object_size != object_range_end + 1 || request->part_range_end < object_range_end)) {
                            /* Something went wrong if it's matching. Log the error. */
                            AWS_LOGF_ERROR(
                                AWS_LS_S3_META_REQUEST,
                                "id=%p: Part range end mismatch. Expected: %" PRIu64 ", Actual: %" PRIu64
                                ", while object size is: "
                                "%" PRIu64 ".",
                                (void *)meta_request,
                                request->part_range_end,
                                object_range_end,
                                object_size);
                            return aws_raise_error(AWS_ERROR_S3_INVALID_CONTENT_RANGE_HEADER);
                        }
                    }
                }
            }
        }

        if (collect_metrics) {
            aws_http_headers_add(request->send_data.metrics->req_resp_info_metrics.response_headers, *name, *value);
        }
        if (should_record_headers) {
            aws_http_headers_add(request->send_data.response_headers, *name, *value);
        }
    }

    return AWS_OP_SUCCESS;
}

static int s_s3_meta_request_headers_block_done(
    struct aws_http_stream *stream,
    enum aws_http_header_block header_block,
    void *user_data) {
    (void)stream;

    if (header_block != AWS_HTTP_HEADER_BLOCK_MAIN) {
        return AWS_OP_SUCCESS;
    }

    struct aws_s3_connection *connection = user_data;
    AWS_PRECONDITION(connection);

    struct aws_s3_request *request = connection->request;
    AWS_PRECONDITION(request);

    /*
     * When downloading parts via partNumber, if the response is larger than the buffer we reserved, cancel
     * immediately so we don't overflow memory. We'll retry using ranged gets instead.
     *
     * Compare against the reserved buffer size (part_range_end - part_range_start + 1) rather than part_size,
     * because when object_size_hint is provided the buffer is sized to min(hint, part_size), which may be
     * smaller than part_size. Using part_size here would miss the case where hint < content_length <= part_size.
     */
    struct aws_s3_meta_request *meta_request = request->meta_request;
    AWS_PRECONDITION(meta_request);

    /* Check if we need to create a `request_level_combine_sum` or not */
    if (meta_request->checksum_config.validate_response_checksum &&
        request->request_type == AWS_S3_REQUEST_TYPE_GET_OBJECT &&
        s_s3_meta_request_error_code_from_response_status(request->send_data.response_status) == AWS_ERROR_SUCCESS) {
        if (s_ensure_part_combine_sum(meta_request, request)) {
            return AWS_OP_ERR;
        }
    }

    if (request->request_type == AWS_S3_REQUEST_TYPE_GET_OBJECT &&
        request->request_tag == AWS_S3_AUTO_RANGE_GET_REQUEST_TYPE_GET_OBJECT_WITH_PART_NUMBER_1) {
        uint64_t content_length;
        uint64_t reserved_size = request->part_range_end - request->part_range_start + 1;
        if (!aws_s3_parse_content_length_response_header(
                request->allocator, request->send_data.response_headers, &content_length) &&
            content_length > reserved_size) {
            return aws_raise_error(AWS_ERROR_S3_INTERNAL_BUFFER_SIZE_MISMATCH_RETRYING_WITH_RANGE);
        }
    }
    return AWS_OP_SUCCESS;
}

/*
 * Small helper to either do a static or dynamic append.
 * TODO: something like this would be useful in common.
 */
static int s_response_body_append(struct aws_byte_buf *buf, const struct aws_byte_cursor *data) {
    return buf->allocator != NULL ? aws_byte_buf_append_dynamic(buf, data) : aws_byte_buf_append(buf, data);
}

static int s_s3_meta_request_incoming_body(
    struct aws_http_stream *stream,
    const struct aws_byte_cursor *data,
    void *user_data) {
    (void)stream;

    struct aws_s3_connection *connection = user_data;
    AWS_PRECONDITION(connection);

    struct aws_s3_request *request = connection->request;
    AWS_PRECONDITION(request);

    struct aws_s3_meta_request *meta_request = request->meta_request;
    AWS_PRECONDITION(meta_request);
    AWS_PRECONDITION(meta_request->vtable);

    AWS_LOGF_TRACE(
        AWS_LS_S3_META_REQUEST,
        "id=%p Incoming body for request %p. Response status: %d. Data Size: %" PRIu64 ". connection: %p.",
        (void *)meta_request,
        (void *)request,
        request->send_data.response_status,
        (uint64_t)data->len,
        (void *)connection);
    bool successful_response =
        s_s3_meta_request_error_code_from_response_status(request->send_data.response_status) == AWS_ERROR_SUCCESS;
    if (!successful_response) {
        AWS_LOGF_TRACE(AWS_LS_S3_META_REQUEST, "response body: \n" PRInSTR "\n", AWS_BYTE_CURSOR_PRI(*data));
    }

    if (meta_request->checksum_config.validate_response_checksum) {
        /* Update whichever of this part's running checksums are active, while the data is still hot from the
         * socket read on this connection's thread. The two are independent: validation_sum is present only
         * when this part's response carried a checksum header of its own, combine_sum only when this part
         * feeds the whole-object checksum. They are separate objects because those two checksums may not use
         * the same algorithm. */
        struct aws_s3_checksum *validation_sum = request->request_level_running_response_sum;
        struct aws_s3_checksum *combine_sum = request->request_level_combine_sum;

        if ((validation_sum != NULL && aws_checksum_update(validation_sum, data)) ||
            (combine_sum != NULL && aws_checksum_update(combine_sum, data))) {
            AWS_LOGF_ERROR(
                AWS_LS_S3_META_REQUEST,
                "id=%p: Request %p could not update checksum due to error %d (%s).",
                (void *)meta_request,
                (void *)request,
                aws_last_error_or_unknown(),
                aws_error_str(aws_last_error_or_unknown()));
            return AWS_OP_ERR;
        }
    }

    if (request->send_data.response_body.capacity == 0) {
        /* Make sure that request is get, since puts can also have ticket allocated, which is used for request body. */
        if (successful_response && request->request_type == AWS_S3_REQUEST_TYPE_GET_OBJECT && request->ticket != NULL) {
            request->send_data.response_body = aws_s3_buffer_ticket_claim(request->ticket);
        } else {
            size_t buffer_size = s_dynamic_body_initial_buf_size;
            aws_byte_buf_init(&request->send_data.response_body, meta_request->allocator, buffer_size);
        }
    }

    /* Sanity checking that we somehow haven't reused the same buffer for both upload and download*/
    AWS_FATAL_ASSERT(request->send_data.response_body.buffer != request->request_body.buffer);

    /* Note: not having part sized response body means the buffer is dynamic and
     * can grow. */
    if (s_response_body_append(&request->send_data.response_body, data)) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p: Request %p could not append to response body due to error %d (%s).",
            (void *)meta_request,
            (void *)request,
            aws_last_error_or_unknown(),
            aws_error_str(aws_last_error_or_unknown()));

        return AWS_OP_ERR;
    }

    return AWS_OP_SUCCESS;
}

static void s_s3_meta_request_stream_metrics(
    struct aws_http_stream *stream,
    const struct aws_http_stream_metrics *http_metrics,
    void *user_data) {
    (void)stream;
    struct aws_s3_connection *connection = user_data;
    AWS_PRECONDITION(connection);

    struct aws_s3_request *request = connection->request;
    AWS_PRECONDITION(request);
    AWS_ASSERT(request->send_data.metrics);
    struct aws_s3_request_metrics *s3_metrics = request->send_data.metrics;
    /* Copy over the time metrics from aws_http_stream_metrics to aws_s3_request_metrics */
    s3_metrics->time_metrics.send_start_timestamp_ns = http_metrics->send_start_timestamp_ns;
    s3_metrics->time_metrics.send_end_timestamp_ns = http_metrics->send_end_timestamp_ns;
    s3_metrics->time_metrics.sending_duration_ns = http_metrics->sending_duration_ns;
    s3_metrics->time_metrics.receive_start_timestamp_ns = http_metrics->receive_start_timestamp_ns;

    if (s3_metrics->time_metrics.receive_start_timestamp_ns != -1) {
        s3_metrics->time_metrics.service_call_duration_ns = s3_metrics->time_metrics.receive_start_timestamp_ns -
                                                            s3_metrics->time_metrics.conn_acquire_start_timestamp_ns;
    }

    s3_metrics->time_metrics.receive_end_timestamp_ns = http_metrics->receive_end_timestamp_ns;
    s3_metrics->time_metrics.receiving_duration_ns = http_metrics->receiving_duration_ns;

    s3_metrics->crt_info_metrics.stream_id = http_metrics->stream_id;

    /* Also related metrics from the request/response. */
    s3_metrics->crt_info_metrics.connection_ptr = (void *)connection->http_connection;
    const struct aws_socket_endpoint *endpoint = aws_http_connection_get_remote_endpoint(connection->http_connection);
    request->send_data.metrics->crt_info_metrics.ip_address =
        aws_string_new_from_c_str(request->allocator, endpoint->address);
    AWS_ASSERT(request->send_data.metrics->crt_info_metrics.ip_address != NULL);

    s3_metrics->crt_info_metrics.thread_id = aws_thread_current_thread_id();
}

/* Finish up the processing of the request work. */
static void s_s3_meta_request_stream_complete(struct aws_http_stream *stream, int error_code, void *user_data) {

    struct aws_s3_connection *connection = user_data;
    AWS_PRECONDITION(connection);
    struct aws_s3_request *request = connection->request;
    struct aws_s3_meta_request *meta_request = request->meta_request;

    if (meta_request->checksum_config.validate_response_checksum) {
        /* Validate this part against its own checksum header, if it had one. The presence of an expected
         * value is what decides, not the presence of a running sum: a part that only contributes to the
         * whole-object checksum has a combine sum but nothing to compare anything against on its own. */
        if (error_code == AWS_OP_SUCCESS && request->request_level_response_header_checksum.len > 0) {
            struct aws_s3_checksum *part_sum = request->request_level_running_response_sum;
            if (part_sum != NULL) {
                request->did_validate = true;
                request->validation_algorithm = part_sum->algorithm;
                request->checksum_match =
                    s_validate_checksum(part_sum, &request->request_level_response_header_checksum);
                if (!request->checksum_match) {
                    AWS_LOGF_ERROR(
                        AWS_LS_S3_META_REQUEST,
                        "id=%p Checksum mismatch! (request=%p, response status=%d)",
                        (void *)meta_request,
                        (void *)request,
                        request->send_data.response_status);
                    error_code = AWS_ERROR_S3_RESPONSE_CHECKSUM_MISMATCH;
                }
            } else {
                /* part sum in theory will only be null if crt does not support the checksum. skip validation in that
                 * case. */
                request->did_validate = false;
            }
        } else {
            request->did_validate = false;
        }

        /* Record this part's digest for the whole-object combine, which happens once the meta request
         * finishes. It is copied into a slot the meta request owns, so the running checksum below can be torn
         * down here exactly as it always was, and nothing of this request outlives it. */
        if (error_code == AWS_OP_SUCCESS && request->request_level_combine_sum != NULL) {
            uint8_t digest_storage[AWS_S3_COMBINABLE_DIGEST_MAX_LEN] = {0};
            struct aws_byte_buf part_digest = aws_byte_buf_from_empty_array(digest_storage, sizeof(digest_storage));

            if (aws_checksum_finalize(request->request_level_combine_sum, &part_digest)) {
                error_code = aws_last_error_or_unknown();
            } else {
                s_s3_meta_request_record_part_digest(
                    meta_request, request->part_number, &part_digest, request->send_data.response_body.len);
            }
        }

        aws_checksum_destroy(request->request_level_running_response_sum);
        request->request_level_running_response_sum = NULL;
        aws_checksum_destroy(request->request_level_combine_sum);
        request->request_level_combine_sum = NULL;
        aws_byte_buf_clean_up(&request->request_level_response_header_checksum);
    }

    /* BEGIN CRITICAL SECTION */
    {
        aws_s3_meta_request_lock_synced_data(meta_request);
        if (request->synced_data.cancellable_http_stream) {
            aws_linked_list_remove(&request->cancellable_http_streams_list_node);
            request->synced_data.cancellable_http_stream = NULL;
        }
        aws_s3_meta_request_unlock_synced_data(meta_request);
    }
    /* END CRITICAL SECTION */
    s_s3_meta_request_send_request_finish(connection, stream, error_code);
}

static void s_s3_meta_request_send_request_finish(
    struct aws_s3_connection *connection,
    struct aws_http_stream *stream,
    int error_code) {
    AWS_PRECONDITION(connection);

    struct aws_s3_request *request = connection->request;
    AWS_PRECONDITION(request);

    struct aws_s3_meta_request *meta_request = request->meta_request;
    AWS_PRECONDITION(meta_request);

    struct aws_s3_meta_request_vtable *vtable = meta_request->vtable;
    AWS_PRECONDITION(vtable);

    vtable->send_request_finish(connection, stream, error_code);
}

/* Return whether the response to this request might contain an error, even though we got 200 OK.
 * see: https://repost.aws/knowledge-center/s3-resolve-200-internalerror */
static bool s_should_check_for_error_despite_200_OK(const struct aws_s3_request *request) {
    /* We handle async error for every thing EXCEPT GetObject.
     *
     * Note that we check the aws_s3_request_type (not the aws_s3_meta_request_type),
     * in case someone is using a DEFAULT meta-request to send GetObject */
    if (request->request_type == AWS_S3_REQUEST_TYPE_GET_OBJECT) {
        return false;
    }
    return true;
}

/**
 * Check the response detail, returns:
 * - AWS_ERROR_SUCCESS for successfully response
 * - AWS_ERROR_S3_NON_RECOVERABLE_ASYNC_ERROR 200 response with error in the body that is non-recoverable
 * - AWS_ERROR_S3_INVALID_RESPONSE_STATUS for all other non-recoverable response.
 * - Specific error code for recoverable response.
 */
static int s_s3_meta_request_error_code_from_response(struct aws_s3_request *request) {
    AWS_PRECONDITION(request);

    int error_code_from_status = s_s3_meta_request_error_code_from_response_status(request->send_data.response_status);

    /* Response body might be XML with an <Error><Code> inside.
     * The is very likely when status-code is bad.
     * In some cases, it's even possible after 200 OK. */
    int error_code_from_xml = AWS_ERROR_SUCCESS;
    if (error_code_from_status != AWS_ERROR_SUCCESS || s_should_check_for_error_despite_200_OK(request)) {
        if (request->send_data.response_body.len > 0) {
            /* Attempt to read as XML, it's fine if this fails. */
            struct aws_byte_cursor xml_doc = aws_byte_cursor_from_buf(&request->send_data.response_body);
            struct aws_byte_cursor error_code_string = {0};
            const char *xml_path[] = {"Error", "Code", NULL};
            if (aws_xml_get_body_at_path(request->allocator, xml_doc, xml_path, &error_code_string) == AWS_OP_SUCCESS) {
                /* Found an <Error><Code> string! Map it to CRT error code if retry-able. */
                error_code_from_xml =
                    aws_s3_crt_error_code_from_recoverable_server_error_code_string(error_code_string);
            }
        }
    }

    if (error_code_from_status == AWS_ERROR_SUCCESS) {
        /* Status-code was OK, so assume everything's good, unless we found an <Error><Code> in the XML */
        switch (error_code_from_xml) {
            case AWS_ERROR_SUCCESS:
                return AWS_ERROR_SUCCESS;
            case AWS_ERROR_UNKNOWN:
                return AWS_ERROR_S3_NON_RECOVERABLE_ASYNC_ERROR;
            default:
                return error_code_from_xml;
        }
    } else {
        /* Return error based on status-code, unless we got something more specific from XML */
        switch (error_code_from_xml) {
            case AWS_ERROR_SUCCESS:
                return error_code_from_status;
            case AWS_ERROR_UNKNOWN:
                return error_code_from_status;
            default:
                return error_code_from_xml;
        }
    }
}

void aws_s3_meta_request_send_request_finish_default(
    struct aws_s3_connection *connection,
    struct aws_http_stream *stream,
    int error_code) {

    struct aws_s3_request *request = connection->request;
    AWS_PRECONDITION(request);

    struct aws_s3_meta_request *meta_request = request->meta_request;
    AWS_PRECONDITION(meta_request);

    struct aws_s3_client *client = meta_request->client;
    AWS_PRECONDITION(client);

    int response_status = request->send_data.response_status;
    /* If our error code is currently success, then we have some other calls to make that could still indicate a
     * failure. */
    if (error_code == AWS_ERROR_SUCCESS) {
        error_code = s_s3_meta_request_error_code_from_response(request);
        if (error_code != AWS_ERROR_SUCCESS) {
            aws_raise_error(error_code);
        }
    }

    AWS_LOGF_DEBUG(
        AWS_LS_S3_META_REQUEST,
        "id=%p: Request %p finished with error code %d (%s) and response status %d, x-amz-request-id: %s, x-amz-id-2: "
        "%s",
        (void *)meta_request,
        (void *)request,
        error_code,
        aws_error_debug_str(error_code),
        response_status,
        request->send_data.request_id ? aws_string_c_str(request->send_data.request_id) : "N/A",
        request->send_data.amz_id_2 ? aws_string_c_str(request->send_data.amz_id_2) : "N/A");

    enum aws_s3_connection_finish_code finish_code = AWS_S3_CONNECTION_FINISH_CODE_FAILED;

    if (error_code == AWS_ERROR_SUCCESS) {
        finish_code = AWS_S3_CONNECTION_FINISH_CODE_SUCCESS;
    } else {
        /* BEGIN CRITICAL SECTION */
        aws_s3_meta_request_lock_synced_data(meta_request);
        bool meta_request_finishing = aws_s3_meta_request_has_finish_result_synced(meta_request);
        aws_s3_meta_request_unlock_synced_data(meta_request);
        /* END CRITICAL SECTION */

        /* If the request failed due to an invalid (ie: unrecoverable) response status, or the meta request already
         * has a result, then make sure that this request isn't retried. */
        if (error_code == AWS_ERROR_S3_INVALID_RESPONSE_STATUS ||
            error_code == AWS_ERROR_S3_INTERNAL_BUFFER_SIZE_MISMATCH_RETRYING_WITH_RANGE ||
            error_code == AWS_ERROR_S3_NON_RECOVERABLE_ASYNC_ERROR ||
            error_code == AWS_ERROR_S3_RESPONSE_CHECKSUM_MISMATCH || meta_request_finishing) {
            finish_code = AWS_S3_CONNECTION_FINISH_CODE_FAILED;
            if (error_code == AWS_ERROR_S3_INTERNAL_BUFFER_SIZE_MISMATCH_RETRYING_WITH_RANGE) {
                /* Log at info level instead of error as it's expected and not a fatal error */
                AWS_LOGF_INFO(
                    AWS_LS_S3_META_REQUEST,
                    "id=%p Cancelling the request because of error %d (%s). (request=%p, response status=%d)",
                    (void *)meta_request,
                    error_code,
                    aws_error_str(error_code),
                    (void *)request,
                    response_status);
            } else {
                AWS_LOGF_ERROR(
                    AWS_LS_S3_META_REQUEST,
                    "id=%p Meta request cannot recover from error %d (%s). (request=%p, response status=%d)",
                    (void *)meta_request,
                    error_code,
                    aws_error_str(error_code),
                    (void *)request,
                    response_status);
            }

        } else {
            if (error_code == AWS_ERROR_HTTP_RESPONSE_FIRST_BYTE_TIMEOUT) {
                /* Log at info level instead of error as it's somewhat expected. */
                AWS_LOGF_INFO(
                    AWS_LS_S3_META_REQUEST,
                    "id=%p Request failed from error %d (%s). (request=%p). Try to setup a retry.",
                    (void *)meta_request,
                    error_code,
                    aws_error_str(error_code),
                    (void *)request);
            } else {
                AWS_LOGF_ERROR(
                    AWS_LS_S3_META_REQUEST,
                    "id=%p Request failed from error %d (%s). (request=%p, response status=%d). Try to setup a "
                    "retry.",
                    (void *)meta_request,
                    error_code,
                    aws_error_str(error_code),
                    (void *)request,
                    response_status);
            }

            /* Otherwise, set this up for a retry if the meta request is active. */
            finish_code = AWS_S3_CONNECTION_FINISH_CODE_RETRY;
        }
    }

    if (stream != NULL) {
        aws_http_stream_release(stream);
        stream = NULL;
    }

    aws_s3_client_notify_connection_finished(client, connection, error_code, finish_code);
}

void aws_s3_meta_request_finished_request(
    struct aws_s3_meta_request *meta_request,
    struct aws_s3_request *request,
    int error_code) {
    AWS_PRECONDITION(meta_request);
    AWS_PRECONDITION(meta_request->vtable);
    AWS_PRECONDITION(meta_request->vtable->finished_request);

    meta_request->vtable->finished_request(meta_request, request, error_code);
}

/* Pushes a request into the body streaming priority queue. Derived meta request types should not call this--they
 * should instead call aws_s3_meta_request_stream_response_body_synced.*/
static void s_s3_meta_request_body_streaming_push_synced(
    struct aws_s3_meta_request *meta_request,
    struct aws_s3_request *request);

/* Pops the next available request from the body streaming priority queue. If the parts previous the next request in
 * the priority queue have not been placed in the priority queue yet, the priority queue will remain the same, and
 * NULL will be returned. (Should not be needed to be called by derived types.) */
static struct aws_s3_request *s_s3_meta_request_body_streaming_pop_next_synced(
    struct aws_s3_meta_request *meta_request);

static void s_s3_meta_request_event_delivery_task(struct aws_task *task, void *arg, enum aws_task_status task_status);

static void s_s3_body_write_task(struct aws_task *task, void *arg, enum aws_task_status task_status);

struct aws_s3_body_write_task_args {
    struct aws_allocator *allocator;

    /* Owning ref. A pending write may be the last thing keeping the meta request alive. */
    struct aws_s3_meta_request *meta_request;

    /* Keeps `body`'s bytes alive when they came from the buffer pool, since
     * aws_s3_buffer_ticket_claim() hands back a non-owning view of ticket-held memory.
     * NULL when `body` was grown dynamically and owns its own allocation. */
    struct aws_s3_buffer_ticket *ticket;

    /* The bytes to write. */
    struct aws_byte_buf body;

    /* Moved off the request, because aws_s3_request_clean_up_send_data() asserts that a request
     * being torn down no longer holds started metrics. Whoever completes the write is responsible
     * for finishing these before destroying it. */
    struct aws_s3_request_metrics *metrics;

    /* The byte index of the object that this refers to. For example, for an HTTP message that has a range header, the
       first chunk received will have a range_start that matches the range header's range-start.*/
    uint64_t s3_object_range_start;

    /* Inclusive end of the object range the part was asked for. Paired with `s3_object_range_start`
     * rather than derived from `body.len`, because a short body must not shrink the range the part
     * covered. */
    uint64_t s3_object_range_end;

    /* Part number the body came from. */
    uint32_t part_number;

    /* Which write worker owns this: an index into the client's file_io_elg, and equally the
     * index of the meta request's descriptor slot this write uses. Assigned when the write is
     * scheduled. */
    size_t write_loop_index;

    /* Scheduling state. */
    struct aws_task task;
};

static struct aws_s3_body_write_task_args *s_s3_body_write_task_args_new_from_request(struct aws_s3_request *request) {
    AWS_PRECONDITION(request);
    AWS_PRECONDITION(request->meta_request);

    struct aws_s3_meta_request *meta_request = request->meta_request;
    struct aws_s3_body_write_task_args *body_write =
        aws_mem_calloc(meta_request->allocator, 1, sizeof(struct aws_s3_body_write_task_args));

    body_write->allocator = meta_request->allocator;

    /* The request holds its own ref, which goes away when the caller releases it, so take one. */
    body_write->meta_request = aws_s3_meta_request_acquire(meta_request);

    /* Move rather than copy: the request must not clean up or release anything the write now owns.
     * `body` may be a non-owning view of `ticket`'s memory, so the two have to travel together for
     * the bytes to stay valid. */
    body_write->ticket = request->ticket;
    request->ticket = NULL;

    body_write->body = request->send_data.response_body;
    AWS_ZERO_STRUCT(request->send_data.response_body);

    body_write->s3_object_range_end = request->part_range_end;

    body_write->metrics = request->send_data.metrics;
    request->send_data.metrics = NULL;

    body_write->s3_object_range_start = request->part_range_start;
    body_write->part_number = request->part_number;

    return body_write;
}

static void s_s3_body_write_task_args_destroy(struct aws_s3_body_write_task_args *body_write) {
    if (body_write == NULL) {
        return;
    }

    /* Mirrors the invariant aws_s3_request_clean_up_send_data() enforces: metrics are finished where
     * the work completes, not silently dropped during teardown. */
    AWS_FATAL_ASSERT(body_write->metrics == NULL);

    /* No-op when `body` is a view of pool memory; the ticket release below is what frees those. */
    aws_byte_buf_clean_up(&body_write->body);
    aws_s3_buffer_ticket_release(body_write->ticket);
    aws_s3_meta_request_release(body_write->meta_request);

    aws_mem_release(body_write->allocator, body_write);
}

/* Schedule `body_write` on one of the file I/O event loops. */
static void s_s3_body_write_schedule(struct aws_s3_body_write_task_args *body_write) {
    struct aws_s3_meta_request *meta_request = body_write->meta_request;
    struct aws_s3_client *client = meta_request->client;

    /* Pick a worker by round robin and remember which one, so the task can use that worker's
     * descriptor slot. get_loop_at() rather than get_next_loop() because the index has to be known,
     * not just the loop. */
    size_t loop_count = aws_event_loop_group_get_loop_count(client->file_io_elg);
    size_t loop_index = aws_atomic_fetch_add(&client->next_write_loop_index, 1) % loop_count;
    body_write->write_loop_index = loop_index;

    struct aws_event_loop *loop = aws_event_loop_group_get_loop_at(client->file_io_elg, loop_index);
    aws_task_init(&body_write->task, s_s3_body_write_task, body_write, "s3_body_write");
    aws_event_loop_schedule_task_now(loop, &body_write->task);
}

void aws_s3_meta_request_stream_response_body_synced(
    struct aws_s3_meta_request *meta_request,
    struct aws_s3_request *request) {

    ASSERT_SYNCED_DATA_LOCK_HELD(meta_request);
    AWS_PRECONDITION(meta_request);
    AWS_PRECONDITION(request);
    AWS_PRECONDITION(request->part_number > 0);

    /* Out-of-order delivery: bypass the priority queue entirely, so a part never waits on the part
     * ahead of it. Every part carries its own absolute offset, so they need no ordering relative to
     * each other. */
    if (aws_atomic_load_int(&meta_request->out_of_order_delivery) != 0) {

        ++meta_request->synced_data.num_parts_delivery_sent;

        if (meta_request->recv_filepath != NULL) {
            /* Hand the body off to a write worker. The request owns nothing the write still needs, so
             * the caller's release can destroy it now instead of the pending write pinning it alive. */
            struct aws_s3_body_write_task_args *body_write = s_s3_body_write_task_args_new_from_request(request);

            aws_atomic_fetch_add(&meta_request->client->num_pending_writes, 1);
            s_s3_body_write_schedule(body_write);
            return;
        }

        /* Callback sink: still deliver through the ordered event path, which is what keeps the callback
         * firing one part at a time on io_event_loop. Skipping the queue only removes the wait for
         * earlier parts; it does not move the callback off that thread. */
        struct aws_s3_meta_request_event event = {.type = AWS_S3_META_REQUEST_EVENT_RESPONSE_BODY};
        aws_s3_request_acquire(request);
        event.u.response_body.completed_request = request;
        aws_s3_meta_request_add_event_for_delivery_synced(meta_request, &event);

        aws_atomic_fetch_add(&meta_request->client->stats.num_requests_streaming_response, 1);
        return;
    }

    /* Push it into the priority queue. */
    s_s3_meta_request_body_streaming_push_synced(meta_request, request);

    struct aws_s3_client *client = meta_request->client;
    AWS_PRECONDITION(client);
    aws_atomic_fetch_add(&client->stats.num_requests_stream_queued_waiting, 1);

    /* Grab any requests that can be streamed back to the caller
     * and send them for delivery on io_event_loop thread. */
    uint32_t num_streaming_requests = 0;
    struct aws_s3_request *next_streaming_request;
    while ((next_streaming_request = s_s3_meta_request_body_streaming_pop_next_synced(meta_request)) != NULL) {
        struct aws_s3_meta_request_event event = {.type = AWS_S3_META_REQUEST_EVENT_RESPONSE_BODY};
        event.u.response_body.completed_request = next_streaming_request;
        aws_s3_meta_request_add_event_for_delivery_synced(meta_request, &event);

        ++num_streaming_requests;
    }

    if (num_streaming_requests == 0) {
        return;
    }

    aws_atomic_fetch_add(&client->stats.num_requests_streaming_response, num_streaming_requests);
    aws_atomic_fetch_sub(&client->stats.num_requests_stream_queued_waiting, num_streaming_requests);

    meta_request->synced_data.num_parts_delivery_sent += num_streaming_requests;
}

void aws_s3_meta_request_add_event_for_delivery_synced(
    struct aws_s3_meta_request *meta_request,
    const struct aws_s3_meta_request_event *event) {

    ASSERT_SYNCED_DATA_LOCK_HELD(meta_request);
    if (event) {
        aws_array_list_push_back(&meta_request->synced_data.event_delivery_array, event);
    }

    /* If the event delivery task is not scheduled before, and there are more to be delivered. */
    if (!meta_request->synced_data.event_delivery_task_scheduled &&
        aws_array_list_length(&meta_request->synced_data.event_delivery_array) > 0) {
        aws_s3_meta_request_acquire(meta_request);

        aws_task_init(
            &meta_request->synced_data.event_delivery_task,
            s_s3_meta_request_event_delivery_task,
            meta_request,
            "s3_meta_request_event_delivery");
        aws_event_loop_schedule_task_now(meta_request->io_event_loop, &meta_request->synced_data.event_delivery_task);
        meta_request->synced_data.event_delivery_task_scheduled = true;
    }
}

bool aws_s3_meta_request_are_events_out_for_delivery_synced(struct aws_s3_meta_request *meta_request) {
    ASSERT_SYNCED_DATA_LOCK_HELD(meta_request);
    return aws_array_list_length(&meta_request->synced_data.event_delivery_array) > 0 ||
           meta_request->synced_data.event_delivery_active;
}

void aws_s3_meta_request_cancel_cancellable_requests_synced(struct aws_s3_meta_request *meta_request, int error_code) {
    ASSERT_SYNCED_DATA_LOCK_HELD(meta_request);
    while (!aws_linked_list_empty(&meta_request->synced_data.cancellable_http_streams_list)) {
        struct aws_linked_list_node *request_node =
            aws_linked_list_pop_front(&meta_request->synced_data.cancellable_http_streams_list);
        struct aws_s3_request *request =
            AWS_CONTAINER_OF(request_node, struct aws_s3_request, cancellable_http_streams_list_node);
        AWS_ASSERT(!request->always_send);

        aws_http_stream_cancel(request->synced_data.cancellable_http_stream, error_code);
        request->synced_data.cancellable_http_stream = NULL;
    }
}

void aws_s3_meta_request_cancel_pending_buffer_futures_synced(
    struct aws_s3_meta_request *meta_request,
    int error_code) {
    ASSERT_SYNCED_DATA_LOCK_HELD(meta_request);

    for (struct aws_linked_list_node *node = aws_linked_list_begin(&meta_request->synced_data.pending_buffer_futures);
         node != aws_linked_list_end(&meta_request->synced_data.pending_buffer_futures);
         node = aws_linked_list_next(node)) {

        struct aws_s3_request *request = AWS_CONTAINER_OF(node, struct aws_s3_request, pending_buffer_future_list_node);

        aws_future_s3_buffer_ticket_set_error(request->synced_data.buffer_future, error_code);
    }
}

static struct aws_s3_request_metrics *s_s3_request_finish_up_and_release_metrics(
    struct aws_s3_request_metrics *metrics,
    struct aws_s3_meta_request *meta_request) {

    if (metrics != NULL) {
        /* Request is done streaming the body, complete the metrics for the request now. */

        if (metrics->time_metrics.end_timestamp_ns == -1) {
            aws_high_res_clock_get_ticks((uint64_t *)&metrics->time_metrics.end_timestamp_ns);
            metrics->time_metrics.total_duration_ns =
                metrics->time_metrics.end_timestamp_ns - metrics->time_metrics.start_timestamp_ns;
            aws_high_res_clock_get_ticks((uint64_t *)&metrics->time_metrics.s3_request_last_attempt_end_timestamp_ns);
        }

        if (meta_request->telemetry_callback != NULL) {
            /* We already in the meta request event thread, invoke the telemetry callback directly */
            meta_request->telemetry_callback(meta_request, metrics, meta_request->user_data);
        }
        aws_s3_request_metrics_release(metrics);
    }
    return NULL;
}

static bool s_should_apply_backpressure(struct aws_s3_request *request) {
    struct aws_s3_meta_request *meta_request = request->meta_request;
    if (!meta_request->client->enable_read_backpressure) {
        /* Backpressure is disabled. */
        return false;
    }
    if (!meta_request->body_callback) {
        /* No callback to deliver the body, don't apply backpressure */
        return false;
    }
    /* Apply backpressure only for GetObject request */
    if (meta_request->type == AWS_S3_META_REQUEST_TYPE_GET_OBJECT) {
        return true;
    }
    if (aws_string_eq_c_str(request->operation_name, "GetObject")) {
        return true;
    }
    return false;
}

/* Where a part's bytes belong in the file. A part is delivered at its absolute position in the object,
 * so a ranged download has to subtract the range's origin for its first byte to land at the base offset
 * rather than that many bytes into the file. */
static int s_s3_recv_file_offset(
    struct aws_s3_meta_request *meta_request,
    uint64_t object_range_start,
    uint64_t *out_file_offset) {

    /* The mapping is only meaningful once the origin it subtracts is known, and the origin cannot say so
     * for itself: 0 is what it holds before anything resolves it and also what a whole-object download
     * resolves it to. Mapping before then would place the body at its absolute position in the object
     * rather than at the base offset, with nothing about the outcome looking wrong. */
    if (!meta_request->recv_file_object_range_origin_resolved) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p: Cannot place object range start %" PRIu64 " in the file before the object range is resolved.",
            (void *)meta_request,
            object_range_start);
        return aws_raise_error(AWS_ERROR_INVALID_STATE);
    }

    /* Ahead of the origin there is no file to map onto: the subtraction would wrap and the write would
     * land somewhere far past the end of the file. The checked subtraction is the guard, so the check and
     * the value it protects cannot drift apart. */
    uint64_t offset_from_base = 0;
    if (aws_sub_u64_checked(object_range_start, meta_request->recv_file_object_range_origin, &offset_from_base)) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p: Object range start %" PRIu64 " precedes the range origin %" PRIu64 ", so it has no place in the "
            "file.",
            (void *)meta_request,
            object_range_start,
            meta_request->recv_file_object_range_origin);
        /* Replaces the overflow error the checked subtraction raised: a range ahead of the origin is a state this
         * code should never reach, not an arithmetic accident. */
        return aws_raise_error(AWS_ERROR_INVALID_STATE);
    }

    /* A large base offset, such as a WRITE_TO_POSITION recv_file_position, can wrap the sum around to a small
     * offset, which would overwrite the start of the file without any error. */
    if (aws_add_u64_checked(meta_request->recv_file_base_offset, offset_from_base, out_file_offset)) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p: File offset for object range start %" PRIu64 " overflows: base offset %" PRIu64 " plus %" PRIu64
            " does not fit in 64 bits.",
            (void *)meta_request,
            object_range_start,
            meta_request->recv_file_base_offset,
            offset_from_base);
        return AWS_OP_ERR;
    }
    return AWS_OP_SUCCESS;
}

/* Write one body buffered through a descriptor opened and closed just for it.
 *
 * Only reached when an O_DIRECT descriptor rejects a body for being unaligned in offset, length or
 * buffer address, which the object's last part normally is -- once per transfer, not per part. At that
 * rate the open/close costs less than keeping a second descriptor per writer alive for it. */
static int s_s3_recv_file_write_once(
    struct aws_s3_meta_request *meta_request,
    uint64_t file_offset,
    const struct aws_byte_cursor *body) {

    int fd = AWS_FILE_INVALID_FD;
    if (aws_file_open_for_write(meta_request->recv_filepath, &fd) != AWS_OP_SUCCESS) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p Could not open a descriptor for writing to %s. aws-error:%s",
            (void *)meta_request,
            aws_string_c_str(meta_request->recv_filepath),
            aws_error_name(aws_last_error()));
        return AWS_OP_ERR;
    }

    int result = aws_file_write_to_offset(fd, file_offset, *body);
    aws_file_close_fd(fd);
    return result;
}

/* Write one body at an absolute file offset through `fds`, which the calling thread owns exclusively.
 * pwrite-based throughout, so the offset travels with the write and no seek is involved. */
static int s_s3_recv_file_write(
    struct aws_s3_meta_request *meta_request,
    struct aws_s3_recv_file_fds *fds,
    uint64_t file_offset,
    const struct aws_byte_cursor *body) {

#ifdef AWS_C_S3_ENABLE_TEST_STUBS
    if (meta_request->vtable->recv_file_write_stub != NULL) {
        return meta_request->vtable->recv_file_write_stub(meta_request, file_offset, body);
    }
#endif

    if (!fds->open_attempted) {
        fds->open_attempted = true;

        if (meta_request->recv_file_direct_io) {
            if (aws_file_open_direct_io_for_write(meta_request->recv_filepath, &fds->fd) == AWS_OP_SUCCESS) {
                fds->direct = true;
            } else {
                AWS_LOGF_WARN(
                    AWS_LS_S3_META_REQUEST,
                    "id=%p: Could not open an O_DIRECT descriptor for writing. aws-error:%s. This writer will "
                    "use buffered I/O.",
                    (void *)meta_request,
                    aws_error_name(aws_last_error()));
                aws_reset_error();
                fds->fd = AWS_FILE_INVALID_FD;
            }
        }

        if (fds->fd == AWS_FILE_INVALID_FD &&
            aws_file_open_for_write(meta_request->recv_filepath, &fds->fd) != AWS_OP_SUCCESS) {
            AWS_LOGF_ERROR(
                AWS_LS_S3_META_REQUEST,
                "id=%p Could not open a descriptor for writing to %s. aws-error:%s",
                (void *)meta_request,
                aws_string_c_str(meta_request->recv_filepath),
                aws_error_name(aws_last_error()));
            fds->fd = AWS_FILE_INVALID_FD;
            return AWS_OP_ERR;
        }
    }

    if (fds->fd == AWS_FILE_INVALID_FD) {
        /* An earlier open failed, which already failed the meta request. */
        return aws_raise_error(AWS_ERROR_FILE_WRITE_FAILURE);
    }

    if (!fds->direct) {
        return aws_file_write_to_offset(fds->fd, file_offset, *body);
    }

    if (aws_file_write_to_offset_direct_io(fds->fd, file_offset, *body) == AWS_OP_SUCCESS) {
        return AWS_OP_SUCCESS;
    }

    if (aws_atomic_fetch_add(&meta_request->recv_file_direct_io_fallback_count, 1) == 0) {
        AWS_LOGF_WARN(
            AWS_LS_S3_META_REQUEST,
            "id=%p Failed writing to file with O_DIRECT. aws-error:%s. Writing this body buffered.",
            (void *)meta_request,
            aws_error_name(aws_last_error()));
    }
    aws_reset_error();
    /* Fallback to buffered write, with open the fd and close right after. */
    return s_s3_recv_file_write_once(meta_request, file_offset, body);
}

/* Deliver response body to the appropriate sink: file or user callback.
 * Hand one part's body to whichever sink this download has: the receive file, or a body callback. */
static int s_deliver_body_to_sink(
    struct aws_s3_meta_request *meta_request,
    const struct aws_byte_cursor *body,
    uint64_t delivery_range_start,
    struct aws_s3_request *request) {

    if (meta_request->recv_filepath != NULL) {
        uint64_t file_offset = 0;
        if (s_s3_recv_file_offset(meta_request, delivery_range_start, &file_offset) != AWS_OP_SUCCESS) {
            return AWS_OP_ERR;
        }
        if (s_s3_recv_file_write(meta_request, &meta_request->recv_file_ordered_fds, file_offset, body) !=
            AWS_OP_SUCCESS) {
            AWS_LOGF_ERROR(
                AWS_LS_S3_META_REQUEST,
                "id=%p Failed writing body to file. aws-error:%s",
                (void *)meta_request,
                aws_error_name(aws_last_error()));
            return AWS_OP_ERR;
        }
        if (meta_request->client->enable_read_backpressure) {
            /* Only for bytes that actually landed, matching the parallel write path: opening the window
             * for a failed write would invite more data down a path that is already failing. */
            aws_s3_meta_request_increment_read_window(meta_request, body->len);
        }
        return AWS_OP_SUCCESS;
    }

    /* A callback signals failure by raising an error and returning non-zero, so the reason is already
     * on the thread when we get here. */
    if (meta_request->body_callback_ex != NULL &&
        meta_request->body_callback_ex(
            meta_request,
            body,
            (struct aws_s3_meta_request_receive_body_extra_info){
                .range_start = delivery_range_start, .ticket = request->ticket},
            meta_request->user_data)) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p Response body callback raised error %d (%s).",
            (void *)meta_request,
            aws_last_error(),
            aws_error_str(aws_last_error()));
        return AWS_OP_ERR;
    }

    if (meta_request->body_callback != NULL &&
        meta_request->body_callback(meta_request, body, delivery_range_start, meta_request->user_data)) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p Response body callback raised error %d (%s).",
            (void *)meta_request,
            aws_last_error(),
            aws_error_str(aws_last_error()));
        return AWS_OP_ERR;
    }

    return AWS_OP_SUCCESS;
}

/* A byte whose lowest `count` bits are 1 and the rest 0, for a `count` of 0 through 8.
 *
 * Take a count of 3. Shifting a 1 up by 3 gives 00001000 -- one set bit with nothing but zeros beneath
 * it. Subtracting 1 from that finds nothing to borrow from in those low bits, so the borrow cascades:
 * bit 3 clears and every bit under it flips to 1, leaving 00000111. Which is the first 3 bits are masked. */
static uint8_t s_byte_with_lowest_bits_set(uint32_t count) {
    AWS_PRECONDITION(count <= 8);
    return (uint8_t)((1u << count) - 1);
}

/* Part numbers are 1-based and bits are 0-based, so part N is bit N-1 of the mask. Dividing that bit
 * index by 8 splits it in two: the quotient says which byte holds the bit, the remainder says where it
 * sits inside that byte. Each helper below is one half of that split, and they are the only places that
 * spell it out.
 *
 * Part 11, say. Its bit index is 10, and 10 / 8 is 1 with a remainder of 2, so part 11 is bit 2 of
 * byte 1. */
static uint32_t s_byte_index_holding_part(uint32_t part_number) {
    AWS_PRECONDITION(part_number >= 1);
    return (part_number - 1) / 8;
}

/* The remainder from above, turned into a byte with only that bit set -- position 2 becomes 00000100.
 * Returning the bit already shifted into place is what lets callers test it with & and set it with |=
 * instead of shifting at each use. The shift runs on 1u rather than on a byte because anything narrower
 * promotes to int before shifting anyway, and a position of at most 7 leaves a result of at most
 * 10000000, so narrowing back to a byte cannot drop the bit. */
static uint8_t s_bit_mask_for_part(uint32_t part_number) {
    AWS_PRECONDITION(part_number >= 1);
    return (uint8_t)(1u << ((part_number - 1) % 8));
}

/* Mark part_number as delivered in the validation mask. Returns true on success, false if something is
 * wrong (out of range or duplicate), in which case it logs the error. The caller should fail the meta
 * request on false rather than aborting, since a double-delivery is a bug but not an unrecoverable one. */
static int s_mark_part_delivered(struct aws_s3_meta_request *meta_request, uint32_t part_number) {

    if (meta_request->synced_data.parts_delivered_mask == NULL) {
        return AWS_OP_SUCCESS;
    }

    if (part_number < 1 || part_number > meta_request->synced_data.parts_delivered_mask_num_parts) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p: Part %" PRIu32 " is outside the valid range [1, %" PRIu32 "].",
            (void *)meta_request,
            part_number,
            meta_request->synced_data.parts_delivered_mask_num_parts);
        return aws_raise_error(AWS_ERROR_INVALID_STATE);
    }

    const uint32_t byte_index = s_byte_index_holding_part(part_number);
    if (byte_index >= meta_request->synced_data.parts_delivered_mask_length) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p: Part %" PRIu32 " falls in byte %" PRIu32 " of a %" PRIu32
            "-byte mask, so the mask length and its part count disagree.",
            (void *)meta_request,
            part_number,
            byte_index,
            meta_request->synced_data.parts_delivered_mask_length);
        return aws_raise_error(AWS_ERROR_INVALID_STATE);
    }

    const uint8_t part_bit_mask = s_bit_mask_for_part(part_number);
    const bool already_delivered = (meta_request->synced_data.parts_delivered_mask[byte_index] & part_bit_mask) != 0;
    if (already_delivered) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p: Part %" PRIu32 " was delivered more than once.",
            (void *)meta_request,
            part_number);
        return aws_raise_error(AWS_ERROR_INVALID_STATE);
    }

    meta_request->synced_data.parts_delivered_mask[byte_index] |= part_bit_mask;
    return AWS_OP_SUCCESS;
}

int aws_s3_meta_request_validate_parts_delivered_synced(struct aws_s3_meta_request *meta_request) {
    AWS_PRECONDITION(meta_request);
    ASSERT_SYNCED_DATA_LOCK_HELD(meta_request);

    const uint8_t *mask = meta_request->synced_data.parts_delivered_mask;
    if (mask == NULL) {
        return AWS_OP_SUCCESS;
    }

    const uint32_t num_parts = meta_request->synced_data.parts_delivered_mask_num_parts;
    const uint32_t num_full_bytes = num_parts / 8;
    const uint32_t num_bytes = meta_request->synced_data.parts_delivered_mask_length;

    /* The walk below reads every byte of the mask and derives which bits of the last one stand for a real
     * part from the part count, so the two have to agree before any of it is trusted. Checking once here
     * is what keeps the loop from reading off the end, and keeps the partial-byte arithmetic from asking
     * about bits in a byte that was never allocated. */
    if (num_bytes != (num_parts + 7) / 8) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p: Delivery mask covers %" PRIu32 " parts, which needs %" PRIu32 " bytes, but it is %" PRIu32
            " bytes long.",
            (void *)meta_request,
            num_parts,
            (num_parts + 7) / 8,
            num_bytes);
        return aws_raise_error(AWS_ERROR_INVALID_STATE);
    }

    for (uint32_t byte = 0; byte < num_bytes; ++byte) {
        /* A whole byte covers 8 parts, so all of its bits are required. A part count that is not a
         * multiple of 8 leaves a partial byte at the end whose high bits stand for no part at all, so
         * only its low bits are required. That byte exists only when there is a remainder, which is
         * exactly when `num_bytes` reaches past `num_full_bytes`. */
        const bool is_partial_last_byte = byte >= num_full_bytes;
        const uint8_t required = is_partial_last_byte ? s_byte_with_lowest_bits_set(num_parts % 8) : 0xFF;
        if ((mask[byte] & required) == required) {
            continue;
        }

        /* Name the first part that is missing rather than the byte it sits in. */
        const uint8_t missing_bits = (uint8_t)(required & ~mask[byte]);
        const uint32_t missing_part = byte * 8 + (uint32_t)aws_ctz_u32(missing_bits) + 1;
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p: Download is finishing successfully but part %" PRIu32 " of %" PRIu32 " was never delivered.",
            (void *)meta_request,
            missing_part,
            num_parts);
        return aws_raise_error(AWS_ERROR_INVALID_STATE);
    }

    return AWS_OP_SUCCESS;
}

/* Fold one part into the contiguous delivered prefix.
 *
 * The prefix is only as meaningful as its contiguity: `num_bytes_delivered` is reported as the resume
 * token's continuously-downloaded length, which claims every byte from the start of the range is present.
 * A part beginning anywhere other than where the prefix ended means the parts either skipped bytes or
 * covered the same ones twice, and in both cases that claim is wrong while the byte count still looks
 * plausible. */
static int s_s3_meta_request_extend_delivered_prefix_synced(
    struct aws_s3_meta_request *meta_request,
    const struct aws_s3_delivery_tracking_record *record) {

    ASSERT_SYNCED_DATA_LOCK_HELD(meta_request);

    /* Part 1 decides where the prefix starts. For a ranged download that is the range's start rather
     * than 0, and this accounting has no other way to learn it. */
    uint64_t expected_range_start = meta_request->synced_data.next_contiguous_delivered_part == 1
                                        ? record->range_start
                                        : meta_request->synced_data.next_contiguous_delivered_range_start;

    if (record->range_start != expected_range_start) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p: Part %u covers the object range starting at %" PRIu64 ", but the delivered prefix ends at %" PRIu64
            ". The parts either skipped a range or covered one twice, so the continuous downloaded length cannot be "
            "trusted.",
            (void *)meta_request,
            record->part_number,
            record->range_start,
            expected_range_start);
        return aws_raise_error(AWS_ERROR_INVALID_STATE);
    }

    meta_request->synced_data.num_bytes_delivered += record->bytes;
    /* Advance by the range the part covered, not by the bytes it delivered. A part answered with a
     * short body still accounts for its whole range, so the next part's range start is where the
     * prefix continues. */
    meta_request->synced_data.next_contiguous_delivered_range_start = record->range_end + 1;
    ++meta_request->synced_data.next_contiguous_delivered_part;
    return AWS_OP_SUCCESS;
}

/* Advance the contiguous delivered prefix by `bytes` for `part_number`, draining any later parts that
 * finished first. Only the prefix feeds `num_bytes_delivered`, because that is what the download
 * resume token reports as continuously downloaded -- counting an out-of-order part would claim bytes
 * past a hole the sink never received.
 *
 * Call this once per part, once that part is entirely delivered. Both out-of-order sinks use it: a
 * write worker after its part reaches the file, and the event delivery task after a part's last
 * chunk reaches the body callback. */
static int s_s3_meta_request_record_delivered_part_synced(
    struct aws_s3_meta_request *meta_request,
    uint32_t part_number,
    uint64_t range_start,
    uint64_t range_end,
    uint64_t bytes) {

    ASSERT_SYNCED_DATA_LOCK_HELD(meta_request);

    /* Every written part counts toward the total, whether or not it extends the contiguous prefix. */
    meta_request->synced_data.num_bytes_delivered_total += bytes;

    if (part_number != meta_request->synced_data.next_contiguous_delivered_part) {
        struct aws_s3_delivery_tracking_record entry = {
            .part_number = part_number,
            .range_start = range_start,
            .range_end = range_end,
            .bytes = bytes,
        };
        if (aws_priority_queue_push(&meta_request->synced_data.completed_deliveries_tracker, &entry) !=
            AWS_OP_SUCCESS) {
            /* Dropping it would strand every later part behind a gap that can never close, so this has to
             * fail the meta request rather than be ignored. The queue already raised the reason. */
            AWS_LOGF_ERROR(
                AWS_LS_S3_META_REQUEST,
                "id=%p: Could not park part %u for the delivered prefix. aws-error:%s",
                (void *)meta_request,
                part_number,
                aws_error_name(aws_last_error()));
            return AWS_OP_ERR;
        }
        return AWS_OP_SUCCESS;
    }

    struct aws_s3_delivery_tracking_record current = {
        .part_number = part_number,
        .range_start = range_start,
        .range_end = range_end,
        .bytes = bytes,
    };
    if (s_s3_meta_request_extend_delivered_prefix_synced(meta_request, &current) != AWS_OP_SUCCESS) {
        return AWS_OP_ERR;
    }

    struct aws_s3_delivery_tracking_record *top = NULL;
    while (aws_priority_queue_top(&meta_request->synced_data.completed_deliveries_tracker, (void **)&top) ==
               AWS_OP_SUCCESS &&
           top->part_number == meta_request->synced_data.next_contiguous_delivered_part) {

        struct aws_s3_delivery_tracking_record entry;
        aws_priority_queue_pop(&meta_request->synced_data.completed_deliveries_tracker, &entry);
        if (s_s3_meta_request_extend_delivered_prefix_synced(meta_request, &entry) != AWS_OP_SUCCESS) {
            return AWS_OP_ERR;
        }
    }
    return AWS_OP_SUCCESS;
}

/* Write one part's body to the file. Runs on a body-streaming event loop, concurrently with other
 * parts' writes and with the ordered event delivery task. */
static void s_s3_body_write_task(struct aws_task *task, void *arg, enum aws_task_status task_status) {
    (void)task;
    struct aws_s3_body_write_task_args *body_write = arg;
    struct aws_s3_meta_request *meta_request = body_write->meta_request;
    struct aws_s3_client *client = meta_request->client;

    int error_code = AWS_ERROR_SUCCESS;

    if (task_status == AWS_TASK_STATUS_RUN_READY) {
        struct aws_byte_cursor body = aws_byte_cursor_from_buf(&body_write->body);
        uint64_t file_offset = 0;
        if (s_s3_recv_file_offset(meta_request, body_write->s3_object_range_start, &file_offset) != AWS_OP_SUCCESS) {
            /* Nowhere to put the bytes, so the write never starts and its timing is never bracketed. */
            error_code = aws_last_error_or_unknown();
        } else {
            /* Success */
            AWS_LOGF_TRACE(
                AWS_LS_S3_META_REQUEST,
                "id=%p: Writer %zu writing part %" PRIu32 ", %zu bytes, object range start %" PRIu64
                " -> file offset %" PRIu64 ".",
                (void *)meta_request,
                body_write->write_loop_index,
                body_write->part_number,
                body.len,
                body_write->s3_object_range_start,
                file_offset);

            if (body_write->metrics != NULL) {
                aws_high_res_clock_get_ticks((uint64_t *)&body_write->metrics->time_metrics.deliver_start_timestamp_ns);
            }

            if (s_s3_recv_file_write(
                    meta_request,
                    &meta_request->recv_file_write_fd_slots[body_write->write_loop_index],
                    file_offset,
                    &body) != AWS_OP_SUCCESS) {
                error_code = aws_last_error_or_unknown();
                AWS_LOGF_ERROR(
                    AWS_LS_S3_META_REQUEST,
                    "id=%p Failed writing part %" PRIu32 " to file. aws-error:%s",
                    (void *)meta_request,
                    body_write->part_number,
                    aws_error_name(error_code));
            }

            if (body_write->metrics != NULL) {
                struct aws_s3_request_metrics *metrics = body_write->metrics;
                aws_high_res_clock_get_ticks((uint64_t *)&metrics->time_metrics.deliver_end_timestamp_ns);
                metrics->time_metrics.deliver_duration_ns =
                    metrics->time_metrics.deliver_end_timestamp_ns - metrics->time_metrics.deliver_start_timestamp_ns;
            }
        }

        if (error_code == AWS_ERROR_SUCCESS && client->enable_read_backpressure) {
            aws_s3_meta_request_increment_read_window(meta_request, body_write->body.len);
        }
    } else {
        error_code = AWS_ERROR_S3_CANCELED;
    }

    /* Completion accounting. Runs for every task status, including a cancelled event loop, so the
     * parked-write chain below always keeps moving and the meta request can reach its finish state. */
    {
        /* BEGIN CRITICAL SECTION */
        aws_s3_meta_request_lock_synced_data(meta_request);

        ++meta_request->synced_data.num_parts_delivery_completed;

        if (error_code == AWS_ERROR_SUCCESS) {

            if (s_mark_part_delivered(meta_request, body_write->part_number) != AWS_OP_SUCCESS) {
                aws_s3_meta_request_set_fail_synced(meta_request, NULL, aws_last_error());
            }
            if (s_s3_meta_request_record_delivered_part_synced(
                    meta_request,
                    body_write->part_number,
                    body_write->s3_object_range_start,
                    body_write->s3_object_range_end,
                    body_write->body.len) != AWS_OP_SUCCESS) {
                aws_s3_meta_request_set_fail_synced(meta_request, NULL, aws_last_error_or_unknown());
            }
        } else {
            /* A body that never reached the file must fail the meta request, otherwise the caller is
             * handed a silently truncated file. */
            aws_s3_meta_request_set_fail_synced(meta_request, NULL, error_code);
        }

        /* Telemetry must stay on the meta request's io_event_loop and non-overlapping, so hand the
         * metrics to the ordered event path rather than invoking the callback from this thread. */
        if (body_write->metrics != NULL) {
            if (meta_request->telemetry_callback != NULL) {
                struct aws_s3_meta_request_event event = {.type = AWS_S3_META_REQUEST_EVENT_TELEMETRY};
                event.u.telemetry.metrics = body_write->metrics;
                body_write->metrics = NULL;
                aws_s3_meta_request_add_event_for_delivery_synced(meta_request, &event);
            } else {
                body_write->metrics = aws_s3_request_metrics_release(body_write->metrics);
            }
        }
        size_t prev_pending = aws_atomic_fetch_sub(&client->num_pending_writes, 1);
        AWS_FATAL_ASSERT(prev_pending > 0);

        aws_s3_meta_request_unlock_synced_data(meta_request);
        /* END CRITICAL SECTION */
    }

    /* Order matters: the destroy below releases this task's meta request reference, which may be the last one and
     * take the client's last reference with it, after which the client can be freed at any moment. So the client
     * must be used before the destroy, never after. */
    aws_s3_client_schedule_process_work(client);
    /* Releases the buffer ticket, which is what frees this part's pool memory. */
    s_s3_body_write_task_args_destroy(body_write);
}

/* Deliver events in event_delivery_array.
 * This task runs on the meta-request's io_event_loop thread. */
static void s_s3_meta_request_event_delivery_task(struct aws_task *task, void *arg, enum aws_task_status task_status) {
    (void)task;
    (void)task_status;
    struct aws_s3_meta_request *meta_request = arg;
    AWS_PRECONDITION(meta_request);
    AWS_PRECONDITION(meta_request->vtable);

    struct aws_s3_client *client = meta_request->client;
    AWS_PRECONDITION(client);

    /* Client owns this event loop group. A cancel should not be possible. */
    AWS_ASSERT(task_status == AWS_TASK_STATUS_RUN_READY);

    /* Swap contents of synced_data.event_delivery_array into this pre-allocated array-list, then process events */
    struct aws_array_list *event_delivery_array = &meta_request->io_threaded_data.event_delivery_array;
    AWS_FATAL_ASSERT(aws_array_list_length(event_delivery_array) == 0);

    struct aws_array_list incomplete_deliver_events_array;
    aws_array_list_init_dynamic(
        &incomplete_deliver_events_array, meta_request->allocator, 1, sizeof(struct aws_s3_meta_request_event));

    /* If an error occurs, don't fire callbacks anymore. */
    int error_code = AWS_ERROR_SUCCESS;
    uint32_t num_parts_delivered = 0;
    uint64_t num_bytes_delivered = 0;
    uint64_t bytes_allowed_to_deliver = 0;
    bool out_of_order_delivery = false;

    /* Parts fully delivered during this tick, when delivery is out of order. Recorded at the end so the
     * contiguous prefix advances under the lock in one pass, rather than taking it per part. Unused on
     * the ordered path, where the prefix and the total simply advance together. */
    struct aws_array_list completed_deliveries;
    aws_array_list_init_dynamic(
        &completed_deliveries, meta_request->allocator, 1, sizeof(struct aws_s3_delivery_tracking_record));

    /* BEGIN CRITICAL SECTION */
    {
        aws_s3_meta_request_lock_synced_data(meta_request);

        aws_array_list_swap_contents(event_delivery_array, &meta_request->synced_data.event_delivery_array);
        meta_request->synced_data.event_delivery_active = true;
        meta_request->synced_data.event_delivery_task_scheduled = false;

        if (aws_s3_meta_request_has_finish_result_synced(meta_request)) {
            error_code = AWS_ERROR_S3_CANCELED;
        }

        bytes_allowed_to_deliver = meta_request->synced_data.read_window_running_total -
                                   meta_request->io_threaded_data.num_bytes_delivery_completed;

        aws_s3_meta_request_unlock_synced_data(meta_request);
    }
    /* END CRITICAL SECTION */

    /* Resolved before the first body was queued, so it cannot change while this task runs. */
    out_of_order_delivery = aws_atomic_load_int(&meta_request->out_of_order_delivery) != 0;
    if (bytes_allowed_to_deliver > SIZE_MAX) {
        bytes_allowed_to_deliver = SIZE_MAX;
    }

    /* Deliver all events */
    for (size_t event_i = 0; event_i < aws_array_list_length(event_delivery_array); ++event_i) {
        struct aws_s3_meta_request_event event;
        aws_array_list_get_at(event_delivery_array, &event, event_i);
        switch (event.type) {

            case AWS_S3_META_REQUEST_EVENT_RESPONSE_BODY: {
                struct aws_s3_request *request = event.u.response_body.completed_request;
                size_t bytes_delivered_for_request = event.u.response_body.bytes_delivered;
                AWS_ASSERT(meta_request == request->meta_request);
                bool delivery_incomplete = false;
                struct aws_byte_cursor response_body = aws_byte_cursor_from_buf(&request->send_data.response_body);

                /* 1. Early return: empty body */
                if (response_body.len == 0) {
                    aws_atomic_fetch_sub(&client->stats.num_requests_streaming_response, 1);
                    ++num_parts_delivered;

                    if (error_code == AWS_ERROR_SUCCESS) {
                        /* Still has to close its slot in the prefix, or every later part parks behind
                         * a part that was never going to contribute any bytes. */
                        struct aws_s3_delivery_tracking_record completed = {
                            .part_number = request->part_number,
                            .range_start = request->part_range_start,
                            .range_end = request->part_range_end,
                            .bytes = 0,
                        };
                        aws_array_list_push_back(&completed_deliveries, &completed);
                    }
                    request->send_data.metrics =
                        s_s3_request_finish_up_and_release_metrics(request->send_data.metrics, meta_request);
                    aws_s3_request_release(request);
                    break;
                }

                /* 2. Backpressure: limit how many bytes we deliver this tick */
                if (s_should_apply_backpressure(request)) {
                    aws_byte_cursor_advance(&response_body, bytes_delivered_for_request);
                    if (response_body.len > (size_t)bytes_allowed_to_deliver) {
                        response_body.len = (size_t)bytes_allowed_to_deliver;
                        delivery_incomplete = true;
                    }
                    bytes_allowed_to_deliver -= response_body.len;
                } else {
                    AWS_FATAL_ASSERT(bytes_delivered_for_request == 0);
                }

                /* Nothing to deliver after backpressure — re-queue and move on */
                if (response_body.len == 0) {
                    aws_array_list_push_front(&incomplete_deliver_events_array, &event);
                    break;
                }

                /* 3. Sequential order validation */
                uint64_t delivery_range_start = request->part_range_start + bytes_delivered_for_request;
                AWS_ASSERT(request->part_number >= 1);
                if (!out_of_order_delivery) {
                    /* Check sequential order when we are not deliverying out of order. */
                    if (request->part_number == 1) {
                        meta_request->io_threaded_data.next_deliver_range_start = delivery_range_start;
                    }
                    if (delivery_range_start != meta_request->io_threaded_data.next_deliver_range_start) {
                        AWS_LOGF_ERROR(
                            AWS_LS_S3_META_REQUEST,
                            "id=%p: Unexpected code error. Please report the error to the team, "
                            "delivery_range_start:%" PRIu64 ", next_deliver_range_start:%" PRIu64 ".",
                            (void *)meta_request,
                            delivery_range_start,
                            meta_request->io_threaded_data.next_deliver_range_start);
                        error_code = AWS_ERROR_INVALID_STATE;
                    }
                    meta_request->io_threaded_data.next_deliver_range_start += response_body.len;
                }

                /* 4. Checksum update */
                if (error_code == AWS_ERROR_SUCCESS && meta_request->meta_request_level_running_response_sum &&
                    !meta_request->meta_request_level_checksum_combinable) {
                    /* Non-combinable algorithm, so the whole-object checksum can only be built by feeding it
                     * bytes in object order, which is what this delivery loop guarantees. Combinable
                     * algorithms fold in each part's own checksum when the part completes instead, so there
                     * is nothing to do here. */
                    AWS_ASSERT(!out_of_order_delivery); /* a non-combinable whole-object checksum ruled it out */
                    if (aws_checksum_update(meta_request->meta_request_level_running_response_sum, &response_body)) {
                        error_code = aws_last_error();
                        AWS_LOGF_ERROR(
                            AWS_LS_S3_META_REQUEST,
                            "id=%p Failed to update checksum. last error:%s",
                            (void *)meta_request,
                            aws_error_name(error_code));
                    }
                }

                /* 5. Deliver body to sink (file or callback) */
                if (error_code == AWS_ERROR_SUCCESS) {
                    if (request->send_data.metrics) {
                        aws_high_res_clock_get_ticks(
                            (uint64_t *)&request->send_data.metrics->time_metrics.deliver_start_timestamp_ns);
                    }

                    if (s_deliver_body_to_sink(meta_request, &response_body, delivery_range_start, request) !=
                        AWS_OP_SUCCESS) {
                        /* Capture the reason before the metrics calls below, since any of them could
                         * overwrite the thread's last error. */
                        error_code = aws_last_error_or_unknown();
                    }

                    if (request->send_data.metrics) {
                        struct aws_s3_request_metrics *metric = request->send_data.metrics;
                        aws_high_res_clock_get_ticks((uint64_t *)&metric->time_metrics.deliver_end_timestamp_ns);
                        AWS_ASSERT(metric->time_metrics.deliver_start_timestamp_ns != 0);
                        metric->time_metrics.deliver_duration_ns = metric->time_metrics.deliver_end_timestamp_ns -
                                                                   metric->time_metrics.deliver_start_timestamp_ns;
                    }
                }

                /* 6. Completion tracking */
                event.u.response_body.bytes_delivered += response_body.len;
                meta_request->io_threaded_data.num_bytes_delivery_completed += response_body.len;
                if (error_code == AWS_ERROR_SUCCESS) {
                    /* Only count bytes the sink actually accepted. */
                    num_bytes_delivered += response_body.len;
                }

                if (!delivery_incomplete || error_code != AWS_ERROR_SUCCESS) {
                    aws_atomic_fetch_sub(&client->stats.num_requests_streaming_response, 1);
                    ++num_parts_delivered;

                    if (error_code == AWS_ERROR_SUCCESS) {
                        struct aws_s3_delivery_tracking_record completed = {
                            .part_number = request->part_number,
                            .range_start = request->part_range_start,
                            .range_end = request->part_range_end,
                            .bytes = event.u.response_body.bytes_delivered,
                        };
                        aws_array_list_push_back(&completed_deliveries, &completed);
                    }
                    request->send_data.metrics =
                        s_s3_request_finish_up_and_release_metrics(request->send_data.metrics, meta_request);
                    aws_s3_request_release(request);
                } else {
                    /* Incomplete delivery — re-queue for next tick */
                    aws_array_list_push_front(&incomplete_deliver_events_array, &event);
                }
            } break;

            case AWS_S3_META_REQUEST_EVENT_PROGRESS: {
                if (error_code == AWS_ERROR_SUCCESS && meta_request->progress_callback != NULL) {
                    /* Don't report 0 byte progress events.
                     * The reasoning behind this is:
                     *
                     * In some code paths, when no data is transferred, there are no progress events,
                     * but in other code paths there might be one progress event of 0 bytes.
                     * We want to be consistent, either:
                     * - REPORT AT LEAST ONCE: even if no data is being transferred.
                     *   This would require finding every code path where no progress events are sent,
                     *   and sending an appropriate progress event, even if it's for 0 bytes.
                     *   One example of ending early is: when resuming a paused upload,
                     *   we do ListParts on the UploadID, and if that 404s we assume the
                     *   previous "paused" meta-request actually completed,
                     *   and so we immediately end the "resuming" meta-request
                     *   as successful without sending any further HTTP requests.
                     *   It would be tough to accurately report progress here because
                     *   we don't know the total size, since we never read the request body,
                     *   and didn't get any info about the previous upload.
                     * OR
                     * - NEVER REPORT ZERO BYTES: even if that means no progress events at all.
                     *   This is easy to do. We'd only send progress events when data is transferred,
                     *   and if a 0 byte event slips through somehow, just check before firing the callback.
                     * Since the NEVER REPORT ZERO BYTES path is simpler to implement, we went with that. */
                    if (event.u.progress.info.bytes_transferred > 0) {
                        meta_request->progress_callback(meta_request, &event.u.progress.info, meta_request->user_data);
                    }
                }
            } break;

            case AWS_S3_META_REQUEST_EVENT_TELEMETRY: {
                struct aws_s3_request_metrics *metrics = event.u.telemetry.metrics;
                AWS_FATAL_ASSERT(meta_request->telemetry_callback != NULL);
                AWS_FATAL_ASSERT(metrics != NULL);

                event.u.telemetry.metrics =
                    s_s3_request_finish_up_and_release_metrics(event.u.telemetry.metrics, meta_request);
            } break;

            default:
                AWS_FATAL_ASSERT(false);
        }
    }

    /* Done delivering events */
    aws_array_list_clear(event_delivery_array);

    /* BEGIN CRITICAL SECTION */
    {
        aws_s3_meta_request_lock_synced_data(meta_request);
        if (error_code != AWS_ERROR_SUCCESS) {
            aws_s3_meta_request_set_fail_synced(meta_request, NULL, error_code);
        }
        if (aws_array_list_length(&incomplete_deliver_events_array) > 0) {
            /* Only if we don't have any window to deliver the bytes, we will have incomplete parts. */
            AWS_FATAL_ASSERT(bytes_allowed_to_deliver == 0);
            /* Push the incomplete events back to the queue */
            for (size_t i = 0; i < aws_array_list_length(&incomplete_deliver_events_array); ++i) {
                struct aws_s3_meta_request_event event;
                aws_array_list_get_at(&incomplete_deliver_events_array, &event, i);
                /* Push the incomplete one to the front of the queue. */
                aws_array_list_push_front(&meta_request->synced_data.event_delivery_array, &event);
            }
            /* As we push to the event delivery array, we check if we need to schedule another delivery by if there
             * is space to make the delivery or not. */
            bytes_allowed_to_deliver = meta_request->synced_data.read_window_running_total -
                                       meta_request->io_threaded_data.num_bytes_delivery_completed;
            if (bytes_allowed_to_deliver > 0 && error_code == AWS_ERROR_SUCCESS) {
                /* We have more space now, let's try another delivery now. */
                aws_s3_meta_request_add_event_for_delivery_synced(meta_request, NULL);
            }
        }

        meta_request->synced_data.num_parts_delivery_completed += num_parts_delivered;

        /* Mark every delivered part in the validation mask and update byte accounting.
         * completed_deliveries is populated by both the ordered and out-of-order paths now. */
        for (size_t i = 0; i < aws_array_list_length(&completed_deliveries); ++i) {
            struct aws_s3_delivery_tracking_record completed;
            aws_array_list_get_at(&completed_deliveries, &completed, i);

            if (s_mark_part_delivered(meta_request, completed.part_number) != AWS_OP_SUCCESS) {
                aws_s3_meta_request_set_fail_synced(meta_request, NULL, aws_last_error());
            }

            if (out_of_order_delivery) {
                if (s_s3_meta_request_record_delivered_part_synced(
                        meta_request,
                        completed.part_number,
                        completed.range_start,
                        completed.range_end,
                        completed.bytes) != AWS_OP_SUCCESS) {
                    /* The prefix is already inconsistent, so recording the rest of this tick would only
                     * build on it. */
                    aws_s3_meta_request_set_fail_synced(meta_request, NULL, aws_last_error_or_unknown());
                    break;
                }
            }
        }
        if (!out_of_order_delivery) {
            /* This path delivers in object order, so the prefix and the total advance together. */
            meta_request->synced_data.num_bytes_delivered += num_bytes_delivered;
            meta_request->synced_data.num_bytes_delivered_total += num_bytes_delivered;
        }
        meta_request->synced_data.event_delivery_active = false;
        aws_s3_meta_request_unlock_synced_data(meta_request);
    }
    /* END CRITICAL SECTION */
    aws_array_list_clean_up(&incomplete_deliver_events_array);
    aws_array_list_clean_up(&completed_deliveries);

    aws_s3_client_schedule_process_work(client);
    aws_s3_meta_request_release(meta_request);
}

static void s_s3_meta_request_body_streaming_push_synced(
    struct aws_s3_meta_request *meta_request,
    struct aws_s3_request *request) {
    ASSERT_SYNCED_DATA_LOCK_HELD(meta_request);
    AWS_PRECONDITION(meta_request);
    AWS_PRECONDITION(request);

    AWS_ASSERT(request->meta_request == meta_request);

    aws_s3_request_acquire(request);

    aws_priority_queue_push(&meta_request->synced_data.pending_body_streaming_requests, &request);
}

static struct aws_s3_request *s_s3_meta_request_body_streaming_pop_next_synced(
    struct aws_s3_meta_request *meta_request) {
    AWS_PRECONDITION(meta_request);
    ASSERT_SYNCED_DATA_LOCK_HELD(meta_request);

    if (0 == aws_priority_queue_size(&meta_request->synced_data.pending_body_streaming_requests)) {
        return NULL;
    }

    struct aws_s3_request **top_request = NULL;

    aws_priority_queue_top(&meta_request->synced_data.pending_body_streaming_requests, (void **)&top_request);

    AWS_ASSERT(top_request);

    AWS_FATAL_ASSERT(*top_request);

    if ((*top_request)->part_number != meta_request->synced_data.next_streaming_part) {
        return NULL;
    }

    struct aws_s3_request *request = NULL;
    aws_priority_queue_pop(&meta_request->synced_data.pending_body_streaming_requests, (void **)&request);

    ++meta_request->synced_data.next_streaming_part;

    return request;
}

void aws_s3_meta_request_finish(struct aws_s3_meta_request *meta_request) {
    AWS_PRECONDITION(meta_request);
    AWS_PRECONDITION(meta_request->vtable);
    AWS_PRECONDITION(meta_request->vtable->finish);

    meta_request->vtable->finish(meta_request);
}

/* Used to reopen recv_filepath in read-only mode after the write handle has been closed, solely to
 * query its last-modified time for the resume token (see aws_s3_meta_request_finish_default). */
AWS_STATIC_STRING_FROM_LITERAL(s_recv_file_reopen_mode, "rb");

void aws_s3_meta_request_finish_default(struct aws_s3_meta_request *meta_request) {
    AWS_PRECONDITION(meta_request);

    bool already_finished = false;
    struct aws_linked_list release_request_list;
    aws_linked_list_init(&release_request_list);

    aws_simple_completion_callback *pending_async_write_waker = NULL;
    void *pending_async_write_waker_user_data = NULL;

    bool is_async_paused = false;
    bool is_error = false;
    aws_s3_meta_request_pause_complete_fn *pause_callback = NULL;
    void *pause_user_data = NULL;
    struct aws_s3_meta_request_resume_token *token = NULL;

    struct aws_s3_meta_request_result finish_result;
    AWS_ZERO_STRUCT(finish_result);

    /* BEGIN CRITICAL SECTION */
    {
        aws_s3_meta_request_lock_synced_data(meta_request);

        if (meta_request->synced_data.state == AWS_S3_META_REQUEST_STATE_FINISHED) {
            already_finished = true;
            goto unlock;
        }

        meta_request->synced_data.state = AWS_S3_META_REQUEST_STATE_FINISHED;

        /* Validate the whole-object checksum before anything below reads the outcome. A mismatch is only found
         * here, after every part already passed on its own, and it must count as the failure it is: for the
         * error and resume-token decisions just below, and for recv_file_delete_on_failure after the lock is
         * released. */
        bool whole_object_mismatch =
            s_validate_meta_request_checksum_on_finish(meta_request, &meta_request->synced_data.finish_result);

        /* Read pause state and build a resume token while still holding the lock. */
        if (meta_request->synced_data.async_pause_requested) {
            is_async_paused = true;
            pause_callback = meta_request->synced_data.pause_complete_callback;
            pause_user_data = meta_request->synced_data.pause_complete_user_data;
        } else if (
            meta_request->synced_data.finish_result.error_code != AWS_ERROR_SUCCESS &&
            meta_request->synced_data.finish_result.error_code != AWS_ERROR_S3_PAUSED) {
            is_error = true;
        }

        /* No error token when recv_file_delete_on_failure will discard the partial file on error,
         * since the token would describe deleted state. Nor after a whole-object checksum mismatch, with or
         * without a file: every byte was received, so a resume would have nothing left to download and would
         * report the bad data as complete. The on_error_resume_token callback still fires with a NULL token
         * below. Async pause is unaffected as pause is not treated as an error.
         **/
        bool skip_error_token =
            (meta_request->recv_filepath != NULL && meta_request->recv_file_delete_on_failure) || whole_object_mismatch;

        if ((is_async_paused || (is_error && meta_request->on_error_resume_token && !skip_error_token)) &&
            meta_request->vtable->build_resume_token_synced != NULL) {
            token = meta_request->vtable->build_resume_token_synced(meta_request);
        }

        /* Clean out the pending-stream-to-caller priority queue*/
        while (aws_priority_queue_size(&meta_request->synced_data.pending_body_streaming_requests) > 0) {
            struct aws_s3_request *request = NULL;
            aws_priority_queue_pop(&meta_request->synced_data.pending_body_streaming_requests, (void **)&request);
            AWS_FATAL_ASSERT(request != NULL);

            aws_linked_list_push_back(&release_request_list, &request->node);
        }

        /* Clean out any pending async-write future */
        if (meta_request->synced_data.async_write.buffered_data_ticket_future != NULL) {
            /* We're waiting on the buffer pool to fulfill a (deferred) ticket reservation.
             * Error it out so its completion callback fires; that callback owns invoking the
             * waker and cleaning up the future (and releasing the ref it holds on the meta request).
             * NOTE: set_error schedules the callback as an event-loop task (it was registered with
             * register_event_loop_callback), so this does NOT run the callback synchronously here. */
            aws_future_s3_buffer_ticket_set_error(
                meta_request->synced_data.async_write.buffered_data_ticket_future, AWS_ERROR_S3_CANCELED);
        } else if (meta_request->synced_data.async_write.waker != NULL) {
            pending_async_write_waker = meta_request->synced_data.async_write.waker;
            pending_async_write_waker_user_data = meta_request->synced_data.async_write.waker_user_data;

            meta_request->synced_data.async_write.waker = NULL;
            meta_request->synced_data.async_write.waker_user_data = NULL;
        }
        finish_result = meta_request->synced_data.finish_result;
        AWS_ZERO_STRUCT(meta_request->synced_data.finish_result);

    unlock:
        aws_s3_meta_request_unlock_synced_data(meta_request);
    }
    /* END CRITICAL SECTION */

    if (already_finished) {
        return;
    }

    if (pending_async_write_waker != NULL) {
        AWS_LOGF_TRACE(
            AWS_LS_S3_META_REQUEST,
            "id=%p: Invoking write waker, due to meta request's early finish",
            (void *)meta_request);
        pending_async_write_waker(pending_async_write_waker_user_data);
    }

    /* Every byte must be out of our hands before the mtime probe or the delete below. */
    s_s3_meta_request_close_write_fds(meta_request);

    if (meta_request->recv_filepath != NULL) {
        bool delete_on_failure = finish_result.error_code && finish_result.error_code != AWS_ERROR_S3_PAUSED &&
                                 meta_request->recv_file_delete_on_failure;

        /* Capture the file's last-modified time for the resume token. This must happen after the
         * write descriptors are closed so the mtime reflects all written data. */
        if (token != NULL && !delete_on_failure) {
            FILE *reopened_file = aws_fopen_safe(meta_request->recv_filepath, s_recv_file_reopen_mode);
            if (reopened_file != NULL) {
                uint64_t last_modified_ns = 0;
                if (aws_file_get_last_modified_epoch(reopened_file, &last_modified_ns) == AWS_OP_SUCCESS) {
                    token->file_last_modified_epoch_ns = last_modified_ns;
                }
                fclose(reopened_file);
            }
        }

        if (delete_on_failure) {
            aws_file_delete(meta_request->recv_filepath);
        }

        /* Set on failure too, not just success: the file is already deleted here, and by the time destroy runs
         * the caller may have been told of the failure and put a new file at this path. */
        meta_request->recv_file_finalized = true;
    }

    /* Fire pause/error resume-token callbacks before the general finish callback below,
     * so callers see the resume token before the operation is reported as complete.
     * Both callbacks fire exactly once whenever registered — bindings may wrap them in
     * futures, so skipping the invocation could deadlock the caller. A NULL token means
     * no resumable state was captured. */
    if (is_error && meta_request->on_error_resume_token) {
        meta_request->on_error_resume_token(meta_request, token, finish_result.error_code, meta_request->user_data);
    }
    if (is_async_paused && pause_callback != NULL) {
        /* Token may be NULL if the request type has no resumable state — resume restarts from the beginning. */
        pause_callback(meta_request, token, AWS_ERROR_SUCCESS, pause_user_data);
    }
    token = aws_s3_meta_request_resume_token_release(token);

    while (!aws_linked_list_empty(&release_request_list)) {
        struct aws_linked_list_node *request_node = aws_linked_list_pop_front(&release_request_list);
        struct aws_s3_request *release_request = AWS_CONTAINER_OF(request_node, struct aws_s3_request, node);
        AWS_FATAL_ASSERT(release_request != NULL);
        /* This pending-body-streaming request was never moved to the event-delivery queue,
         * so its metrics were never finished. Finish them now. */
        release_request->send_data.metrics =
            s_s3_request_finish_up_and_release_metrics(release_request->send_data.metrics, meta_request);
        aws_s3_request_release(release_request);
    }

    if (meta_request->headers_callback && finish_result.error_response_headers) {
        if (meta_request->headers_callback(
                meta_request,
                finish_result.error_response_headers,
                finish_result.response_status,
                meta_request->user_data)) {
            finish_result.error_code = aws_last_error_or_unknown();
        }
        meta_request->headers_callback = NULL;
    }

    AWS_LOGF_DEBUG(
        AWS_LS_S3_META_REQUEST,
        "id=%p Meta request finished with error code %d (%s)",
        (void *)meta_request,
        finish_result.error_code,
        aws_error_str(finish_result.error_code));

    /* As the meta request has been finished with any HTTP message, we can safely release the http message that
     * hold. So that, the downstream high level language doesn't need to wait for shutdown to clean related resource
     * (eg: input stream) */
    meta_request->request_body_async_stream = aws_async_input_stream_release(meta_request->request_body_async_stream);

    if (meta_request->request_body_parallel_stream) {
        struct aws_future_void *shutdown_future =
            aws_parallel_input_stream_get_shutdown_future(meta_request->request_body_parallel_stream);
        aws_parallel_input_stream_release(meta_request->request_body_parallel_stream);
        /* NULL it out so the destroy path can tell an already-torn-down stream from a
         * half-initialized meta request that never finished and still owns one. */
        meta_request->request_body_parallel_stream = NULL;
        aws_future_void_wait(shutdown_future, MAX_TIMEOUT_NS_P);
        aws_future_void_release(shutdown_future);
    }
    meta_request->initial_request_message = aws_http_message_release(meta_request->initial_request_message);

    if (meta_request->finish_callback != NULL) {
        meta_request->finish_callback(meta_request, &finish_result, meta_request->user_data);
    }

    aws_s3_meta_request_result_clean_up(meta_request, &finish_result);

    aws_s3_endpoint_release(meta_request->endpoint);
    meta_request->endpoint = NULL;

    meta_request->io_event_loop = NULL;
}

struct aws_future_bool *aws_s3_meta_request_read_body(
    struct aws_s3_meta_request *meta_request,
    uint64_t offset,
    struct aws_byte_buf *buffer) {

    AWS_PRECONDITION(meta_request);
    AWS_PRECONDITION(buffer);

    /* If async-stream, simply call read_to_fill() */
    if (meta_request->request_body_async_stream != NULL) {
        return aws_async_input_stream_read_to_fill(meta_request->request_body_async_stream, buffer);
    }

    /* If parallel-stream, simply call read(), which must fill the buffer and/or EOF */
    if (meta_request->request_body_parallel_stream != NULL) {
        return aws_parallel_input_stream_read(
            meta_request->request_body_parallel_stream, offset, buffer->capacity, buffer);
    }

    /* Further techniques are synchronous... */
    struct aws_future_bool *synchronous_read_future = aws_future_bool_new(meta_request->allocator);

    /* If using async-writes, call function which fills the buffer and/or hits EOF  */
    if (meta_request->request_body_using_async_writes == true) {
        if (offset < meta_request->io_threaded_data.next_read_offset) {
            AWS_LOGF_ERROR(
                AWS_LS_S3_META_REQUEST,
                "id=%p: Async-write read out of order. Last offset was %" PRIu64 " but got %" PRIu64,
                (void *)meta_request,
                meta_request->io_threaded_data.next_read_offset,
                offset);
            aws_future_bool_set_error(synchronous_read_future, AWS_ERROR_INVALID_STATE);
            return synchronous_read_future;
        }

        bool eof = s_s3_meta_request_read_from_pending_async_writes(meta_request, buffer);
        meta_request->io_threaded_data.next_read_offset = offset + buffer->len;
        aws_future_bool_set_result(synchronous_read_future, eof);
        return synchronous_read_future;
    }

    /* Else synchronous aws_input_stream */
    struct aws_input_stream *synchronous_stream =
        aws_http_message_get_body_stream(meta_request->initial_request_message);
    AWS_FATAL_ASSERT(synchronous_stream);

    /* Non-parallel body sources require reads in increasing offset order.
     * If a read arrives below the last offset seen, parts were prepared out of order. */
    if (offset < meta_request->io_threaded_data.next_read_offset) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p: Sequential stream read out of order. Last offset was %" PRIu64 " but got %" PRIu64,
            (void *)meta_request,
            meta_request->io_threaded_data.next_read_offset,
            offset);
        aws_future_bool_set_error(synchronous_read_future, AWS_ERROR_INVALID_STATE);
        return synchronous_read_future;
    }

    /* Keep calling read() until we fill the buffer, or hit EOF */
    struct aws_stream_status status = {.is_end_of_stream = false, .is_valid = true};
    while ((buffer->len < buffer->capacity) && !status.is_end_of_stream) {
        /* Read from stream */
        if (aws_input_stream_read(synchronous_stream, buffer) != AWS_OP_SUCCESS) {
            aws_future_bool_set_error(synchronous_read_future, aws_last_error());
            goto synchronous_read_done;
        }

        /* Check if stream is done */
        if (aws_input_stream_get_status(synchronous_stream, &status) != AWS_OP_SUCCESS) {
            aws_future_bool_set_error(synchronous_read_future, aws_last_error());
            goto synchronous_read_done;
        }
    }

    meta_request->io_threaded_data.next_read_offset = offset;
    aws_future_bool_set_result(synchronous_read_future, status.is_end_of_stream);

synchronous_read_done:
    return synchronous_read_future;
}

void aws_s3_meta_request_result_setup(
    struct aws_s3_meta_request *meta_request,
    struct aws_s3_meta_request_result *result,
    struct aws_s3_request *failed_request,
    int response_status,
    int error_code) {

    if (failed_request != NULL) {
        if (failed_request->send_data.response_headers != NULL) {
            result->error_response_headers = failed_request->send_data.response_headers;
            aws_http_headers_acquire(result->error_response_headers);
        }

        if (failed_request->send_data.response_body.capacity > 0) {
            result->error_response_body = aws_mem_calloc(meta_request->allocator, 1, sizeof(struct aws_byte_buf));

            aws_byte_buf_init_copy(
                result->error_response_body, meta_request->allocator, &failed_request->send_data.response_body);
        }

        result->error_response_operation_name =
            aws_string_new_from_string(meta_request->allocator, failed_request->operation_name);
    }

    result->response_status = response_status;
    result->error_code = error_code;
}

/* Completion callback for a deferred async-write buffer reservation.
 * Runs on the meta request's io_event_loop thread. */
static void s_s3_meta_request_on_async_write_buffer_reserved(void *user_data) {
    struct aws_s3_meta_request *meta_request = user_data;
    AWS_PRECONDITION(meta_request);

    aws_simple_completion_callback *waker = NULL;
    void *waker_user_data = NULL;
    bool schedule_work = false;

    /* BEGIN CRITICAL SECTION */
    {
        aws_s3_meta_request_lock_synced_data(meta_request);

        struct aws_future_s3_buffer_ticket *future = meta_request->synced_data.async_write.buffered_data_ticket_future;
        AWS_FATAL_ASSERT(future != NULL);
        meta_request->synced_data.async_write.buffered_data_ticket_future = NULL;

        int error_code = aws_future_s3_buffer_ticket_get_error(future);
        if (error_code == AWS_ERROR_SUCCESS && !aws_s3_meta_request_has_finish_result_synced(meta_request)) {
            /* Reservation granted. Claim the buffer so the resumed poll_write() can copy data into it. */
            meta_request->synced_data.async_write.buffered_data_ticket =
                aws_future_s3_buffer_ticket_get_result_by_move(future);
            meta_request->synced_data.async_write.buffered_data =
                aws_s3_buffer_ticket_claim(meta_request->synced_data.async_write.buffered_data_ticket);
        } else if (error_code != AWS_ERROR_SUCCESS) {
            /* Reservation failed. Terminate the meta request; the resumed poll_write() will report the
             * failure to the caller. Kick the process-work loop so update() observes the finish result
             * and drives the meta request to completion. */
            if (error_code == AWS_ERROR_S3_CANCELED) {
                AWS_LOGF_TRACE(
                    AWS_LS_S3_META_REQUEST,
                    "id=%p: Async-write buffer reservation canceled; meta request already finishing.",
                    (void *)meta_request);
            } else {
                AWS_LOGF_ERROR(
                    AWS_LS_S3_META_REQUEST,
                    "id=%p: Failed to acquire buffer for async write, error %d (%s).",
                    (void *)meta_request,
                    error_code,
                    aws_error_str(error_code));
            }
            aws_s3_meta_request_set_fail_synced(meta_request, NULL, error_code);
            schedule_work = true;
        } else {
            /* Reservation was granted, but the meta request already finished.
             * Nothing to claim; releasing the future below returns the granted ticket to the pool. */
            AWS_LOGF_TRACE(
                AWS_LS_S3_META_REQUEST,
                "id=%p: Buffer reservation for async write fulfilled after meta request finished; "
                "returning buffer to pool.",
                (void *)meta_request);
        }

        aws_future_s3_buffer_ticket_release(future);

        waker = meta_request->synced_data.async_write.waker;
        meta_request->synced_data.async_write.waker = NULL;
        waker_user_data = meta_request->synced_data.async_write.waker_user_data;
        meta_request->synced_data.async_write.waker_user_data = NULL;

        aws_s3_meta_request_unlock_synced_data(meta_request);
    }
    /* END CRITICAL SECTION */

    if (schedule_work) {
        aws_s3_client_schedule_process_work(meta_request->client);
    }

    if (waker != NULL) {
        AWS_LOGF_TRACE(
            AWS_LS_S3_META_REQUEST,
            "id=%p: Invoking write waker, buffer reservation fulfilled. Ready for more data",
            (void *)meta_request);
        waker(waker_user_data);
    }

    aws_s3_meta_request_release(meta_request);
}

struct aws_s3_meta_request_poll_write_result aws_s3_meta_request_poll_write(
    struct aws_s3_meta_request *meta_request,
    struct aws_byte_cursor data,
    bool eof,
    aws_simple_completion_callback *waker,
    void *user_data) {

    AWS_ASSERT(meta_request);
    AWS_ASSERT(waker);

    struct aws_s3_meta_request_poll_write_result result;
    AWS_ZERO_STRUCT(result);

    /* Set this true, while lock is held, if we're ready to send data */
    bool ready_to_send = false;

    /* Set this true, while lock is held, if write() was called illegally
     * and the meta-request should terminate */
    bool illegal_usage_terminate_meta_request = false;

    /* BEGIN CRITICAL SECTION */
    aws_s3_meta_request_lock_synced_data(meta_request);
    if (aws_s3_meta_request_has_finish_result_synced(meta_request)) {
        /* The meta-request is already complete */
        AWS_LOGF_DEBUG(
            AWS_LS_S3_META_REQUEST,
            "id=%p: Ignoring write(), the meta request is already complete.",
            (void *)meta_request);
        result.error_code = AWS_ERROR_S3_REQUEST_HAS_COMPLETED;

    } else if (!meta_request->request_body_using_async_writes) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p: Illegal call to write(). The meta-request must be configured to send-using-data-writes.",
            (void *)meta_request);
        illegal_usage_terminate_meta_request = true;

    } else if (meta_request->synced_data.async_write.waker != NULL) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p: Illegal call to write(). A waker is already registered.",
            (void *)meta_request);
        illegal_usage_terminate_meta_request = true;

    } else if (meta_request->synced_data.async_write.eof) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST, "id=%p: Illegal call to write(). EOF already set.", (void *)meta_request);
        illegal_usage_terminate_meta_request = true;

    } else if (meta_request->synced_data.async_write.buffered_data.len == meta_request->part_size) {
        /* Can't write more until buffered data is sent. Store waker */
        AWS_LOGF_TRACE(AWS_LS_S3_META_REQUEST, "id=%p: write() pending, waker registered ...", (void *)meta_request);
        meta_request->synced_data.async_write.waker = waker;
        meta_request->synced_data.async_write.waker_user_data = user_data;
        result.is_pending = true;
    } else {
        /* write call is OK */

        /* If we don't already have a buffer, grab one from the pool. */
        if (meta_request->synced_data.async_write.buffered_data_ticket == NULL) {

            struct aws_future_s3_buffer_ticket *buffered_ticket_future;
            /* can_block=true: not granting this right away can block the meta request (deadlock risk
             * if we waited on a normal reservation - see test_s3_many_async_uploads_without_data, and
             * the can_block docs in s3_buffer_pool.h). The default pool grants synchronously (forced
             * buffer); a custom pool may defer, which we handle below. */

            struct aws_s3_buffer_pool_reserve_meta meta = {
                .size = meta_request->part_size,
                .can_block = true,
                .meta_request = meta_request,
                .client = meta_request->client};

            buffered_ticket_future = aws_s3_buffer_pool_reserve(meta_request->client->buffer_pool, meta);
            AWS_FATAL_ASSERT(buffered_ticket_future);

            if (aws_future_s3_buffer_ticket_is_done(buffered_ticket_future)) {
                if (aws_future_s3_buffer_ticket_get_error(buffered_ticket_future) != AWS_OP_SUCCESS) {
                    AWS_LOGF_ERROR(AWS_LS_S3_META_REQUEST, "id=%p: Failed to acquire buffer.", (void *)meta_request);
                    illegal_usage_terminate_meta_request = true;
                } else {
                    meta_request->synced_data.async_write.buffered_data_ticket =
                        aws_future_s3_buffer_ticket_get_result_by_move(buffered_ticket_future);
                    meta_request->synced_data.async_write.buffered_data =
                        aws_s3_buffer_ticket_claim(meta_request->synced_data.async_write.buffered_data_ticket);
                }
                aws_future_s3_buffer_ticket_release(buffered_ticket_future);
            } else {
                /* The pool deferred the reservation. Ownership of buffered_ticket_future moves into
                 * the meta request; the completion callback resumes poll_write() (or, if the meta
                 * request finishes first, finish_default() errors the future) and releases it. */
                AWS_LOGF_TRACE(
                    AWS_LS_S3_META_REQUEST,
                    "id=%p: write() pending, buffer reservation deferred by pool, waker registered ...",
                    (void *)meta_request);

                meta_request->synced_data.async_write.buffered_data_ticket_future = buffered_ticket_future;
                meta_request->synced_data.async_write.waker = waker;
                meta_request->synced_data.async_write.waker_user_data = user_data;
                result.is_pending = true;

                /* Keep the meta request alive until the ticket future callback invokes. */
                aws_s3_meta_request_acquire(meta_request);
                aws_future_s3_buffer_ticket_register_event_loop_callback(
                    buffered_ticket_future,
                    meta_request->io_event_loop,
                    s_s3_meta_request_on_async_write_buffer_reserved,
                    meta_request);
            }
        }

        if (!illegal_usage_terminate_meta_request && !result.is_pending) {
            /* Copy as much data as we can into the buffer */
            struct aws_byte_cursor processed_data =
                aws_byte_buf_write_to_capacity(&meta_request->synced_data.async_write.buffered_data, &data);

            /* Don't store EOF unless we've consumed all data */
            if ((data.len == 0) && eof) {
                meta_request->synced_data.async_write.eof = true;
            }

            /* This write makes us ready to send (EOF, or we have enough data now to send at least 1 part) */
            if (meta_request->synced_data.async_write.eof ||
                meta_request->synced_data.async_write.buffered_data.len == meta_request->part_size) {

                meta_request->synced_data.async_write.ready_to_send = true;
                ready_to_send = true;
            }

            AWS_LOGF_TRACE(
                AWS_LS_S3_META_REQUEST,
                "id=%p: write(data=%zu, eof=%d) processed=%zu remainder:%zu previously-buffered=%zu. %s"
                "part...",
                (void *)meta_request,
                data.len + processed_data.len /*original data.len*/,
                eof /*eof*/,
                processed_data.len /*processed*/,
                data.len /*remainder*/,
                meta_request->synced_data.async_write.buffered_data.len - processed_data.len /*previously-buffered*/,
                ready_to_send ? "Ready to upload part..." : "Not enough data to upload." /*msg*/);

            result.bytes_processed = processed_data.len;
        }
    }

    if (illegal_usage_terminate_meta_request) {
        result.error_code = AWS_ERROR_INVALID_STATE;
        aws_s3_meta_request_set_fail_synced(meta_request, NULL, AWS_ERROR_INVALID_STATE);
    }

    aws_s3_meta_request_unlock_synced_data(meta_request);
    /* END CRITICAL SECTION */

    if (ready_to_send || illegal_usage_terminate_meta_request) {
        /* Schedule the work task, to continue processing the meta-request */
        aws_s3_client_schedule_process_work(meta_request->client);
    }

    /* Assert that exactly 1 result field is set (OR they're all zero because data.len was zero) */
    AWS_ASSERT(
        (result.is_pending ^ result.error_code ^ result.bytes_processed) ||
        (!result.is_pending && !result.error_code && !result.bytes_processed && !data.len));
    return result;
}

struct aws_s3_meta_request_async_write_job {
    struct aws_s3_meta_request *meta_request;
    struct aws_future_void *write_future;
    struct aws_byte_cursor data;
    bool eof;
};

/* Do async job where, under the hood, aws_s3_meta_request_write()
 * calls aws_s3_meta_request_poll_write() in a loop until all data is written */
static void s_s3_meta_request_async_write_job_loop(void *user_data) {

    struct aws_s3_meta_request_async_write_job *job = user_data;

    int error_code = 0;

    /* Call poll_write() until we can't anymore.
     * It MUST be called at least once, hence the do-while */
    do {
        struct aws_s3_meta_request_poll_write_result poll_result = aws_s3_meta_request_poll_write(
            job->meta_request,
            job->data,
            job->eof,
            s_s3_meta_request_async_write_job_loop /*waker*/,
            job /*user_data*/);

        if (poll_result.is_pending) {
            /* We'll resume this loop when waker fires */
            return;

        } else if (poll_result.error_code) {
            error_code = poll_result.error_code;

        } else {
            aws_byte_cursor_advance(&job->data, poll_result.bytes_processed);
        }
    } while (error_code == AWS_ERROR_SUCCESS && job->data.len > 0);

    /* cleanup */
    struct aws_allocator *allocator = job->meta_request->allocator;
    if (error_code) {
        aws_future_void_set_error(job->write_future, error_code);
    } else {
        aws_future_void_set_result(job->write_future);
    }
    aws_future_void_release(job->write_future);
    aws_mem_release(allocator, job);
}

struct aws_future_void *aws_s3_meta_request_write(
    struct aws_s3_meta_request *meta_request,
    struct aws_byte_cursor data,
    bool eof) {

    struct aws_future_void *write_future = aws_future_void_new(meta_request->allocator);

    struct aws_s3_meta_request_async_write_job *job =
        aws_mem_calloc(meta_request->allocator, 1, sizeof(struct aws_s3_meta_request_async_write_job));
    job->meta_request = meta_request;
    job->write_future = aws_future_void_acquire(write_future);
    job->data = data;
    job->eof = eof;

    s_s3_meta_request_async_write_job_loop(job);

    return write_future;
}

/* For async-writes this is only called after aws_s3_meta_request_poll_write()
 * already filled a buffer with enough data for the next part.
 * In fact, the dest buffer being passed in is the same one we already filled. */
static bool s_s3_meta_request_read_from_pending_async_writes(
    struct aws_s3_meta_request *meta_request,
    struct aws_byte_buf *dest) {

    /* BEGIN CRITICAL SECTION */
    aws_s3_meta_request_lock_synced_data(meta_request);

    /* Assert that dest buffer is in fact the same one we already filled */
    AWS_ASSERT(
        meta_request->synced_data.async_write.buffered_data.len == dest->len &&
        meta_request->synced_data.async_write.buffered_data.buffer == dest->buffer);
    (void)dest;

    /* Assert that ticket for this buffer is no longer owned by the aws_s3_meta_request
     * (ownership was moved to aws_s3_request) */
    AWS_ASSERT(meta_request->synced_data.async_write.buffered_data_ticket == NULL);

    /* Assert we filled the dest buffer, unless this is the final write */
    AWS_ASSERT(dest->len == dest->capacity || meta_request->synced_data.async_write.eof);

    /* Reset things so we're ready to receive the next aws_s3_meta_request_poll_write() */
    meta_request->synced_data.async_write.ready_to_send = false;
    AWS_ZERO_STRUCT(meta_request->synced_data.async_write.buffered_data);

    bool eof = meta_request->synced_data.async_write.eof;

    aws_simple_completion_callback *waker = meta_request->synced_data.async_write.waker;
    meta_request->synced_data.async_write.waker = NULL;

    void *waker_user_data = meta_request->synced_data.async_write.waker_user_data;
    meta_request->synced_data.async_write.waker_user_data = NULL;

    aws_s3_meta_request_unlock_synced_data(meta_request);
    /* END CRITICAL SECTION */

    /* Don't hold locks while triggering the user's waker callback */
    if (waker != NULL) {
        AWS_LOGF_TRACE(
            AWS_LS_S3_META_REQUEST, "id=%p: Invoking write waker. Ready for more data", (void *)meta_request);
        waker(waker_user_data);
    }

    return eof;
}

void aws_s3_meta_request_result_clean_up(
    struct aws_s3_meta_request *meta_request,
    struct aws_s3_meta_request_result *result) {
    AWS_PRECONDITION(meta_request);
    AWS_PRECONDITION(result);

    aws_http_headers_release(result->error_response_headers);

    if (result->error_response_body != NULL) {
        aws_byte_buf_clean_up(result->error_response_body);
        aws_mem_release(meta_request->allocator, result->error_response_body);
    }

    aws_string_destroy(result->error_response_operation_name);

    AWS_ZERO_STRUCT(*result);
}

bool aws_s3_meta_request_checksum_config_has_algorithm(
    struct aws_s3_meta_request *meta_request,
    enum aws_s3_checksum_algorithm algorithm) {
    AWS_PRECONDITION(meta_request);

    switch (algorithm) {
        case AWS_SCA_CRC64NVME:
            return meta_request->checksum_config.response_checksum_algorithms.crc64nvme;
        case AWS_SCA_CRC32C:
            return meta_request->checksum_config.response_checksum_algorithms.crc32c;
        case AWS_SCA_CRC32:
            return meta_request->checksum_config.response_checksum_algorithms.crc32;
        case AWS_SCA_SHA1:
            return meta_request->checksum_config.response_checksum_algorithms.sha1;
        case AWS_SCA_SHA256:
            return meta_request->checksum_config.response_checksum_algorithms.sha256;
        case AWS_SCA_SHA512:
            return meta_request->checksum_config.response_checksum_algorithms.sha512;
        case AWS_SCA_XXHASH64:
            return meta_request->checksum_config.response_checksum_algorithms.xxhash64;
        case AWS_SCA_XXHASH3_64:
            return meta_request->checksum_config.response_checksum_algorithms.xxhash3_64;
        case AWS_SCA_XXHASH3_128:
            return meta_request->checksum_config.response_checksum_algorithms.xxhash3_128;
        default:
            return false;
    }
}
