/**
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */

#include "aws/s3/private/s3_auto_ranged_get.h"
#include "aws/s3/private/s3_client_impl.h"
#include "aws/s3/private/s3_meta_request_impl.h"
#include "aws/s3/private/s3_request_messages.h"
#include "aws/s3/private/s3_util.h"
#include <aws/common/string.h>
#include <aws/common/system_info.h>
#include <inttypes.h>

/* Dont use buffer pool when we know response size, and its below this number,
 * i.e. when user provides explicit range that is small, ex. range = 1-100.
 * Instead of going through the pool in that case, we just use a dynamic buffer
 * for response (pre-mempool behavior). */
const uint64_t s_min_size_response_for_pooling = 1 * 1024 * 1024;
const uint32_t s_conservative_max_requests_in_flight = 8;
const struct aws_byte_cursor g_application_xml_value = AWS_BYTE_CUR_INIT_FROM_STRING_LITERAL("application/xml");

static void s_s3_meta_request_auto_ranged_get_destroy(struct aws_s3_meta_request *meta_request);

static void s_init_spread_synced(struct aws_s3_meta_request *meta_request);
static uint32_t s_next_part_number_synced(struct aws_s3_meta_request *meta_request);

static bool s_s3_auto_ranged_get_update(
    struct aws_s3_meta_request *meta_request,
    uint32_t flags,
    struct aws_s3_request **out_request);

static struct aws_future_void *s_s3_auto_ranged_get_prepare_request(struct aws_s3_request *request);

static void s_s3_auto_ranged_get_request_finished(
    struct aws_s3_meta_request *meta_request,
    struct aws_s3_request *request,
    int error_code);

static struct aws_s3_meta_request_resume_token *s_build_download_resume_token_synced(
    struct aws_s3_meta_request *meta_request);

static struct aws_s3_meta_request_vtable s_s3_auto_ranged_get_vtable = {
    .update = s_s3_auto_ranged_get_update,
    .send_request_finish = aws_s3_meta_request_send_request_finish_default,
    .prepare_request = s_s3_auto_ranged_get_prepare_request,
    .init_signing_date_time = aws_s3_meta_request_init_signing_date_time_default,
    .sign_request = aws_s3_meta_request_sign_request_default,
    .finished_request = s_s3_auto_ranged_get_request_finished,
    .destroy = s_s3_meta_request_auto_ranged_get_destroy,
    .finish = aws_s3_meta_request_finish_default,
    .build_resume_token_synced = s_build_download_resume_token_synced,
};

static int s_s3_auto_ranged_get_success_status(struct aws_s3_meta_request *meta_request) {
    AWS_PRECONDITION(meta_request);

    struct aws_s3_auto_ranged_get *auto_ranged_get = meta_request->impl;
    AWS_PRECONDITION(auto_ranged_get);

    if (auto_ranged_get->initial_message_has_range_header) {
        return AWS_HTTP_STATUS_CODE_206_PARTIAL_CONTENT;
    }

    return AWS_HTTP_STATUS_CODE_200_OK;
}

/* Allocate a new auto-ranged-get meta request. */
struct aws_s3_meta_request *aws_s3_meta_request_auto_ranged_get_new(
    struct aws_allocator *allocator,
    struct aws_s3_client *client,
    size_t part_size,
    bool part_size_set,
    const struct aws_s3_meta_request_options *options) {
    AWS_PRECONDITION(allocator);
    AWS_PRECONDITION(client);
    AWS_PRECONDITION(options);
    AWS_PRECONDITION(options->message);

    struct aws_s3_auto_ranged_get *auto_ranged_get =
        aws_mem_calloc(allocator, 1, sizeof(struct aws_s3_auto_ranged_get));

    /* Try to initialize the base type. */
    if (aws_s3_meta_request_init_base(
            allocator,
            client,
            part_size,
            false,
            false,
            options,
            auto_ranged_get,
            &s_s3_auto_ranged_get_vtable,
            &auto_ranged_get->base)) {

        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p Could not initialize base type for Auto-Ranged-Get Meta Request.",
            (void *)auto_ranged_get);
        aws_mem_release(allocator, auto_ranged_get);
        return NULL;
    }

    auto_ranged_get->part_size_set = part_size_set;
    auto_ranged_get->force_dynamic_part_size = options->force_dynamic_part_size;
    struct aws_http_headers *headers = aws_http_message_get_headers(auto_ranged_get->base.initial_request_message);
    AWS_ASSERT(headers != NULL);

    if (aws_http_headers_has(headers, g_range_header_name)) {
        auto_ranged_get->initial_message_has_range_header = true;
        if (aws_s3_parse_request_range_header(
                headers,
                &auto_ranged_get->initial_message_has_start_range,
                &auto_ranged_get->initial_message_has_end_range,
                &auto_ranged_get->initial_range_start,
                &auto_ranged_get->initial_range_end)) {
            AWS_LOGF_ERROR(
                AWS_LS_S3_META_REQUEST,
                "id=%p Could not parse Range header for Auto-Ranged-Get Meta Request.",
                (void *)auto_ranged_get);
            goto on_error;
        }
    }
    auto_ranged_get->initial_message_has_if_match_header = aws_http_headers_has(headers, g_if_match_header_name);

    auto_ranged_get->synced_data.first_part_size = auto_ranged_get->base.part_size;
    if (options->object_size_hint != NULL) {
        auto_ranged_get->object_size_hint_available = true;
        auto_ranged_get->object_size_hint = *options->object_size_hint;
    }

    AWS_LOGF_DEBUG(
        AWS_LS_S3_META_REQUEST, "id=%p Created new Auto-Ranged Get Meta Request.", (void *)&auto_ranged_get->base);

    return &auto_ranged_get->base;

on_error:
    /* This will also clean up the auto_ranged_get */
    aws_s3_meta_request_release(&(auto_ranged_get->base));
    return NULL;
}

static void s_s3_meta_request_auto_ranged_get_destroy(struct aws_s3_meta_request *meta_request) {
    AWS_PRECONDITION(meta_request);
    AWS_PRECONDITION(meta_request->impl);

    struct aws_s3_auto_ranged_get *auto_ranged_get = meta_request->impl;
    aws_string_destroy(auto_ranged_get->etag);
    aws_string_destroy(auto_ranged_get->s3_object_last_modified);
    aws_mem_release(meta_request->allocator, auto_ranged_get);
}

/*
 * Whether the download should be validated against a single checksum covering all of it, on top of validating each
 * part response against the checksum that response reports. A caller who only wants each response checked against
 * its own checksum (AWS_SCVM_REQUEST_ONLY) also saves the HeadObject request the client makes to learn a
 * whole-object one.
 */
static bool s_should_validate_whole_download(const struct aws_s3_meta_request *meta_request) {
    if (!meta_request->checksum_config.validate_response_checksum) {
        return false;
    }
    switch (meta_request->checksum_config.response_checksum_validation_mode) {
        case AWS_SCVM_DEFAULT:
        case AWS_SCVM_FULL_OBJECT:
            return true;
        default:
            return false;
    }
}

/*
 * This function returns the type of first request which we will also use to discover overall object size.
 */
static enum aws_s3_auto_ranged_get_request_type s_s3_get_request_type_for_discovering_object_size(
    const struct aws_s3_meta_request *meta_request) {
    AWS_PRECONDITION(meta_request);
    struct aws_s3_auto_ranged_get *auto_ranged_get = meta_request->impl;
    AWS_ASSERT(auto_ranged_get);

    /*
     * When we attempt to download an empty file using the `AWS_S3_AUTO_RANGE_GET_REQUEST_TYPE_GET_OBJECT_WITH_RANGE`
     * request type, the request fails with an empty file error. We then reset `object_range_known`
     * (`object_range_empty` is set to true) and try to download the file again with
     * `AWS_S3_AUTO_RANGE_GET_REQUEST_TYPE_GET_OBJECT_WITH_PART_NUMBER_1`. We send another request, even though there is
     * no body, to provide successful response headers to the user. If the file is still empty, successful response
     * headers will be provided to the users. Otherwise, the newer version of the file will be downloaded.
     */
    if (auto_ranged_get->synced_data.object_range_empty != 0) {
        auto_ranged_get->synced_data.object_range_empty = 0;
        return AWS_S3_AUTO_RANGE_GET_REQUEST_TYPE_GET_OBJECT_WITH_PART_NUMBER_1;
    }

    /*
     * If a range header exists but has no start-range (i.e. Range: bytes=-100), we perform a HeadRequest. If the
     * start-range is unknown, we could potentially execute a request from the end-range and keep that request around
     * until the meta request finishes. However, this approach involves the complexity of managing backpressure. For
     * simplicity, we execute a HeadRequest if the start-range is not specified.
     */
    if (auto_ranged_get->initial_message_has_range_header != 0) {
        return auto_ranged_get->initial_message_has_start_range
                   ? AWS_S3_AUTO_RANGE_GET_REQUEST_TYPE_GET_OBJECT_WITH_RANGE
                   : AWS_S3_AUTO_RANGE_GET_REQUEST_TYPE_HEAD_OBJECT;
    }

    /* If the object_size_hint indicates that it fits in a single part, try to get the file directly.
     * This avoids a HEAD request and sizes the buffer reservation to the hint rather than full part_size.
     * If the hint is wrong and the object is larger, the request will be cancelled and retried with ranged gets. */
    if (auto_ranged_get->object_size_hint_available && auto_ranged_get->object_size_hint > 0 &&
        auto_ranged_get->object_size_hint <= meta_request->part_size) {
        return AWS_S3_AUTO_RANGE_GET_REQUEST_TYPE_GET_OBJECT_WITH_PART_NUMBER_1;
    }

    /* If we don't need a whole-download checksum, then discover the size of the object while trying to get the first
     * part. Same when we already have the checksum to validate against, which at this point means the caller supplied
     * it: the HeadObject below exists only to learn a checksum from the service. */
    if (!s_should_validate_whole_download(meta_request) ||
        meta_request->meta_request_level_running_response_sum != NULL) {
        return AWS_S3_AUTO_RANGE_GET_REQUEST_TYPE_GET_OBJECT_WITH_RANGE;
    }

    /* Otherwise, do a headObject so that we can validate checksum if the file was uploaded as a single part */
    return AWS_S3_AUTO_RANGE_GET_REQUEST_TYPE_HEAD_OBJECT;
}

static bool s_s3_auto_ranged_get_update(
    struct aws_s3_meta_request *meta_request,
    uint32_t flags,
    struct aws_s3_request **out_request) {
    AWS_PRECONDITION(meta_request);
    AWS_PRECONDITION(out_request);

    struct aws_s3_auto_ranged_get *auto_ranged_get = meta_request->impl;
    struct aws_s3_request *request = NULL;
    bool work_remaining = false;

    /* BEGIN CRITICAL SECTION */
    {
        aws_s3_meta_request_lock_synced_data(meta_request);

#ifdef AWS_C_S3_ENABLE_TEST_STUBS
        if (meta_request->vtable->synced_update_stub && meta_request->vtable->synced_update_stub(meta_request)) {
            /* TEST ONLY, allow test to stub here. */
            aws_s3_meta_request_unlock_synced_data(meta_request);
            return true;
        }
#endif
        /* If nothing has set the "finish result" then this meta request is still in progress, and we can potentially
         * send additional requests. */
        if (!aws_s3_meta_request_has_finish_result_synced(meta_request)) {

            if ((flags & AWS_S3_META_REQUEST_UPDATE_FLAG_CONSERVATIVE) != 0) {
                uint32_t num_requests_in_flight =
                    (auto_ranged_get->synced_data.num_parts_requested -
                     auto_ranged_get->synced_data.num_parts_completed) +
                    (uint32_t)aws_priority_queue_size(&meta_request->synced_data.pending_body_streaming_requests);

                /* auto-ranged-gets make use of body streaming, which will hold onto response bodies if parts earlier in
                 * the file haven't arrived yet. This can potentially create a lot of backed up requests, causing us to
                 * hit our global request limit. To help mitigate this, when the "conservative" flag is passed in, we
                 * only allow the total amount of requests being sent/streamed to be inside a set limit.  */
                if (num_requests_in_flight > s_conservative_max_requests_in_flight) {
                    goto has_work_remaining;
                }
            }

            /* If the overall range of the object that we are trying to retrieve isn't known yet, then we need to send a
             * request to figure that out. */
            if (!auto_ranged_get->synced_data.object_range_known) {
                if (auto_ranged_get->synced_data.head_object_sent ||
                    auto_ranged_get->synced_data.num_parts_requested > 0) {
                    goto has_work_remaining;
                }
                switch (s_s3_get_request_type_for_discovering_object_size(meta_request)) {
                    case AWS_S3_AUTO_RANGE_GET_REQUEST_TYPE_HEAD_OBJECT:
                        AWS_LOGF_INFO(
                            AWS_LS_S3_META_REQUEST,
                            "id=%p: Doing a HeadObject to discover the size of the object",
                            (void *)meta_request);
                        request = aws_s3_request_new(
                            meta_request,
                            AWS_S3_AUTO_RANGE_GET_REQUEST_TYPE_HEAD_OBJECT,
                            AWS_S3_REQUEST_TYPE_HEAD_OBJECT,
                            0 /*part_number*/,
                            AWS_S3_REQUEST_FLAG_RECORD_RESPONSE_HEADERS);
                        auto_ranged_get->synced_data.head_object_sent = true;
                        break;
                    case AWS_S3_AUTO_RANGE_GET_REQUEST_TYPE_GET_OBJECT_WITH_PART_NUMBER_1:
                        AWS_LOGF_INFO(
                            AWS_LS_S3_META_REQUEST,
                            "id=%p: Doing a 'GET_OBJECT_WITH_PART_NUMBER_1' to discover the size of the object and get "
                            "the first part",
                            (void *)meta_request);

                        request = aws_s3_request_new(
                            meta_request,
                            AWS_S3_AUTO_RANGE_GET_REQUEST_TYPE_GET_OBJECT_WITH_PART_NUMBER_1,
                            AWS_S3_REQUEST_TYPE_GET_OBJECT,
                            1 /*part_number*/,
                            AWS_S3_REQUEST_FLAG_RECORD_RESPONSE_HEADERS |
                                AWS_S3_REQUEST_FLAG_ALLOCATE_BUFFER_FROM_POOL);
                        /* Reserve only as much buffer as the hint suggests, capped at part_size.
                         * If the hint is absent or zero, fall back to the full part_size reservation.
                         * If the hint turns out to be too small, the cancellation in
                         * s_s3_meta_request_headers_block_done fires before the body arrives, and the
                         * mismatch handling below keeps the discovered size and fetches the data as
                         * ranged gets instead of re-issuing a partNumber request. */
                        request->part_range_start = 0;
                        request->part_range_end =
                            (auto_ranged_get->object_size_hint_available && auto_ranged_get->object_size_hint > 0)
                                ? aws_min_u64(auto_ranged_get->object_size_hint, meta_request->part_size) - 1
                                : meta_request->part_size - 1;
                        ++auto_ranged_get->synced_data.num_parts_requested;

                        break;
                    case AWS_S3_AUTO_RANGE_GET_REQUEST_TYPE_GET_OBJECT_WITH_RANGE:
                        AWS_LOGF_INFO(
                            AWS_LS_S3_META_REQUEST,
                            "id=%p: Doing a 'GET_OBJECT_WITH_RANGE' to discover the size of the object and get the "
                            "first part",
                            (void *)meta_request);

                        uint64_t part_range_start = 0;
                        uint64_t first_part_size = meta_request->part_size;
                        if (auto_ranged_get->initial_message_has_range_header) {
                            /*
                             * Currently, we only discover the size of the object when the initial range header includes
                             * a start-range. If we ever implement skipping the HeadRequest for a Range request without
                             * a start-range, this will need to update.
                             */
                            AWS_ASSERT(auto_ranged_get->initial_message_has_start_range);
                            part_range_start = auto_ranged_get->initial_range_start;

                            if (auto_ranged_get->initial_message_has_end_range) {
                                first_part_size = aws_min_u64(
                                    first_part_size,
                                    auto_ranged_get->initial_range_end - auto_ranged_get->initial_range_start + 1);
                            }

                            auto_ranged_get->synced_data.first_part_size = first_part_size;
                        }
                        AWS_LOGF_INFO(
                            AWS_LS_S3_META_REQUEST,
                            "id=%p: Doing a ranged get to discover the size of the object and get the first part",
                            (void *)meta_request);

                        request = aws_s3_request_new(
                            meta_request,
                            AWS_S3_AUTO_RANGE_GET_REQUEST_TYPE_GET_OBJECT_WITH_RANGE,
                            AWS_S3_REQUEST_TYPE_GET_OBJECT,
                            1 /*part_number*/,
                            AWS_S3_REQUEST_FLAG_RECORD_RESPONSE_HEADERS |
                                AWS_S3_REQUEST_FLAG_ALLOCATE_BUFFER_FROM_POOL);
                        request->part_range_start = part_range_start;
                        request->part_range_end = part_range_start + first_part_size - 1; /* range-end is inclusive */
                        ++auto_ranged_get->synced_data.num_parts_requested;
                        break;
                    default:
                        AWS_FATAL_ASSERT(
                            0 && "s_s3_get_request_type_for_discovering_object_size returned unexpected discover "
                                 "object size request type");
                }
                request->discovers_object_size = true;
                goto has_work_remaining;
            }

            /* If there are still more parts to be requested */
            if (auto_ranged_get->synced_data.num_parts_requested < auto_ranged_get->synced_data.total_num_parts) {

                if (meta_request->client->enable_read_backpressure) {
                    /* Don't start a part until we have enough window to send bytes to the user.
                     *
                     * Note that we start a part once we have enough window to deliver ANY of its bytes.
                     * If we waited until the window was large enough for the WHOLE part,
                     * we could end up stuck in a situation where the user is
                     * waiting for more bytes before they'll open the window,
                     * and this implementation is waiting for more window before it will send more parts. */
                    uint64_t read_data_requested = 0;
                    if (auto_ranged_get->synced_data.num_parts_requested > 0) {
                        read_data_requested =
                            (auto_ranged_get->synced_data.num_parts_requested - 1) * meta_request->part_size +
                            auto_ranged_get->synced_data.first_part_size;
                    }
                    if (read_data_requested >= meta_request->synced_data.read_window_running_total) {

                        /* Avoid spamming users with this DEBUG message */
                        if (auto_ranged_get->synced_data.read_window_warning_issued == 0) {
                            auto_ranged_get->synced_data.read_window_warning_issued = 1;

                            AWS_LOGF_DEBUG(
                                AWS_LS_S3_META_REQUEST,
                                "id=%p: Download paused because read window is zero. "
                                "You must increment to window to continue.",
                                (void *)meta_request);
                        }

                        goto has_work_remaining;
                    }

                    auto_ranged_get->synced_data.read_window_warning_issued = 0;
                }

                request = aws_s3_request_new(
                    meta_request,
                    AWS_S3_AUTO_RANGE_GET_REQUEST_TYPE_GET_OBJECT_WITH_RANGE,
                    AWS_S3_REQUEST_TYPE_GET_OBJECT,
                    s_next_part_number_synced(meta_request) /*part_number*/,
                    AWS_S3_REQUEST_FLAG_ALLOCATE_BUFFER_FROM_POOL);

                aws_s3_calculate_auto_ranged_get_part_range(
                    auto_ranged_get->synced_data.object_range_start,
                    auto_ranged_get->synced_data.object_range_end,
                    meta_request->part_size,
                    auto_ranged_get->synced_data.first_part_size,
                    request->part_number,
                    &request->part_range_start,
                    &request->part_range_end);

                ++auto_ranged_get->synced_data.num_parts_requested;
                goto has_work_remaining;
            }

            /* If there are parts that have not attempted delivery to the caller or that have not yet completed
             * delivery, then there is still work being done. */
            if (meta_request->synced_data.num_parts_delivery_completed < auto_ranged_get->synced_data.total_num_parts ||
                meta_request->synced_data.num_parts_delivery_completed <
                    meta_request->synced_data.num_parts_delivery_sent) {
                goto has_work_remaining;
            }
        } else {
            /* Else, if there is a finish result set, make sure that all work-in-progress winds down before the meta
             * request completely exits. */

            if (auto_ranged_get->synced_data.head_object_sent && !auto_ranged_get->synced_data.head_object_completed) {
                goto has_work_remaining;
            }

            /* Wait for all requests to complete (successfully or unsuccessfully) before finishing.*/
            if (auto_ranged_get->synced_data.num_parts_completed < auto_ranged_get->synced_data.num_parts_requested) {
                goto has_work_remaining;
            }

            /* If some parts are still being delivered to the caller, then wait for those to finish. */
            if (meta_request->synced_data.num_parts_delivery_completed <
                meta_request->synced_data.num_parts_delivery_sent) {
                goto has_work_remaining;
            }
        }

        goto no_work_remaining;

    has_work_remaining:
        work_remaining = true;

        if (request != NULL) {
            AWS_LOGF_DEBUG(
                AWS_LS_S3_META_REQUEST,
                "id=%p: Returning request %p for part %d of %d",
                (void *)meta_request,
                (void *)request,
                request->part_number,
                auto_ranged_get->synced_data.total_num_parts);
        }

    no_work_remaining:
        /* If some events are still being delivered to caller, then wait for those to finish */
        if (!work_remaining && aws_s3_meta_request_are_events_out_for_delivery_synced(meta_request)) {
            work_remaining = true;
        }

        if (!work_remaining) {
            if (!aws_s3_meta_request_has_finish_result_synced(meta_request)) {
                /* About to report success, so every part must have been delivered. A gap here means a part
                 * was dropped somewhere in the delivery path, which would hand the caller a short or holed
                 * file while reporting success -- fail instead. set_fail_synced wins over the
                 * set_success_synced below, which becomes a no-op once a finish result is set. */
                if (aws_s3_meta_request_validate_parts_delivered_synced(meta_request) != AWS_OP_SUCCESS) {
                    aws_s3_meta_request_set_fail_synced(meta_request, NULL, aws_last_error());
                }
                aws_mem_release(meta_request->allocator, meta_request->synced_data.parts_delivered_mask);
                meta_request->synced_data.parts_delivered_mask = NULL;
                meta_request->synced_data.parts_delivered_mask_length = 0;
            }
            aws_s3_meta_request_set_success_synced(meta_request, s_s3_auto_ranged_get_success_status(meta_request));
            if (auto_ranged_get->synced_data.num_parts_checksum_validated ==
                auto_ranged_get->synced_data.num_parts_requested) {
                /* If we have validated the checksum for every part, we set the meta request level checksum validation
                 * result.*/
                meta_request->synced_data.finish_result.did_validate = true;
                meta_request->synced_data.finish_result.validation_algorithm = auto_ranged_get->validation_algorithm;
            }
        }

        aws_s3_meta_request_unlock_synced_data(meta_request);
    }
    /* END CRITICAL SECTION */

    if (work_remaining) {
        *out_request = request;
    } else {
        AWS_ASSERT(request == NULL);
        aws_s3_meta_request_finish(meta_request);
    }

    return work_remaining;
}

/* Given a request, prepare it for sending based on its description.
 * Currently, this is actually synchronous. */
static struct aws_future_void *s_s3_auto_ranged_get_prepare_request(struct aws_s3_request *request) {
    AWS_PRECONDITION(request);
    struct aws_s3_meta_request *meta_request = request->meta_request;

    /* Generate a new ranged get request based on the original message. */
    struct aws_http_message *message = NULL;
    struct aws_s3_auto_ranged_get *auto_ranged_get = meta_request->impl;

    bool success = false;

    switch (request->request_tag) {
        case AWS_S3_AUTO_RANGE_GET_REQUEST_TYPE_HEAD_OBJECT:
            /* A head object will be a copy of the original headers but with a HEAD request method. */
            message = aws_s3_message_util_copy_http_message_no_body_all_headers(
                meta_request->allocator, meta_request->initial_request_message);
            if (message) {
                aws_http_message_set_request_method(message, g_head_method);
            }
            break;
        case AWS_S3_AUTO_RANGE_GET_REQUEST_TYPE_GET_OBJECT_WITH_RANGE:
            message = aws_s3_ranged_get_object_message_new(
                meta_request->allocator,
                meta_request->initial_request_message,
                request->part_range_start,
                request->part_range_end);
            break;
        case AWS_S3_AUTO_RANGE_GET_REQUEST_TYPE_GET_OBJECT_WITH_PART_NUMBER_1:
            message = aws_s3_message_util_copy_http_message_no_body_all_headers(
                meta_request->allocator, meta_request->initial_request_message);
            if (message) {
                aws_s3_message_util_set_multipart_request_path(
                    meta_request->allocator, NULL, request->part_number, false, message);
            }
            break;
    }

    if (message == NULL) {
        AWS_LOGF_ERROR(
            AWS_LS_S3_META_REQUEST,
            "id=%p Could not create message for request with tag %d for auto-ranged-get meta request.",
            (void *)meta_request,
            request->request_tag);
        goto finish;
    }
    if (meta_request->checksum_config.validate_response_checksum) {
        aws_http_headers_set(aws_http_message_get_headers(message), g_request_validation_mode, g_enabled);
    }
    if (!auto_ranged_get->initial_message_has_if_match_header && auto_ranged_get->etag) {
        /* Add the if_match to the request */
        AWS_LOGF_DEBUG(
            AWS_LS_S3_META_REQUEST,
            "id=%p: Added the If-Match header to request %p for part %d",
            (void *)meta_request,
            (void *)request,
            request->part_number);
        aws_http_headers_set(
            aws_http_message_get_headers(message),
            g_if_match_header_name,
            aws_byte_cursor_from_string(auto_ranged_get->etag));
    }

    aws_s3_request_setup_send_data(request, message);
    aws_http_message_release(message);

    /* Success! */
    AWS_LOGF_DEBUG(
        AWS_LS_S3_META_REQUEST,
        "id=%p: Created request %p for part %d allocated from pool %d",
        (void *)meta_request,
        (void *)request,
        request->part_number,
        request->should_allocate_buffer_from_pool);

    success = true;

finish:;
    struct aws_future_void *future = aws_future_void_new(meta_request->allocator);
    if (success) {
        aws_future_void_set_result(future);
    } else {
        aws_future_void_set_error(future, aws_last_error_or_unknown());
    }
    return future;
}

/* Check the finish result of meta request.
 * Return true if the request failed because it downloaded an empty file.
 * Return false if the request failed for any other reason */
static bool s_check_empty_file_download_error(struct aws_s3_request *failed_request) {
    struct aws_http_headers *failed_headers = failed_request->send_data.response_headers;
    struct aws_byte_buf failed_body = failed_request->send_data.response_body;
    if (failed_headers && failed_body.capacity > 0) {
        struct aws_byte_cursor content_type;
        AWS_ZERO_STRUCT(content_type);
        if (!aws_http_headers_get(failed_headers, g_content_type_header_name, &content_type)) {
            /* Content type found */
            if (aws_byte_cursor_eq_ignore_case(&content_type, &g_application_xml_value)) {
                /* XML response */
                struct aws_byte_cursor xml_doc = aws_byte_cursor_from_buf(&failed_body);
                const char *path_to_size[] = {"Error", "ActualObjectSize", NULL};
                struct aws_byte_cursor size = {0};
                aws_xml_get_body_at_path(failed_request->allocator, xml_doc, path_to_size, &size);
                if (aws_byte_cursor_eq_c_str(&size, "0")) {
                    return true;
                }
            }
        }
    }
    return false;
}

static int s_discover_object_range_and_size(
    struct aws_s3_meta_request *meta_request,
    struct aws_s3_request *request,
    int error_code,
    uint64_t *out_object_range_start,
    uint64_t *out_object_range_end,
    uint64_t *out_object_size,
    uint64_t *out_first_part_size,
    bool *out_empty_file_error) {

    AWS_PRECONDITION(out_object_size);
    AWS_PRECONDITION(out_object_range_start);
    AWS_PRECONDITION(out_object_range_end);
    AWS_PRECONDITION(out_first_part_size);

    int result = AWS_OP_ERR;

    uint64_t content_length = 0;
    uint64_t object_size = 0;
    uint64_t object_range_start = 0;
    uint64_t object_range_end = 0;
    uint64_t first_part_size = 0;

    AWS_ASSERT(request->discovers_object_size);
    struct aws_s3_auto_ranged_get *auto_ranged_get = meta_request->impl;
    switch (request->request_tag) {
        case AWS_S3_AUTO_RANGE_GET_REQUEST_TYPE_HEAD_OBJECT:
            if (error_code != AWS_ERROR_SUCCESS) {
                /* If the head request failed, there's nothing we can do, so resurface the error code. */
                aws_raise_error(error_code);
                break;
            }

            /* There should be a Content-Length header that indicates the total size of the range.*/
            if (aws_s3_parse_content_length_response_header(
                    meta_request->allocator, request->send_data.response_headers, &content_length)) {

                AWS_LOGF_ERROR(
                    AWS_LS_S3_META_REQUEST,
                    "id=%p Could not find content-length header for request %p",
                    (void *)meta_request,
                    (void *)request);
                break;
            }

            /* if the initial message had a ranged header, there should also be a Content-Range header that specifies
             * the object range and total object size. Otherwise, the size and range should be equal to the
             * total_content_length. */
            if (!auto_ranged_get->initial_message_has_range_header) {
                object_size = content_length;
                if (content_length > 0) {
                    object_range_end = content_length - 1; /* range-end is inclusive */
                }
            } else if (aws_s3_parse_content_range_response_header(
                           request->send_data.response_headers, &object_range_start, &object_range_end, &object_size)) {

                AWS_LOGF_ERROR(
                    AWS_LS_S3_META_REQUEST,
                    "id=%p Could not find content-range header for request %p",
                    (void *)meta_request,
                    (void *)request);
                break;
            }

            result = AWS_OP_SUCCESS;
            break;
        case AWS_S3_AUTO_RANGE_GET_REQUEST_TYPE_GET_OBJECT_WITH_PART_NUMBER_1:
            AWS_ASSERT(request->part_number == 1);

            /* A first part too large for the hint-sized buffer is the only failure whose headers still describe the
             * object, so resurface any other error code. */
            if (error_code != AWS_ERROR_SUCCESS &&
                error_code != AWS_ERROR_S3_INTERNAL_BUFFER_SIZE_MISMATCH_RETRYING_WITH_RANGE) {
                aws_raise_error(error_code);
                break;
            }

            AWS_ASSERT(request->send_data.response_headers != NULL);
            /* There should be a Content-Length header that indicates the size of first part. */
            if (aws_s3_parse_content_length_response_header(
                    meta_request->allocator, request->send_data.response_headers, &content_length)) {

                AWS_LOGF_ERROR(
                    AWS_LS_S3_META_REQUEST,
                    "id=%p Could not find content-length header for request %p",
                    (void *)meta_request,
                    (void *)request);
                break;
            }
            first_part_size = content_length;

            if (first_part_size > 0) {
                /* Parse the object size from the part response. */
                if (aws_s3_parse_content_range_response_header(
                        request->send_data.response_headers, NULL, NULL, &object_size)) {

                    AWS_LOGF_ERROR(
                        AWS_LS_S3_META_REQUEST,
                        "id=%p Could not find content-range header for request %p",
                        (void *)meta_request,
                        (void *)request);
                    break;
                }
                /* When discovering the object size via GET_OBJECT_WITH_PART_NUMBER_1, the object range is the entire
                 * object. */
                object_range_start = 0;
                object_range_end = object_size - 1; /* range-end is inclusive */
            }

            result = AWS_OP_SUCCESS;
            break;
        case AWS_S3_AUTO_RANGE_GET_REQUEST_TYPE_GET_OBJECT_WITH_RANGE:
            AWS_ASSERT(request->part_number == 1);

            if (error_code != AWS_ERROR_SUCCESS) {
                /* If we hit an empty file while trying to discover the object-size via part, then this request
                failure
                 * is as designed. */
                if (!auto_ranged_get->initial_message_has_range_header && s_check_empty_file_download_error(request)) {
                    AWS_LOGF_DEBUG(
                        AWS_LS_S3_META_REQUEST,
                        "id=%p Detected empty file with request %p. Sending new request without range header.",
                        (void *)meta_request,
                        (void *)request);

                    object_size = 0ULL;
                    *out_empty_file_error = true;
                    result = AWS_OP_SUCCESS;
                } else {
                    /* Otherwise, resurface the error code. */
                    aws_raise_error(error_code);
                }
                break;
            }

            AWS_ASSERT(request->send_data.response_headers != NULL);

            /* Parse the object size from the part response. */
            if (aws_s3_parse_content_range_response_header(
                    request->send_data.response_headers, &object_range_start, &object_range_end, &object_size)) {

                AWS_LOGF_ERROR(
                    AWS_LS_S3_META_REQUEST,
                    "id=%p Could not find content-range header for request %p",
                    (void *)meta_request,
                    (void *)request);

                break;
            }
            if (auto_ranged_get->initial_message_has_range_header) {
                if (auto_ranged_get->initial_message_has_end_range) {
                    object_range_end = aws_min_u64(object_size - 1, auto_ranged_get->initial_range_end);
                } else {
                    object_range_end = object_size - 1;
                }
            } else {
                /* When discovering the object size via GET_OBJECT_WITH_RANGE, the object range is the entire object. */
                object_range_start = 0;
                object_range_end = object_size - 1; /* range-end is inclusive */
            }
            result = AWS_OP_SUCCESS;
            break;
        default:
            AWS_ASSERT(false);
            break;
    }

    if (result == AWS_OP_SUCCESS) {
        *out_object_size = object_size;
        *out_object_range_start = object_range_start;
        *out_object_range_end = object_range_end;
        *out_first_part_size = first_part_size;
    }

    return result;
}

/* Does the checksum carried by this discovery response cover exactly the bytes this meta request will deliver?
 *
 * The meta-request-level checksum is compared against a running sum of every byte handed to the caller, so
 * adopting a value that describes any other span of bytes reports intact data as a mismatch. Two things have to
 * line up: the download has to be the whole object, and the response's checksum has to describe the whole object
 * rather than one part or one range of it. */
static bool s_discovery_checksum_covers_download(
    const struct aws_s3_request *request,
    uint64_t object_range_start,
    uint64_t object_range_end,
    uint64_t object_size,
    uint64_t first_part_size) {

    if (object_size == 0) {
        /* Nothing to deliver, so whatever the response carries is the empty object's own checksum. */
        return true;
    }

    if (object_range_start != 0 || object_range_end != object_size - 1) {
        /* A ranged download. No checksum of the whole object can be checked against a slice of it. */
        return false;
    }

    switch (request->request_tag) {
        case AWS_S3_AUTO_RANGE_GET_REQUEST_TYPE_HEAD_OBJECT:
            /* HeadObject reports the object's own checksum. */
            return true;
        case AWS_S3_AUTO_RANGE_GET_REQUEST_TYPE_GET_OBJECT_WITH_PART_NUMBER_1:
            /* A partNumber request reports part 1's checksum, which is the object's checksum only when part 1 is
             * the entire object, i.e. when the object was not uploaded as a multipart upload. */
            return first_part_size == object_size;
        case AWS_S3_AUTO_RANGE_GET_REQUEST_TYPE_GET_OBJECT_WITH_RANGE:
            /* A ranged GET reports the checksum of the bytes it returned, so it covers the object only when this
             * one request spanned the whole thing. */
            return request->part_range_start == 0 && request->part_range_end >= object_size - 1;
        default:
            return false;
    }
}

/* Are the bytes this one response returned the entire download, so that no other request carries data? A response
 * whose body is the whole download and which already validated itself needs no meta-request-level checksum: the
 * running sum would hash the same bytes a second time to reach a verdict the request level already has. */
static bool s_request_body_is_entire_download(
    const struct aws_s3_request *request,
    uint64_t object_range_start,
    uint64_t object_range_end,
    uint64_t first_part_size) {

    switch (request->request_tag) {
        case AWS_S3_AUTO_RANGE_GET_REQUEST_TYPE_GET_OBJECT_WITH_PART_NUMBER_1:
            /* Part 1 starts at the beginning of the object, so its body is [0, first_part_size - 1]. An empty
             * response reports first_part_size == 0 and so never covers anything. */
            return object_range_start == 0 && first_part_size > object_range_end;
        case AWS_S3_AUTO_RANGE_GET_REQUEST_TYPE_GET_OBJECT_WITH_RANGE:
            return request->part_range_start <= object_range_start && request->part_range_end >= object_range_end;
        default:
            /* HeadObject returns no body. */
            return false;
    }
}

/* Set up the block-cyclic spread for this download. After this, s_next_part_number_synced produces part
 * numbers that rotate across K far-apart regions of the object instead of sweeping it. Called from
 * discovery finish, after the delivery order has been resolved. */
static void s_init_spread_synced(struct aws_s3_meta_request *meta_request) {
    struct aws_s3_auto_ranged_get *auto_ranged_get = meta_request->impl;
    ASSERT_SYNCED_DATA_LOCK_HELD(meta_request);

    /* Reset from any previous attempt (a retry can throw away a discovered range). */
    auto_ranged_get->synced_data.spread_num_regions = 0;

    if (meta_request->client == NULL || meta_request->client->force_sequential_requests) {
        return;
    }

    /* Spreading is what hands parts out of object order; an ordered download must sweep contiguously. */
    if (aws_atomic_load_int(&meta_request->out_of_order_delivery) == 0) {
        return;
    }

    const uint32_t first_part = auto_ranged_get->synced_data.num_parts_requested + 1;
    const uint32_t total_num_parts = auto_ranged_get->synced_data.total_num_parts;
    /* If the first part completed the full download, stops here. */
    if (first_part > total_num_parts) {
        return;
    }

    const uint32_t parts_remaining = total_num_parts - first_part + 1;
    const uint32_t num_regions = aws_s3_client_get_max_active_connections(meta_request->client, meta_request);
    if (num_regions <= 1) {
        return;
    }

    /* With a region per remaining part the rotation visits region 0, 1, 2 ... which is parts first,
     * first + 1, first + 2 -- object order, exactly what handing them out with no spread already does.
     * Declining here also keeps the region size below from dividing to zero when the connection count
     * runs ahead of the part count. */
    if (parts_remaining <= num_regions) {
        return;
    }

    /* The leftover of an uneven division goes to the first few regions, one part each. See the spread
     * fields in s3_auto_ranged_get.h for what each of these means, and a worked example. */
    auto_ranged_get->synced_data.spread_num_regions = num_regions;
    auto_ranged_get->synced_data.spread_region_size = parts_remaining / num_regions;
    auto_ranged_get->synced_data.spread_num_large_regions = parts_remaining % num_regions;
    auto_ranged_get->synced_data.spread_first_part = first_part;
    auto_ranged_get->synced_data.spread_parts_handed_out = 0;

    AWS_LOGF_INFO(
        AWS_LS_S3_META_REQUEST,
        "id=%p: Spreading parts %" PRIu32 "-%" PRIu32 " across %" PRIu32 " regions of the object.",
        (void *)meta_request,
        first_part,
        total_num_parts,
        num_regions);
}

/* The 1-based part number to hand out next. When spreading is off, parts go out in object order. When on,
 * parts rotate across the spread's regions. See the spread fields in s3_auto_ranged_get.h for what each
 * one means. */
static uint32_t s_next_part_number_synced(struct aws_s3_meta_request *meta_request) {
    struct aws_s3_auto_ranged_get *auto_ranged_get = meta_request->impl;
    ASSERT_SYNCED_DATA_LOCK_HELD(meta_request);

    /* 0 means spreading is off. 1 would mean a single region, which is a contiguous sweep of the object
     * and so is object order as well -- the arithmetic below would return the same numbers for it, but
     * sweeping says it more directly. */
    const uint32_t num_regions = auto_ranged_get->synced_data.spread_num_regions;
    if (num_regions < 2) {
        return auto_ranged_get->synced_data.num_parts_requested + 1;
    }

    /* Split the handout index in two: `region` is which region this part comes from and `step` is how far
     * into that region it sits. Taking the region from the remainder is what makes the handout visit every
     * region before it comes back to any of them. Using the header's example -- 10 parts from part 2
     * across 3 regions, cut as [2 3 4 5] [6 7 8] [9 10 11] -- an index of 4 is region 1, step 1, which is
     * the second part of [6 7 8]: part 7. */
    const uint32_t i = auto_ranged_get->synced_data.spread_parts_handed_out++;
    const uint32_t region = i % num_regions;
    const uint32_t step = i / num_regions;
    const uint32_t region_size = auto_ranged_get->synced_data.spread_region_size;
    const uint32_t num_large_regions = auto_ranged_get->synced_data.spread_num_large_regions;
    const uint32_t first = auto_ranged_get->synced_data.spread_first_part;

    /* Where this region begins: each of the first `num_large_regions` regions is one part wider. */
    uint32_t region_start;
    if (region < num_large_regions) {
        region_start = first + region * (region_size + 1);
    } else {
        region_start = first + num_large_regions * (region_size + 1) + (region - num_large_regions) * region_size;
    }

    return region_start + step;
}

/* True when the whole-object checksum can only be assembled by feeding bytes in object order, which the
 * parallel-write path cannot do. Combinable algorithms fold each part's own digest in at finish, so they
 * place no ordering demand. Both fields are settled by the end of discovery: the checksum is read from the
 * discovery response's headers, and whether it can be folded is decided from the part count. */
static bool s_response_needs_ordered_body(const struct aws_s3_meta_request *meta_request) {
    return meta_request->meta_request_level_running_response_sum != NULL &&
           !meta_request->meta_request_level_checksum_combinable;
}

/* Resolve, once, whether this download delivers bodies out of object order, and record it on the meta
 * request. Static here because discovery is the only place the question is ever asked: no other meta
 * request implementation splits a download into parts, so no other one has an order to deliver out of,
 * and every one of them leaves the flag at the false it was initialized to. */
static void s_resolve_out_of_order_delivery(struct aws_s3_meta_request *meta_request) {
    bool out_of_order = aws_s3_allow_out_of_order_delivery(
        /* A file sink needs the per-worker descriptors, which init only allocates given a client that
         * had not already ruled out-of-order delivery out. */
        meta_request->recv_filepath != NULL && meta_request->recv_file_write_fd_slots != NULL,
        meta_request->recv_filepath == NULL && meta_request->client != NULL,
        meta_request->out_of_order_delivery_override,
        meta_request->client != NULL ? meta_request->client->out_of_order_delivery : AWS_TRIBOOL_UNSET,
        meta_request->client != NULL ? meta_request->client->out_of_order_delivery_env : AWS_TRIBOOL_UNSET);

    /* A whole-object checksum that cannot be folded per part has to be hashed in object order, which the
     * parallel path cannot do. A correctness constraint, so it overrides the preference -- and worth
     * saying out loud, since it is the one case where the caller asked for out-of-order delivery and did
     * not get it. */
    if (out_of_order && s_response_needs_ordered_body(meta_request)) {
        AWS_LOGF_WARN(
            AWS_LS_S3_META_REQUEST,
            "id=%p: Delivering in object order despite out-of-order delivery being available: this "
            "response's whole-object checksum can only be verified by hashing the body in order.",
            (void *)meta_request);
        out_of_order = false;
    }

    aws_atomic_store_int(&meta_request->out_of_order_delivery, out_of_order ? 1 : 0);
}

static void s_s3_auto_ranged_get_request_finished(
    struct aws_s3_meta_request *meta_request,
    struct aws_s3_request *request,
    int error_code) {
    AWS_PRECONDITION(meta_request);
    AWS_PRECONDITION(meta_request->impl);
    AWS_PRECONDITION(request);

    struct aws_s3_auto_ranged_get *auto_ranged_get = meta_request->impl;
    AWS_PRECONDITION(auto_ranged_get);

    uint64_t object_range_start = 0ULL;
    uint64_t object_range_end = 0ULL;
    uint64_t object_size = 0ULL;
    uint64_t first_part_size = 0ULL;

    bool found_object_size = false;
    bool request_failed = error_code != AWS_ERROR_SUCCESS;
    bool first_part_buffer_size_mismatch =
        (error_code == AWS_ERROR_S3_INTERNAL_BUFFER_SIZE_MISMATCH_RETRYING_WITH_RANGE);
    bool empty_file_error = false;

    if (request->discovers_object_size) {
        /* Try to discover the object-range and object-size.*/
        if (s_discover_object_range_and_size(
                meta_request,
                request,
                error_code,
                &object_range_start,
                &object_range_end,
                &object_size,
                &first_part_size,
                &empty_file_error)) {

            error_code = aws_last_error_or_unknown();

            goto update_synced_data;
        }
        /* Always extract ETag header for part size estimation */
        if (!request_failed || first_part_buffer_size_mismatch) {
            struct aws_byte_cursor etag_header_value;
            if (aws_http_headers_get(request->send_data.response_headers, g_etag_header_name, &etag_header_value) ==
                AWS_OP_SUCCESS) {
                AWS_LOGF_TRACE(
                    AWS_LS_S3_META_REQUEST,
                    "id=%p ETag received for the meta request. value is: " PRInSTR "",
                    (void *)meta_request,
                    AWS_BYTE_CURSOR_PRI(etag_header_value));

                if (!auto_ranged_get->initial_message_has_if_match_header) {
                    /* Store ETag if needed for If-Match header. A second discovery request can
                     * finish after an empty-file redo: free any previously captured value so the
                     * latest discovery wins and nothing leaks. */
                    aws_string_destroy(auto_ranged_get->etag);
                    auto_ranged_get->etag =
                        aws_string_new_from_cursor(auto_ranged_get->base.allocator, &etag_header_value);
                }
            } else {
                AWS_LOGF_ERROR(AWS_LS_S3_META_REQUEST, "id=%p ETag headers are missing", (void *)meta_request);
                aws_raise_error(AWS_ERROR_S3_MISSING_ETAG);
                error_code = AWS_ERROR_S3_MISSING_ETAG;
                goto update_synced_data;
            }

            /* Capture Last-Modified for resume token. A second discovery request can finish after
             * an empty-file redo: free any previously captured value so the latest discovery wins
             * and nothing leaks. */
            struct aws_byte_cursor last_modified_value;
            struct aws_byte_cursor last_modified_name = aws_byte_cursor_from_c_str("Last-Modified");
            if (aws_http_headers_get(request->send_data.response_headers, last_modified_name, &last_modified_value) ==
                AWS_OP_SUCCESS) {
                aws_string_destroy(auto_ranged_get->s3_object_last_modified);
                auto_ranged_get->s3_object_last_modified =
                    aws_string_new_from_cursor(meta_request->allocator, &last_modified_value);
            }
            /* Extract number of parts stored in S3 from ETag and calculate estimated part size */
            uint32_t num_parts = 0;
            if (aws_s3_extract_parts_from_etag(etag_header_value, &num_parts) == AWS_OP_SUCCESS && num_parts > 0) {
                auto_ranged_get->estimated_object_stored_part_size = object_size / num_parts;

                AWS_LOGF_DEBUG(
                    AWS_LS_S3_META_REQUEST,
                    "id=%p Estimated object stored part size: object_size=%" PRIu64 ", num_parts=%" PRIu32
                    ", estimated_part_size=%" PRIu64,
                    (void *)meta_request,
                    object_size,
                    num_parts,
                    auto_ranged_get->estimated_object_stored_part_size);
            } else {
                /* avoid leaking the error code */
                aws_reset_error();
                num_parts = 1;
                /* Failed to parse ETags */
                AWS_LOGF_WARN(
                    AWS_LS_S3_META_REQUEST,
                    "id=%p Failed to parse ETags, fallback to default part size.",
                    (void *)meta_request);
                auto_ranged_get->estimated_object_stored_part_size = g_default_part_size_fallback;
            }
            auto_ranged_get->num_stored_parts = num_parts;
        }

        /* If we were able to discover the object-range/content length successfully, then any error code that was passed
         * into this function is being handled and does not indicate an overall failure.*/
        error_code = AWS_ERROR_SUCCESS;
        found_object_size = true;
        uint32_t max_connections = aws_s3_client_get_max_active_connections(meta_request->client, meta_request);

        if (auto_ranged_get->force_dynamic_part_size ||
            (!auto_ranged_get->part_size_set && !meta_request->client->part_size_set)) {
            /* No part size has been set from user. Now we use the optimal part size based on the throughput and memory
             * limit */
            uint64_t out_request_optimal_range_size = 0;

            if (aws_s3_calculate_request_optimal_range_size(
                    meta_request->client->optimal_range_size,
                    auto_ranged_get->estimated_object_stored_part_size,
                    meta_request->is_express,
                    &out_request_optimal_range_size) == AWS_OP_SUCCESS) {
                /* Apply a buffer pool alignment to the calculated result. */
                out_request_optimal_range_size = aws_s3_buffer_pool_derive_aligned_buffer_size(
                    meta_request->client->buffer_pool, out_request_optimal_range_size);
                /* For O_DIRECT download, also ensure page alignment.
                 * Buffer pool typically aligns to chunk_size which is page-aligned, but apply
                 * a defensive round-up here to guarantee the invariant. */
                if (meta_request->recv_file_direct_io) {
                    size_t page_size = aws_system_info_page_size();
                    if (out_request_optimal_range_size % page_size != 0) {
                        out_request_optimal_range_size = ((out_request_optimal_range_size / page_size) + 1) * page_size;
                    }
                }
                AWS_LOGF_INFO(
                    AWS_LS_S3_META_REQUEST,
                    "id=%p: Override the part size to be optimal. part_size=%" PRIu64 ".",
                    (void *)meta_request,
                    out_request_optimal_range_size);
                /* Override the part size to be optimal */
                *((size_t *)&meta_request->part_size) = (size_t)out_request_optimal_range_size;
                uint64_t parts_threshold = aws_mul_u64_saturating(max_connections, 2);
                if (auto_ranged_get->num_stored_parts > parts_threshold) {
                    /* If the number of parts is greater than the threshold, so that we will be reusing the buffers
                     * enough from the buffer pool. Let's add a special block for the buffer pool to optimize the
                     * case.*/
                    AWS_LOGF_INFO(
                        AWS_LS_S3_META_REQUEST,
                        "id=%p: Apply buffer pool optimization for the size=%zu.",
                        (void *)meta_request,
                        meta_request->part_size);
                    aws_s3_buffer_pool_add_special_size(meta_request->client->buffer_pool, meta_request->part_size);
                    meta_request->buffer_pool_optimized = true;
                }
                if (request->request_tag == AWS_S3_AUTO_RANGE_GET_REQUEST_TYPE_HEAD_OBJECT) {
                    /* Update the first part size as well, if we haven't made the request yet. */
                    first_part_size = meta_request->part_size;
                }
            }
        }

        /* Check for checksums if requested to, unless we already have one covering the download: the caller
         * supplied it, so there is nothing to discover and the discovery response's own value must not replace it. */
        if (s_should_validate_whole_download(meta_request) &&
            meta_request->meta_request_level_running_response_sum == NULL) {
            if (!s_discovery_checksum_covers_download(
                    request, object_range_start, object_range_end, object_size, first_part_size)) {
                AWS_LOGF_DEBUG(
                    AWS_LS_S3_META_REQUEST,
                    "id=%p: Discovery response's checksum does not cover the bytes being downloaded. The download "
                    "will not be validated against a whole-object checksum.",
                    (void *)meta_request);
            } else if (
                request->did_validate &&
                s_request_body_is_entire_download(request, object_range_start, object_range_end, first_part_size)) {
                /* This response's body was already compared against a checksum header of its own, and that body is
                 * every byte the meta request delivers, so there is nothing left for a meta-request-level sum to
                 * check. update() reports the outcome through the all-parts-validated promotion instead. */
                AWS_LOGF_DEBUG(
                    AWS_LS_S3_META_REQUEST,
                    "id=%p: Discovery response covered the whole download and was already validated against its own "
                    "checksum.",
                    (void *)meta_request);
            } else if (
                aws_s3_check_headers_for_checksum(
                    meta_request,
                    request->send_data.response_headers,
                    &meta_request->meta_request_level_running_response_sum,
                    &meta_request->meta_request_level_response_header_checksum) != AWS_OP_SUCCESS) {
                error_code = aws_last_error_or_unknown();
                goto update_synced_data;
            }
        }

        if (meta_request->is_express &&
            meta_request->part_size < g_s3express_connection_limitation_part_size_threshold &&
            object_size > g_s3express_connection_limitation_object_size_threshold) {
            /**
             * TODO: THIS IS A TEMP WORKAROUND, not the long term solution.
             * 1. If the Part Size we set is larger than the possible size to hit the limitation, we are safe to
             * make as many connections as we want.
             * 2. If the object size is less than the threshold, we keep our previous behavior, as it's less likely
             * to hit the server side limitation.
             *
             * Otherwise, we need to make sure the number of concurrent connections is lower than the limitation.
             */
            uint32_t max_active_connections_override = aws_min_u32(g_s3express_connection_limitation, max_connections);
            if (max_active_connections_override < max_connections) {
                /* Override the max active connections to be the limitation. */
                *((uint32_t *)&meta_request->max_active_connections_override) =
                    (uint32_t)max_active_connections_override;
                AWS_LOGF_WARN(
                    AWS_LS_S3_META_REQUEST,
                    "id=%p: Override the max active connections for the meta request to be the limitation: %d",
                    (void *)meta_request,
                    max_active_connections_override);
            }
        }

        if (!empty_file_error && meta_request->headers_callback != NULL) {
            /* Modify the header received to fake the header for the whole meta request. */
            if (request->request_tag == AWS_S3_AUTO_RANGE_GET_REQUEST_TYPE_GET_OBJECT_WITH_RANGE ||
                request->request_tag == AWS_S3_AUTO_RANGE_GET_REQUEST_TYPE_GET_OBJECT_WITH_PART_NUMBER_1) {

                if (auto_ranged_get->initial_message_has_range_header) {
                    /* Populate the header with object_range */
                    char content_range_buffer[64] = "";
                    snprintf(
                        content_range_buffer,
                        sizeof(content_range_buffer),
                        "bytes %" PRIu64 "-%" PRIu64 "/%" PRIu64,
                        object_range_start,
                        object_range_end,
                        object_size);
                    aws_http_headers_set(
                        request->send_data.response_headers,
                        g_content_range_header_name,
                        aws_byte_cursor_from_c_str(content_range_buffer));
                } else {
                    /* content range isn't applicable. */
                    aws_http_headers_erase(request->send_data.response_headers, g_content_range_header_name);
                }
            }

            uint64_t content_length = object_size ? object_range_end - object_range_start + 1 : 0;
            char content_length_buffer[64] = "";
            snprintf(content_length_buffer, sizeof(content_length_buffer), "%" PRIu64, content_length);
            aws_http_headers_set(
                request->send_data.response_headers,
                g_content_length_header_name,
                aws_byte_cursor_from_c_str(content_length_buffer));

            if (meta_request->headers_callback(
                    meta_request,
                    request->send_data.response_headers,
                    s_s3_auto_ranged_get_success_status(meta_request),
                    meta_request->user_data)) {

                error_code = aws_last_error_or_unknown();
            }
            meta_request->headers_callback = NULL;
        }
    }

update_synced_data:

    /* BEGIN CRITICAL SECTION */
    {
        aws_s3_meta_request_lock_synced_data(meta_request);
        bool finishing_metrics = true;

        /* If the object range was found, then record it. */
        if (found_object_size) {
            AWS_ASSERT(!auto_ranged_get->synced_data.object_range_known);
            auto_ranged_get->synced_data.object_range_known = true;
            auto_ranged_get->synced_data.object_range_empty = (object_size == 0);
            auto_ranged_get->synced_data.object_range_start = object_range_start;
            auto_ranged_get->synced_data.object_range_end = object_range_end;
            auto_ranged_get->synced_data.object_size = object_size;
            /* A part is delivered at its absolute position in the object, so the file sink needs the
             * range's origin to map the range's first byte to the file's base offset. Set before any
             * body is delivered, since the range is resolved from the first response's headers. */
            meta_request->recv_file_object_range_origin_resolved = true;
            meta_request->recv_file_object_range_origin = object_range_start;
            if (!first_part_buffer_size_mismatch && first_part_size) {
                /* Only record the discovered first-part size on a successful partNumber request.
                 * On a buffer-size mismatch the request was cancelled before the body arrived, so
                 * we fall back to ranged gets using the client part_size (already the default). */
                auto_ranged_get->synced_data.first_part_size = first_part_size;
            }
            if (auto_ranged_get->synced_data.object_range_empty == 0) {
                auto_ranged_get->synced_data.total_num_parts = aws_s3_calculate_auto_ranged_get_num_parts(
                    meta_request->part_size,
                    auto_ranged_get->synced_data.first_part_size,
                    object_range_start,
                    object_range_end);

                /* Delivery validation mask: one bit per part, checked before success. */
                aws_mem_release(meta_request->allocator, meta_request->synced_data.parts_delivered_mask);
                const uint32_t mask_length = (uint32_t)(((size_t)auto_ranged_get->synced_data.total_num_parts + 7) / 8);
                meta_request->synced_data.parts_delivered_mask =
                    aws_mem_calloc(meta_request->allocator, mask_length, sizeof(uint8_t));
                meta_request->synced_data.parts_delivered_mask_length = mask_length;
                meta_request->synced_data.parts_delivered_mask_num_parts = auto_ranged_get->synced_data.total_num_parts;
            }

            /* Only now is the part count known, which is what sizes the per-part checksum slots. Deciding
             * here also means every part dispatched afterwards sees the decision already made. */
            if (s_should_validate_whole_download(meta_request) && error_code == AWS_ERROR_SUCCESS) {
                if (aws_s3_meta_request_setup_checksum_combine_synced(
                        meta_request, request, auto_ranged_get->synced_data.total_num_parts) != AWS_OP_SUCCESS) {
                    error_code = aws_last_error_or_unknown();
                }
            }

            /* And only now is the last input to the delivery order known: the line above is what decides
             * whether a whole-object checksum can be folded per part or has to see the body in object
             * order. Resolved here rather than on the first body so that the discovery response's own body,
             * delivered further down this same function, is already governed by it. */
            s_resolve_out_of_order_delivery(meta_request);
        }

        switch (request->request_tag) {
            case AWS_S3_AUTO_RANGE_GET_REQUEST_TYPE_HEAD_OBJECT:
                auto_ranged_get->synced_data.head_object_completed = true;
                AWS_LOGF_DEBUG(AWS_LS_S3_META_REQUEST, "id=%p Head object completed.", (void *)meta_request);
                break;
            case AWS_S3_AUTO_RANGE_GET_REQUEST_TYPE_GET_OBJECT_WITH_PART_NUMBER_1:
                AWS_LOGF_DEBUG(AWS_LS_S3_META_REQUEST, "id=%p Get Part Number completed.", (void *)meta_request);
                if (first_part_buffer_size_mismatch && found_object_size) {
                    /* The hint-sized buffer was too small to hold the first part, so the partNumber
                     * request was cancelled before its body arrived. We already parsed the object size
                     * from the cancelled response's headers, so we keep that discovered range and fetch
                     * the data as ranged gets using the client part_size. Note: the recovery ranged gets
                     * may not align to stored part boundaries, so per-part checksum validation may not
                     * be possible in this case. */
                    auto_ranged_get->synced_data.num_parts_requested = 0;
                    break;
                }
                /* fall through */
            case AWS_S3_AUTO_RANGE_GET_REQUEST_TYPE_GET_OBJECT_WITH_RANGE:
                if (empty_file_error) {
                    /*
                     * Try to download the object again using GET_OBJECT_WITH_PART_NUMBER_1. If the file is still
                     * empty, successful response headers will be provided to users. If not, the newer version of
                     * the file will be downloaded.
                     */
                    auto_ranged_get->synced_data.num_parts_requested = 0;
                    auto_ranged_get->synced_data.object_range_known = 0;
                    break;
                }

                ++auto_ranged_get->synced_data.num_parts_completed;

                if (!request_failed) {

                    /* Record the number of parts that checksum has been validated */
                    if (request->did_validate) {
                        if (auto_ranged_get->validation_algorithm == AWS_SCA_NONE) {
                            auto_ranged_get->validation_algorithm = request->validation_algorithm;
                        }
                        /* They should be the same. */
                        AWS_ASSERT(auto_ranged_get->validation_algorithm == request->validation_algorithm);
                        ++auto_ranged_get->synced_data.num_parts_checksum_validated;
                    }
                    ++auto_ranged_get->synced_data.num_parts_successful;

                    /* Send progress_callback for delivery on io_event_loop thread */
                    if (meta_request->progress_callback != NULL) {
                        struct aws_s3_meta_request_event event = {.type = AWS_S3_META_REQUEST_EVENT_PROGRESS};
                        event.u.progress.info.bytes_transferred = request->send_data.response_body.len;
                        if (auto_ranged_get->synced_data.object_range_empty) {
                            event.u.progress.info.content_length = 0;
                        } else {
                            /* Note that range-end is inclusive */
                            event.u.progress.info.content_length = auto_ranged_get->synced_data.object_range_end + 1 -
                                                                   auto_ranged_get->synced_data.object_range_start;
                        }
                        aws_s3_meta_request_add_event_for_delivery_synced(meta_request, &event);
                    }

                    aws_s3_meta_request_stream_response_body_synced(meta_request, request);
                    /* The body of the request is queued to be streamed, don't finish the metrics yet. */
                    finishing_metrics = false;

                    AWS_LOGF_DEBUG(
                        AWS_LS_S3_META_REQUEST,
                        "id=%p: %d out of %d parts have completed.",
                        (void *)meta_request,
                        (auto_ranged_get->synced_data.num_parts_successful +
                         auto_ranged_get->synced_data.num_parts_failed),
                        auto_ranged_get->synced_data.total_num_parts);
                } else {
                    ++auto_ranged_get->synced_data.num_parts_failed;
                }
                break;
        }

        if (error_code != AWS_ERROR_SUCCESS) {
            if (error_code == AWS_ERROR_S3_INVALID_RESPONSE_STATUS &&
                request->send_data.response_status == AWS_HTTP_STATUS_CODE_412_PRECONDITION_FAILED &&
                !auto_ranged_get->initial_message_has_if_match_header) {
                /* Use more clear error code as we added the if-match header under the hood. */
                error_code = AWS_ERROR_S3_OBJECT_MODIFIED;
            }
            aws_s3_meta_request_set_fail_synced(meta_request, request, error_code);
            if (error_code == AWS_ERROR_S3_RESPONSE_CHECKSUM_MISMATCH) {
                /* It's a mismatch of checksum, tell user that we validated the checksum and the algorithm we
                 * validated
                 */
                meta_request->synced_data.finish_result.did_validate = true;
                meta_request->synced_data.finish_result.validation_algorithm = request->validation_algorithm;
            }
        }
        if (finishing_metrics) {
            aws_s3_request_finish_up_metrics_synced(request, meta_request);
        }

        /* Both decisions -- delivery order and request order -- are made from the discovery finish, after
         * every input is settled and every recovery branch has had its say. Lane init reads the delivery
         * order that was just resolved, so the two cannot disagree. Skipped when a branch threw the range
         * away, since the rediscovery will decide. */
        if (request->discovers_object_size && auto_ranged_get->synced_data.object_range_known) {
            s_init_spread_synced(meta_request);
        }

        aws_s3_meta_request_unlock_synced_data(meta_request);
    }
    /* END CRITICAL SECTION */
}

static struct aws_s3_meta_request_resume_token *s_build_download_resume_token_synced(
    struct aws_s3_meta_request *meta_request) {

    struct aws_s3_auto_ranged_get *auto_ranged_get = meta_request->impl;

    struct aws_s3_meta_request_resume_token *token = aws_s3_meta_request_resume_token_new(meta_request->allocator);
    token->type = AWS_S3_META_REQUEST_TYPE_GET_OBJECT;
    token->part_size = meta_request->part_size;
    token->total_num_parts = auto_ranged_get->synced_data.total_num_parts;
    /* Range fields stay 0 when the object size was never discovered (paused before the
     * first response) or the object is empty. */
    if (auto_ranged_get->synced_data.object_range_known && !auto_ranged_get->synced_data.object_range_empty) {
        token->object_range_start = auto_ranged_get->synced_data.object_range_start;
        token->object_range_end = auto_ranged_get->synced_data.object_range_end;
        /* Full object size: for a ranged download this is larger than the range being fetched. */
        token->object_size = auto_ranged_get->synced_data.object_size;
    }
    token->num_parts_completed = auto_ranged_get->synced_data.num_parts_successful;

    if (auto_ranged_get->etag) {
        token->etag = aws_string_new_from_string(meta_request->allocator, auto_ranged_get->etag);
    }

    if (auto_ranged_get->s3_object_last_modified) {
        token->s3_object_last_modified =
            aws_string_new_from_string(meta_request->allocator, auto_ranged_get->s3_object_last_modified);
    }

    /* These diverge once parts are written out of order: the prefix stops at the first gap, while the
     * total counts every part that landed. A caller resuming must re-fetch from the prefix, since
     * anything past the gap is not contiguous with what is already on disk. */
    token->continuous_downloaded_bytes = meta_request->synced_data.num_bytes_delivered;
    token->total_downloaded_bytes = meta_request->synced_data.num_bytes_delivered_total;

    return token;
}
